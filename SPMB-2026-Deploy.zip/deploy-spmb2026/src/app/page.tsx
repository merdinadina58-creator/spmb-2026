'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { useToast } from '@/hooks/use-toast'
import jsPDF from 'jspdf'
import autoTable from 'jspdf-autotable'
import * as XLSX from 'xlsx'
import {
  Upload,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Users,
  GraduationCap,
  School,
  Filter,
  ChevronLeft,
  ChevronRight,
  FileSpreadsheet,
  ShieldCheck,
  AlertTriangle,
  Loader2,
  Trash2,
  Eye,
  EyeOff,
  UserCheck,
  UserX,
  ArrowRightLeft,
  ListChecks,
  ThumbsUp,
  ThumbsDown,
  FileText,
  RotateCcw,
  Check,
  MapPin,
  Heart,
  Award,
  BookOpen,
  ClipboardCheck,
  ArrowLeftRight,
  Trophy,
  UserCog,
  ClipboardPaste,
  MapPinned,
  Phone,
  CalendarDays,
  IdCard,
  Pencil,
  CalendarClock,
  Printer,
  AlertCircle,
  X,
  Settings,
  Plus,
  Save,
  Globe,
  RefreshCw,
  Lock,
  Mail,
  Copy,
  CircleCheckBig,
  CircleX,
  ClipboardList,
  UserMinus,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  FileDown,
  FileSpreadsheet as FileExcel,
  LayoutList,
  Download,
} from 'lucide-react'

interface Registration {
  id: string
  noRegistrasi: string
  nama: string
  nisn: string
  subJalur: string
  npsnSekolahPilihan: string
  namaSekolahPilihan: string
  jurusan: string
  npsnSekolahAsal: string
  namaSekolahAsal: string
  status: string
  waktuDaftar: string
  verificationStatus: string
  verificationNote: string | null
  createdAt: string
  updatedAt: string
  // Portal SPMB fields
  nik?: string | null
  tanggalLahir?: string | null
  alamat?: string | null
  alamatLengkap?: string | null
  noTelpSiswa?: string | null
  noTelpOrangtua?: string | null
  latitude?: string | null
  longitude?: string | null
  lokasiJarak?: string | null
  nilaiRataRata?: string | null
  skorJarak?: string | null
  skor?: string | null
  nilaiRapor?: string | null
  // Verification-specific fields
  skorNilaiRaport?: string | null
  kekuranganVerifikasi?: string | null
  tanggalVerif?: string | null
  jamVerif?: string | null
  terbitKK?: string | null
  lamaKK?: string | null
  dokumen?: string | null
  statusKelulusan?: string | null
  statusDaftarUlang?: string | null
}

interface DashboardStats {
  total: number
  verified: number
  rejected: number
  pending: number
  bySubJalur: { name: string; count: number }[]
  bySekolahPilihan: { name: string; count: number }[]
  byJurusan: { name: string; count: number }[]
  byStatus: { name: string; count: number }[]
  verifiedBySubJalur: { name: string; count: number }[]
  verifiedBySekolah: { name: string; count: number }[]
  verifiedByJurusan: { name: string; count: number }[]
  verifiedList: Registration[]
  rejectedBySubJalur: { name: string; count: number }[]
  rejectedBySekolah: { name: string; count: number }[]
  rejectedByJurusan: { name: string; count: number }[]
  rejectedList: Registration[]
  // Kelulusan
  lulus: number
  tidakLulus: number
  lulusBySubJalur: { name: string; count: number }[]
  lulusList: Registration[]
  tidakLulusBySubJalur: { name: string; count: number }[]
  tidakLulusList: Registration[]
  // Daftar Ulang
  daftarUlang: number
  tidakDaftarUlang: number
  daftarUlangBySubJalur: { name: string; count: number }[]
  daftarUlangList: Registration[]
  tidakDaftarUlangBySubJalur: { name: string; count: number }[]
  tidakDaftarUlangList: Registration[]
}

interface PaginationInfo {
  page: number
  limit: number
  total: number
  totalPages: number
}

interface LembarVerifikasiData {
  registrations: Registration[]
  pagination: PaginationInfo
  stats: {
    total: number
    verified: number
    rejected: number
    pending: number
  }
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-800 border-yellow-300',
  VERIFIED: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  REJECTED: 'bg-red-100 text-red-800 border-red-300',
}

// Kategori Kekurangan Verifikasi (tanpa nomor agar mudah di-copy)
const KEKURANGAN_VERIFIKASI_DEFAULTS = [
  'Tidak Ada Kendala',
  'Titik Koordinat tidak sesuai dengan Alamat di Kartu Keluarga',
  'Tidak Foto Rapor Semester 2',
  'Tidak Foto Rapor Semester 3',
  'Tidak Foto Rapor Semester 4',
  'Tidak Foto Rapor Semester 5',
  'Foto KK Buram tidak dapat dibaca',
  'Perubahan tempat dan tanggal tanda tangan pada surat pernyataan orang tua',
  'Foto Surat Keterangan Keabsahan Nilai Buram/ tidak dapat dibaca',
  'Tidak Ada Foto Surat Keterangan Kepala Sekolah (Keabsahan Nilai)',
  'Nilai Raport yang dientri tidak sesuai dengan foto nilai Per Semester',
  'Salah Input Nilai Raport Semester 1',
  'Salah Input Nilai Raport Semester 2',
  'Salah Input Nilai Raport Semester 3',
  'Salah Input Nilai Raport Semester 4',
  'Salah Input Nilai Raport Semester 5',
  'Tidak Ada Foto Rapor Sem 1, Sem 2, Sem 3, Sem 4',
  'Tidak Ada Foto Rapor Sem 1, Sem 2, Sem 3',
  'Tidak Ada Foto Rapor Sem 1, Sem 2',
  'Tidak Ada Foto Rapor Sem 1',
  'Tidak Ada Foto Rapor Sem 2',
  'Tidak Ada Foto Rapor Sem 3',
  'Tidak Ada Foto Rapor Sem 4',
  'Tidak Ada Foto Rapor Sem 5',
  'Tidak Ada Foto Rapor Samasekali',
  'Foto KK dan Surat Keterangan Buram',
  'Foto KK dan Rapor Buram',
  'Foto Surat Keterangan Kepala Sekolah dan Foto Rapor Buram',
  'Surat Pernyataan Orangtua/ Wali Tidak Dibubuhi Materai 10.000',
  'Titik Koordinat dan alamat di KK tidak sinkron',
  'Umur KK Baru 13 Hari',
  'Usia KK Masih Belum Setahun Silahkan Upload KK yang Diatas Satu tahun',
  'Umur KK Belum 1 Tahun',
  'Buram Foto Rapor Semester 2, 3, 4 dan 5',
  'Buram Foto Rapor Semester 3, 4 dan 5',
  'Buram Foto Rapor Semester 4 dan 5',
  'Surat pernyataan orang tua salah',
  'Foto raport yang di upload adalah foto raport asli dan bukan daftar kumpul',
  'Salah Upload bukti dokumen PIP',
  'Ditolak dinas',
  'KK tidak aktif segera aktifkan ke dukcapil serta surat keterangan tidak mampu',
  'KK tidak aktif segera aktifkan ke dukcapil supaya bisa mendaftar kembali',
  'Titik koordinat berbeda dan kartu keluarga tidak dapat di scan',
  'Kartu PKH sudah tidak aktif',
  'Titik koordinat salah dan KK tidak aktif',
  'Foto KK tidak dapat di scan',
  'Dokumen PKH yang diunggah salah dan surat pernyataan tidak sesuai form',
  'KK kurang dari 1 tahun dan nilai raport yang di input tidak sesuai dengan foto',
  'Nilai raport yang di input tidak sesuai dengan yang di upload',
  'KK tidak aktif, tidak ada kartu PKH, format pernyataan orang tua salah',
  'KK tidak aktif dan ket. Tempat dan tanggal surat pernyataan orang tua tidak sesuai',
  'KK tidak dapat dibaca dan hasil scan kartu KIP eror',
  'Dokumen KIP salah dan surat pernyataan orang tua kurang jelas',
  'KK tidak aktif dan titik koordinat salah',
  'KK kurang 1 tahun, dokumen KIP buram dan surat pernyataan orang tua tidak sesuai',
  'KK tidak aktif, foto raport tidak jelas dan tidak rapi',
  'Foto raport salah di upload',
  'KK blm 1 tahun, foto KIP buram dan tidak rapi',
  'Foto KK tidak dapat di baca',
  'Foto raport yang di upload pada semester 5 salah',
  'Alamat titik koordinat tidak sesuai dengan alamat di KK dan surat pernyataan',
  'Foto kartu KIP terpotong',
  'KK dan KIP tidak ditemukan serta tanda tangan tidak mengenai materai',
  'Nilai yang di input sem. 2 tidak sesuai dengan foto yang di upload',
  'Umur KK kurang dari 1 tahun dan foto raport tidak sesuai',
  'Nilai yang di input tidak sesuai dengan surat keabsahan nilai dari kasek',
  'KK tidak aktif',
  'Foto KK tdk dapat di scan',
  'Nilai raport sem. 1 yang di upload berbeda dengan surat keabsahan nilai raport',
  'Titik koordinat tidak sesuai, umur KK kurang dari 1 tahun, dokumen PKH salah',
  'KK tidak dapat di scan, titik koordinat tidak sesuai KK, kartu KIP tidak dapat di scan',
  'KK tidak dapat di baca dan kartu KIP eror saat di scan',
  'KK tidak dapat di baca dan titik koordinat tidak sesuai (titik di hutan)',
  'Foto raport semester 5 tidak lengkap dan KK tidak dapat discan',
  'KK buram dan salah upload foto raport',
  'KK tidak jelas, surat pernyataan salah',
  'KK dan kartu KIP tidak ditemukan',
  'Surat pernyataan keabsahan nilai raport salah',
  'Foto KK',
  'Kartu KIP tidak di upload',
  'Nilai sem. 4 dan 5 yang di input tidak sesuai dengan foto raport, umur KK kurang 1 tahun',
  'Titik koordinat tidak sesuai dengan KK, foto raport yang di upload tidak sesuai',
  'Foto raport tidak lengkap',
  'KK kurang 1 tahun dan surat keabsahan raport tidak sesuai',
  'Surat pernyataan dan kartu PKH tidak sesuai',
  'Umur KK kurang 1 tahun dan foto raport yang di upload salah',
  'KK kurang 1 tahun dan surat pernyataan tidak sesuai',
  'KK tidak aktif dan foto raport tidak lengkap',
  'Umur KK kurang 1 tahun dan nilai raport tidak sesuai dengan yang di input',
  'Foto raport semester 5 tidak lengkap',
  'Dokumen surat tugas tidak lengkap dan KK tidak aktif',
  'Foto raport terpotong',
  'Umur KK kurang 1 tahun',
  'Surat keabsahan yang di upload tidak sesuai',
]

// Custom kekurangan options are now stored in the database (not localStorage)
// so they persist even when browser history is cleared

// Fetch custom kekurangan options from database API
async function fetchCustomKekuranganOptions(): Promise<string[]> {
  try {
    const res = await fetch('/api/kekurangan-options')
    if (!res.ok) return []
    const data = await res.json()
    return data.custom || []
  } catch {
    return []
  }
}

// Add a new custom option and persist to database
async function addKekuranganOption(opt: string): Promise<string[]> {
  try {
    const res = await fetch('/api/kekurangan-options', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ option: opt }),
    })
    if (!res.ok) return []
    const data = await res.json()
    return data.custom || []
  } catch {
    return []
  }
}

const SUB_JALUR_COLORS: Record<string, string> = {
  'Domisili': 'bg-sky-100 text-sky-800 border-sky-200',
  'Keluarga Tidak Mampu': 'bg-orange-100 text-orange-800 border-orange-200',
  'Afirmasi': 'bg-orange-100 text-orange-800 border-orange-200',
  'Disabilitas': 'bg-purple-100 text-purple-800 border-purple-200',
  'Anak Guru': 'bg-violet-100 text-violet-800 border-violet-200',
  'Prestasi': 'bg-emerald-100 text-emerald-800 border-emerald-200',
  'Prestasi Non Akademik': 'bg-teal-100 text-teal-800 border-teal-200',
  'Mutasi': 'bg-cyan-100 text-cyan-800 border-cyan-200',
}

// Hitung Lama KK dari tanggal Terbit KK
function hitungLamaKK(terbitKK: string): string {
  if (!terbitKK) return ''
  const terbit = new Date(terbitKK)
  if (isNaN(terbit.getTime())) return ''
  const now = new Date()
  let years = now.getFullYear() - terbit.getFullYear()
  let months = now.getMonth() - terbit.getMonth()
  let days = now.getDate() - terbit.getDate()
  if (days < 0) {
    months--
    const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0)
    days += prevMonth.getDate()
  }
  if (months < 0) {
    years--
    months += 12
  }
  const parts: string[] = []
  if (years > 0) parts.push(`${years} Tahun`)
  if (months > 0) parts.push(`${months} Bulan`)
  if (days > 0 && years === 0) parts.push(`${days} Hari`)
  if (parts.length === 0) parts.push('0 Hari')
  return parts.join(' ')
}

// Cek apakah KK kurang dari 1 tahun
function isKKKurangSetahun(terbitKK: string): boolean {
  if (!terbitKK) return false
  const terbit = new Date(terbitKK)
  if (isNaN(terbit.getTime())) return false
  const now = new Date()
  const diffMs = now.getTime() - terbit.getTime()
  const diffDays = diffMs / (1000 * 60 * 60 * 24)
  return diffDays < 365
}

// Lembar Verifikasi — built dynamically from jalurConfigs
// Icon and color mapping by jalur nama keywords
const JALUR_ICON_MAP: Record<string, any> = {
  'domisili': MapPin,
  'afirmasi': Heart,
  'ktm': Heart,
  'keluarga tidak mampu': Heart,
  'disabilitas': BookOpen,
  'penyandang disabilitas': BookOpen,
  'anak guru': UserCog,
  'mutasi': ArrowLeftRight,
  'perpindahan': ArrowLeftRight,
  'prestasi nilai rapor': Award,
  'prestasi akademik': Award,
  'prestasi': Award,
  'non akademik': Trophy,
  'nonakademik': Trophy,
  'bencana': AlertTriangle,
}

const JALUR_COLOR_MAP: Record<string, { color: string; bgColor: string; borderColor: string; headerBg: string; iconBg: string; iconColor: string; btnColor: string }> = {
  'domisili': { color: 'sky', bgColor: 'bg-sky-50', borderColor: 'border-sky-500', headerBg: 'bg-sky-50/80', iconBg: 'bg-sky-100', iconColor: 'text-sky-600', btnColor: 'bg-sky-600 hover:bg-sky-700' },
  'afirmasi': { color: 'orange', bgColor: 'bg-orange-50', borderColor: 'border-orange-500', headerBg: 'bg-orange-50/80', iconBg: 'bg-orange-100', iconColor: 'text-orange-600', btnColor: 'bg-orange-600 hover:bg-orange-700' },
  'ktm': { color: 'orange', bgColor: 'bg-orange-50', borderColor: 'border-orange-500', headerBg: 'bg-orange-50/80', iconBg: 'bg-orange-100', iconColor: 'text-orange-600', btnColor: 'bg-orange-600 hover:bg-orange-700' },
  'keluarga tidak mampu': { color: 'orange', bgColor: 'bg-orange-50', borderColor: 'border-orange-500', headerBg: 'bg-orange-50/80', iconBg: 'bg-orange-100', iconColor: 'text-orange-600', btnColor: 'bg-orange-600 hover:bg-orange-700' },
  'disabilitas': { color: 'purple', bgColor: 'bg-purple-50', borderColor: 'border-purple-500', headerBg: 'bg-purple-50/80', iconBg: 'bg-purple-100', iconColor: 'text-purple-600', btnColor: 'bg-purple-600 hover:bg-purple-700' },
  'penyandang disabilitas': { color: 'purple', bgColor: 'bg-purple-50', borderColor: 'border-purple-500', headerBg: 'bg-purple-50/80', iconBg: 'bg-purple-100', iconColor: 'text-purple-600', btnColor: 'bg-purple-600 hover:bg-purple-700' },
  'anak guru': { color: 'violet', bgColor: 'bg-violet-50', borderColor: 'border-violet-500', headerBg: 'bg-violet-50/80', iconBg: 'bg-violet-100', iconColor: 'text-violet-600', btnColor: 'bg-violet-600 hover:bg-violet-700' },
  'mutasi': { color: 'cyan', bgColor: 'bg-cyan-50', borderColor: 'border-cyan-500', headerBg: 'bg-cyan-50/80', iconBg: 'bg-cyan-100', iconColor: 'text-cyan-600', btnColor: 'bg-cyan-600 hover:bg-cyan-700' },
  'perpindahan': { color: 'cyan', bgColor: 'bg-cyan-50', borderColor: 'border-cyan-500', headerBg: 'bg-cyan-50/80', iconBg: 'bg-cyan-100', iconColor: 'text-cyan-600', btnColor: 'bg-cyan-600 hover:bg-cyan-700' },
  'prestasi nilai rapor': { color: 'emerald', bgColor: 'bg-emerald-50', borderColor: 'border-emerald-500', headerBg: 'bg-emerald-50/80', iconBg: 'bg-emerald-100', iconColor: 'text-emerald-600', btnColor: 'bg-emerald-600 hover:bg-emerald-700' },
  'prestasi akademik': { color: 'emerald', bgColor: 'bg-emerald-50', borderColor: 'border-emerald-500', headerBg: 'bg-emerald-50/80', iconBg: 'bg-emerald-100', iconColor: 'text-emerald-600', btnColor: 'bg-emerald-600 hover:bg-emerald-700' },
  'prestasi non akademik': { color: 'teal', bgColor: 'bg-teal-50', borderColor: 'border-teal-500', headerBg: 'bg-teal-50/80', iconBg: 'bg-teal-100', iconColor: 'text-teal-600', btnColor: 'bg-teal-600 hover:bg-teal-700' },
  'nonakademik': { color: 'teal', bgColor: 'bg-teal-50', borderColor: 'border-teal-500', headerBg: 'bg-teal-50/80', iconBg: 'bg-teal-100', iconColor: 'text-teal-600', btnColor: 'bg-teal-600 hover:bg-teal-700' },
  'bencana': { color: 'red', bgColor: 'bg-red-50', borderColor: 'border-red-500', headerBg: 'bg-red-50/80', iconBg: 'bg-red-100', iconColor: 'text-red-600', btnColor: 'bg-red-600 hover:bg-red-700' },
}

// Fallback colors for custom jalur (cycling through these)
const FALLBACK_COLORS = [
  { color: 'rose', bgColor: 'bg-rose-50', borderColor: 'border-rose-500', headerBg: 'bg-rose-50/80', iconBg: 'bg-rose-100', iconColor: 'text-rose-600', btnColor: 'bg-rose-600 hover:bg-rose-700' },
  { color: 'indigo', bgColor: 'bg-indigo-50', borderColor: 'border-indigo-500', headerBg: 'bg-indigo-50/80', iconBg: 'bg-indigo-100', iconColor: 'text-indigo-600', btnColor: 'bg-indigo-600 hover:bg-indigo-700' },
  { color: 'amber', bgColor: 'bg-amber-50', borderColor: 'border-amber-500', headerBg: 'bg-amber-50/80', iconBg: 'bg-amber-100', iconColor: 'text-amber-600', btnColor: 'bg-amber-600 hover:bg-amber-700' },
  { color: 'lime', bgColor: 'bg-lime-50', borderColor: 'border-lime-500', headerBg: 'bg-lime-50/80', iconBg: 'bg-lime-100', iconColor: 'text-lime-600', btnColor: 'bg-lime-600 hover:bg-lime-700' },
  { color: 'fuchsia', bgColor: 'bg-fuchsia-50', borderColor: 'border-fuchsia-500', headerBg: 'bg-fuchsia-50/80', iconBg: 'bg-fuchsia-100', iconColor: 'text-fuchsia-600', btnColor: 'bg-fuchsia-600 hover:bg-fuchsia-700' },
]

// subJalurFilter mapping — maps jalur nama to the subJalur value used in Registration data
// If a jalur name doesn't match the subJalur value in the data, add it here
const JALUR_SUB_FILTER_MAP: Record<string, string> = {
  'Afirmasi (KTM)': 'Keluarga Tidak Mampu',
  'Keluarga Tidak Mampu': 'Keluarga Tidak Mampu',
  'Penyandang Disabilitas': 'Disabilitas',
  'Mutasi Orang tua/ Wali': 'Mutasi',
  'Prestasi Akademik': 'Prestasi',
  'Prestasi Nonakademik': 'Prestasi Non Akademik',
  'Terdampak Bencana Alam': 'Terdampak Bencana Alam',
}

function getJalurIcon(nama: string) {
  const lower = nama.toLowerCase()
  for (const [keyword, icon] of Object.entries(JALUR_ICON_MAP)) {
    if (lower.includes(keyword)) return icon
  }
  return ClipboardCheck // default icon
}

function getJalurColors(nama: string, index: number) {
  const lower = nama.toLowerCase()
  for (const [keyword, colors] of Object.entries(JALUR_COLOR_MAP)) {
    if (lower.includes(keyword)) return colors
  }
  return FALLBACK_COLORS[index % FALLBACK_COLORS.length]
}

function getJalurSubFilter(nama: string) {
  return JALUR_SUB_FILTER_MAP[nama] || nama
}

// Build Lembar Verifikasi config from jalurConfigs
function buildLembarVerifikasi(jalurConfigs: Array<{ id: string; nama: string; urutan: number; aktif: boolean }>) {
  const active = jalurConfigs.filter(j => j.aktif)
  return active.map((jalur, idx) => {
    const key = jalur.nama.toLowerCase().replace(/[^a-z0-9]+/g, '-')
    const colors = getJalurColors(jalur.nama, idx)
    const icon = getJalurIcon(jalur.nama)
    const subJalurFilter = getJalurSubFilter(jalur.nama)
    return {
      key,
      label: jalur.nama,
      icon,
      subJalurFilter,
      ...colors,
      description: `Verifikasi pendaftar jalur ${jalur.nama}`,
    }
  })
}

// Type for Lembar Verifikasi config
interface LembarVerifikasiConfig {
  key: string
  label: string
  icon: any
  subJalurFilter: string
  color: string
  bgColor: string
  borderColor: string
  headerBg: string
  iconBg: string
  iconColor: string
  btnColor: string
  description: string
}

function StatBar({ label, count, total, color }: { label: string; count: number; total: number; color: string }) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium text-gray-700">{label}</span>
        <span className="text-gray-500 tabular-nums">{count} ({total > 0 ? Math.round((count / total) * 100) : 0}%)</span>
      </div>
      <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
        <div
          className={`h-2.5 rounded-full transition-all duration-700 ease-out ${color}`}
          style={{ width: total > 0 ? `${(count / total) * 100}%` : '0%' }}
        />
      </div>
    </div>
  )
}

// Multi-Select Kekurangan Verifikasi Dialog
function KekuranganVerifSelect({ value, onChange }: { value: string; onChange: (val: string) => void }) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [manualInput, setManualInput] = useState('')
  const [options, setOptions] = useState<string[]>(KEKURANGAN_VERIFIKASI_DEFAULTS)
  const [copied, setCopied] = useState(false)
  const [loading, setLoading] = useState(false)

  // Fetch custom options from database on mount
  useEffect(() => {
    let cancelled = false
    const loadOptions = async () => {
      try {
        const custom = await fetchCustomKekuranganOptions()
        if (cancelled) return
        const combined = [...KEKURANGAN_VERIFIKASI_DEFAULTS]
        for (const c of custom) {
          if (!combined.includes(c)) combined.push(c)
        }
        setOptions(combined)
      } catch { /* use defaults */ }
    }
    loadOptions()
    return () => { cancelled = true }
  }, [])

  // Parse stored value into array (split by "; ")
  const stripNumber = (s: string) => s.replace(/^\d+\.\s*/, '')
  const selectedItems: string[] = value
    ? value.split('; ').map(s => stripNumber(s.trim())).filter(Boolean)
    : []

  const filtered = search
    ? options.filter(opt => opt.toLowerCase().includes(search.toLowerCase()))
    : options

  const toggleItem = (item: string) => {
    const cleanItem = stripNumber(item)
    const current = selectedItems.map(s => stripNumber(s))
    const next = current.includes(cleanItem)
      ? current.filter(s => s !== cleanItem)
      : [...current, cleanItem]
    onChange(next.join('; '))
  }

  const handleAddManual = async () => {
    const trimmed = manualInput.trim()
    if (!trimmed) return
    setLoading(true)
    try {
      const custom = await addKekuranganOption(trimmed)
      const combined = [...KEKURANGAN_VERIFIKASI_DEFAULTS]
      for (const c of custom) {
        if (!combined.includes(c)) combined.push(c)
      }
      setOptions(combined)
      // Add to selection
      const current = selectedItems.map(s => stripNumber(s))
      if (!current.includes(trimmed)) {
        onChange([...current, trimmed].join('; '))
      }
      setManualInput('')
      setSearch('')
    } finally {
      setLoading(false)
    }
  }

  const handleCopyAll = async () => {
    if (selectedItems.length === 0) return
    const text = selectedItems.map(s => stripNumber(s)).join('\n')
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = text
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyInline = async () => {
    if (selectedItems.length === 0) return
    const text = selectedItems.map(s => stripNumber(s)).join('\n')
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = text
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    }
  }

  const clearAll = () => {
    onChange('')
  }

  const fullText = selectedItems.join('\n')

  return (
    <div className="flex items-start gap-1 min-w-[180px] max-w-[360px]">
      {/* Click to open dialog — full text display */}
      <button
        className="cursor-pointer hover:bg-sky-50 px-1.5 py-1 rounded group text-xs text-left flex-1 min-w-0"
        onClick={() => setOpen(true)}
      >
        {selectedItems.length === 0 ? (
          <span className="text-gray-400">-</span>
        ) : (
          <div className="space-y-0.5">
            {selectedItems.map((item, idx) => (
              <div key={idx} className="flex items-start gap-1 leading-tight">
                <span className="text-sky-500 shrink-0 mt-px">•</span>
                <span className="text-gray-800 break-words">{item}</span>
              </div>
            ))}
          </div>
        )}
        <Pencil className="w-3 h-3 text-gray-300 group-hover:text-sky-500 shrink-0 mt-0.5" />
      </button>

      {/* Copy Button (inline) */}
      {selectedItems.length > 0 && (
        <button
          className="p-0.5 rounded hover:bg-emerald-50 transition-colors group/copy shrink-0 mt-0.5"
          onClick={handleCopyInline}
          title="Salin alasan untuk paste ke portal SPMB"
        >
          {copied ? (
            <Check className="w-3 h-3 text-emerald-500" />
          ) : (
            <Copy className="w-3 h-3 text-gray-300 group-hover/copy:text-emerald-500" />
          )}
        </button>
      )}

      {/* Dialog */}
      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setSearch(''); setManualInput('') } }}>
        <DialogContent className="sm:max-w-lg p-0 gap-0">
          <DialogHeader className="px-4 pt-4 pb-2">
            <DialogTitle className="flex items-center gap-2 text-base">
              <ClipboardCheck className="w-5 h-5 text-sky-600" />
              Alasan Kekurangan Verifikasi
            </DialogTitle>
          </DialogHeader>

          {/* Selected count */}
          {selectedItems.length > 0 && (
            <div className="mx-4 mb-2 flex items-center gap-2 flex-wrap">
              <span className="text-xs font-medium text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full">
                {selectedItems.length} dipilih
              </span>
              <div className="flex-1" />
              <button
                className="text-[10px] text-red-500 hover:text-red-700 flex items-center gap-0.5"
                onClick={clearAll}
              >
                <XCircle className="w-3 h-3" /> Hapus Semua
              </button>
            </div>
          )}

          {/* Search */}
          <div className="flex items-center border-y px-4 py-2">
            <Search className="w-4 h-4 text-gray-400 mr-2 shrink-0" />
            <input
              placeholder="Cari kategori kekurangan..."
              className="flex-1 text-sm outline-none bg-transparent"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              autoFocus
            />
          </div>

          {/* Manual Input */}
          <div className="border-b px-4 py-2 bg-amber-50/50">
            <div className="flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-amber-500 shrink-0" />
              <input
                placeholder="Ketik alasan baru, lalu tekan Enter..."
                className="flex-1 text-xs outline-none bg-transparent"
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAddManual()
                }}
              />
              {manualInput.trim() && (
                <Button size="sm" variant="outline" className="h-6 text-[10px] px-2 border-amber-300 text-amber-700 hover:bg-amber-100" onClick={handleAddManual}>
                  Tambah
                </Button>
              )}
            </div>
            {manualInput.trim() && (
              <p className="text-[10px] text-amber-600 mt-1 ml-5">Alasan ini akan tersimpan sebagai referensi</p>
            )}
          </div>

          {/* Options List with Checkboxes */}
          <div className="max-h-64 overflow-y-auto">
            {filtered.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-6">Tidak ditemukan</p>
            ) : (
              filtered.map((opt) => {
                const isSelected = selectedItems.some(s => stripNumber(s) === stripNumber(opt))
                return (
                  <div
                    key={opt}
                    className={`px-4 py-2 text-xs cursor-pointer hover:bg-sky-50 transition-colors flex items-start gap-2 ${
                      isSelected ? 'bg-sky-50' : ''
                    }`}
                    onClick={() => toggleItem(opt)}
                  >
                    <Checkbox
                      checked={isSelected}
                      className="mt-0.5 shrink-0"
                      onCheckedChange={() => toggleItem(opt)}
                      onClick={(e) => e.stopPropagation()}
                    />
                    <span className={isSelected ? 'font-medium text-sky-900' : 'text-gray-700'}>{opt}</span>
                  </div>
                )
              })
            )}
          </div>

          {/* Footer Actions */}
          <DialogFooter className="px-4 py-3 border-t bg-gray-50/50 flex-row items-center justify-between gap-2">
            <div className="text-[10px] text-gray-400">
              {selectedItems.length > 0 ? `${selectedItems.length} alasan dipilih` : 'Pilih satu atau lebih alasan'}
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="h-8 text-xs gap-1.5 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                onClick={handleCopyAll}
                disabled={selectedItems.length === 0}
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Tersalin!' : 'Salin Semua'}
              </Button>
              <Button
                size="sm"
                className="h-8 text-xs"
                onClick={() => { setOpen(false); setSearch(''); setManualInput('') }}
              >
                Selesai
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Lembar Verifikasi Sheet Component
function LembarVerifikasiSheet({
  config,
  subJalurOptions,
  onVerify,
  onBulkVerify,
  onViewDetail,
  toast,
}: {
  config: LembarVerifikasiConfig
  subJalurOptions: Array<{ label: string; value: string }>
  onVerify: (id: string, action: 'VERIFIED' | 'REJECTED') => void
  onBulkVerify: (ids: string[], action: 'VERIFIED' | 'REJECTED') => void
  onViewDetail: (reg: Registration) => void
  toast: ReturnType<typeof useToast>['toast']
}) {
  const [data, setData] = useState<LembarVerifikasiData | null>(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [verificationFilter, setVerificationFilter] = useState('all')
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [page, setPage] = useState(1)
  const [showAll, setShowAll] = useState(false)
  const limit = showAll ? 9999 : 20
  const [lembarNamaSort, setLembarNamaSort] = useState<'none' | 'asc' | 'desc'>('none')
  const [verifying, setVerifying] = useState(false)
  const [verifyDialogOpen, setVerifyDialogOpen] = useState(false)
  const [bulkVerifyDialogOpen, setBulkVerifyDialogOpen] = useState(false)
  const [verifyAction, setVerifyAction] = useState<'VERIFIED' | 'REJECTED'>('VERIFIED')
  const [verifyNote, setVerifyNote] = useState('')
  const [verifyTargetId, setVerifyTargetId] = useState<string | null>(null)

  // Inline editing state: key = "regId-fieldName"
  const [editingCell, setEditingCell] = useState<string | null>(null)
  const [editingValue, setEditingValue] = useState('')

  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<Registration | null>(null)
  const [editForm, setEditForm] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  // Delete dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<Registration | null>(null)
  const [deleting, setDeleting] = useState(false)

  const handleFieldUpdate = async (regId: string, field: string, value: string) => {
    try {
      const res = await fetch(`/api/registrations/${regId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ field, value }),
      })
      const result = await res.json()
      if (result.success) {
        // Update local data
        if (data) {
          setData({
            ...data,
            registrations: data.registrations.map(r =>
              r.id === regId ? { ...r, [field]: value || null } : r
            ),
          })
        }
        toast({ title: 'Tersimpan', description: `Data ${field} berhasil diperbarui` })
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal menyimpan', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    }
  }

  // Update multiple fields at once (e.g. terbitKK + lamaKK)
  const handleMultiFieldUpdate = async (regId: string, fields: Record<string, string>) => {
    try {
      const res = await fetch(`/api/registrations/${regId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fields),
      })
      const result = await res.json()
      if (result.success) {
        // Update local data with all fields
        if (data) {
          setData({
            ...data,
            registrations: data.registrations.map(r =>
              r.id === regId ? { ...r, ...Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, v || null])) } : r
            ),
          })
        }
        toast({ title: 'Tersimpan', description: 'Data berhasil diperbarui' })
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal menyimpan', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    }
  }

  const startEditing = (regId: string, field: string, currentValue: string) => {
    setEditingCell(`${regId}-${field}`)
    setEditingValue(currentValue || '')
  }

  const commitEdit = (regId: string, field: string) => {
    handleFieldUpdate(regId, field, editingValue)
    setEditingCell(null)
    setEditingValue('')
  }

  const commitEditDirect = (regId: string, field: string, value: string) => {
    handleFieldUpdate(regId, field, value)
  }

  // Commit terbitKK and auto-calculate lamaKK at once
  const commitTerbitKK = (regId: string, newDate: string) => {
    const calculatedLama = newDate ? hitungLamaKK(newDate) : ''
    // Immediately update local state for instant UI feedback
    if (data) {
      setData({
        ...data,
        registrations: data.registrations.map(r =>
          r.id === regId ? { ...r, terbitKK: newDate || null, lamaKK: calculatedLama || null } : r
        ),
      })
    }
    // Save both fields to backend in one request
    handleMultiFieldUpdate(regId, { terbitKK: newDate, lamaKK: calculatedLama })
    setEditingCell(null)
    setEditingValue('')
  }

  const cancelEdit = () => {
    setEditingCell(null)
    setEditingValue('')
  }

  // Edit dialog functions
  const openEditDialog = (reg: Registration) => {
    setEditTarget(reg)
    setEditForm({
      noRegistrasi: reg.noRegistrasi || '',
      nama: reg.nama || '',
      nisn: reg.nisn || '',
      subJalur: reg.subJalur || '',
      nik: reg.nik || '',
      tanggalLahir: reg.tanggalLahir || '',
      alamat: reg.alamat || '',
      alamatLengkap: reg.alamatLengkap || '',
      noTelpSiswa: reg.noTelpSiswa || '',
      noTelpOrangtua: reg.noTelpOrangtua || '',
      npsnSekolahPilihan: reg.npsnSekolahPilihan || '',
      namaSekolahPilihan: reg.namaSekolahPilihan || '',
      jurusan: reg.jurusan || '',
      npsnSekolahAsal: reg.npsnSekolahAsal || '',
      namaSekolahAsal: reg.namaSekolahAsal || '',
      skorJarak: reg.skorJarak || '',
      skorNilaiRaport: reg.skorNilaiRaport || '',
      kekuranganVerifikasi: reg.kekuranganVerifikasi || '',
      tanggalVerif: reg.tanggalVerif || '',
      jamVerif: reg.jamVerif || '',
      terbitKK: reg.terbitKK || '',
      latitude: reg.latitude || '',
      longitude: reg.longitude || '',
      lokasiJarak: reg.lokasiJarak || '',
      statusKelulusan: reg.statusKelulusan || '',
      statusDaftarUlang: reg.statusDaftarUlang || '',
      nilaiRataRata: reg.nilaiRataRata || '',
    })
    setEditDialogOpen(true)
  }

  const handleSaveEdit = async () => {
    if (!editTarget) return
    setSaving(true)
    try {
      // Auto-calculate lamaKK when terbitKK is provided
      const updateData = { ...editForm }
      if (updateData.terbitKK) {
        const calculatedLama = hitungLamaKK(updateData.terbitKK)
        if (calculatedLama) updateData['lamaKK'] = calculatedLama
      }

      const res = await fetch(`/api/registrations/${editTarget.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData),
      })
      const result = await res.json()
      if (result.success) {
        toast({ title: 'Berhasil', description: `Data ${editTarget.nama} berhasil diperbarui` })
        setEditDialogOpen(false)
        setEditTarget(null)
        fetchData()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal menyimpan', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  // Delete dialog functions
  const openDeleteDialog = (reg: Registration) => {
    setDeleteTarget(reg)
    setDeleteDialogOpen(true)
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/registrations/${deleteTarget.id}`, {
        method: 'DELETE',
      })
      const result = await res.json()
      if (result.success) {
        toast({ title: 'Berhasil', description: `Data ${deleteTarget.nama} berhasil dihapus` })
        setDeleteDialogOpen(false)
        setDeleteTarget(null)
        fetchData()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal menghapus', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setDeleting(false)
    }
  }

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('page', page.toString())
      params.set('limit', limit.toString())
      params.set('subJalur', config.subJalurFilter)
      if (search) params.set('search', search)
      if (verificationFilter !== 'all') params.set('verificationStatus', verificationFilter)

      const res = await fetch(`/api/registrations?${params}`)
      const result = await res.json()

      const regs: Registration[] = result.data || []
      const pag = result.pagination || { page: 1, limit, total: 0, totalPages: 0 }

      // Calculate stats from current data set
      const statsRes = await fetch('/api/dashboard')
      const statsData = await statsRes.json()

      // Filter stats for this sub jalur
      const jalurNames = config.subJalurFilter.split(',').map(s => s.trim())
      const relevantSubJalurStats = statsData.bySubJalur.filter(
        (item: { name: string; count: number }) => jalurNames.includes(item.name)
      )
      const totalForJalur = relevantSubJalurStats.reduce((acc: number, item: { count: number }) => acc + item.count, 0)

      const relevantVerifiedStats = statsData.verifiedBySubJalur.filter(
        (item: { name: string; count: number }) => jalurNames.includes(item.name)
      )
      const verifiedForJalur = relevantVerifiedStats.reduce((acc: number, item: { count: number }) => acc + item.count, 0)

      const relevantRejectedStats = statsData.rejectedBySubJalur.filter(
        (item: { name: string; count: number }) => jalurNames.includes(item.name)
      )
      const rejectedForJalur = relevantRejectedStats.reduce((acc: number, item: { count: number }) => acc + item.count, 0)

      const pendingForJalur = totalForJalur - verifiedForJalur - rejectedForJalur

      setData({
        registrations: regs,
        pagination: pag,
        stats: {
          total: totalForJalur,
          verified: verifiedForJalur,
          rejected: rejectedForJalur,
          pending: pendingForJalur,
        },
      })
    } catch {
      toast({ title: 'Error', description: 'Gagal memuat data', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [page, search, verificationFilter, config.subJalurFilter, toast])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const handleVerify = async () => {
    if (!verifyTargetId) return
    setVerifying(true)
    try {
      const res = await fetch('/api/registrations/verify', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: verifyTargetId,
          verificationStatus: verifyAction,
          verificationNote: verifyNote || undefined,
        }),
      })
      const result = await res.json()
      if (result.success) {
        toast({
          title: verifyAction === 'VERIFIED' ? 'Pendaftar Diterima' : 'Pendaftar Ditolak',
          description: verifyAction === 'VERIFIED' ? 'Data telah diverifikasi dan diterima' : 'Data pendaftar telah ditolak',
        })
        setVerifyDialogOpen(false)
        setVerifyNote('')
        setVerifyTargetId(null)
        fetchData()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Terjadi kesalahan', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setVerifying(false)
    }
  }

  const handleBulkVerify = async () => {
    if (selectedIds.size === 0) return
    setVerifying(true)
    try {
      const res = await fetch('/api/registrations/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: Array.from(selectedIds),
          verificationStatus: verifyAction,
          verificationNote: verifyNote || undefined,
        }),
      })
      const result = await res.json()
      if (result.success) {
        toast({
          title: verifyAction === 'VERIFIED' ? 'Pendaftar Diterima' : 'Pendaftar Ditolak',
          description: `${result.updated} pendaftar ${verifyAction === 'VERIFIED' ? 'diterima' : 'ditolak'}`,
        })
        setBulkVerifyDialogOpen(false)
        setVerifyNote('')
        setSelectedIds(new Set())
        fetchData()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Terjadi kesalahan', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setVerifying(false)
    }
  }

  const toggleSelectAll = () => {
    if (!data) return
    if (selectedIds.size === data.registrations.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(data.registrations.map(r => r.id)))
    }
  }

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    setSelectedIds(next)
  }

  const Icon = config.icon
  const s = data?.stats || { total: 0, verified: 0, rejected: 0, pending: 0 }
  const verifiedPct = s.total > 0 ? Math.round((s.verified / s.total) * 100) : 0
  const rejectedPct = s.total > 0 ? Math.round((s.rejected / s.total) * 100) : 0
  const pendingPct = s.total > 0 ? Math.round((s.pending / s.total) * 100) : 0
  const progressPct = s.total > 0 ? Math.round(((s.verified + s.rejected) / s.total) * 100) : 0

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className={`${config.borderColor} border-l-4 shadow-sm hover:shadow-md transition-shadow`}>
        <CardContent className="p-3 sm:p-5">
          <div className="flex items-center gap-3 sm:gap-4">
            <div className={`p-2 sm:p-3 ${config.iconBg} rounded-lg sm:rounded-xl shadow-sm`}>
              <Icon className={`w-6 h-6 sm:w-8 sm:h-8 ${config.iconColor}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-xl font-bold text-gray-900">Lembar Verifikasi: {config.label}</h3>
                {config.subCategories && (
                  <div className="flex gap-1">
                    {config.subCategories.map(sub => (
                      <Badge key={sub} variant="outline" className={SUB_JALUR_COLORS[sub] || 'bg-gray-100 text-gray-800 border-gray-200'}>
                        {sub}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              <p className="text-sm text-gray-500 mt-0.5">{config.description}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4">
        <Card className={`${config.bgColor} shadow-sm hover:shadow-md transition-shadow`}>
          <CardContent className="p-2.5 sm:p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] sm:text-sm text-gray-500">Total Pendaftar</p>
                <p className="text-lg sm:text-2xl font-bold">{s.total}</p>
              </div>
              <div className={`p-1.5 sm:p-2.5 ${config.iconBg} rounded-lg sm:rounded-xl shadow-sm`}>
                <Users className={`w-4 h-4 sm:w-5 sm:h-5 ${config.iconColor}`} />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-50 to-yellow-50/50 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-2.5 sm:p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] sm:text-sm text-gray-500">Menunggu</p>
                <p className="text-lg sm:text-2xl font-bold text-yellow-600">{s.pending}</p>
              </div>
              <div className="p-1.5 sm:p-2.5 bg-amber-100 rounded-lg sm:rounded-xl shadow-sm">
                <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-emerald-50 to-teal-50/50 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-2.5 sm:p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] sm:text-sm text-gray-500">Diterima</p>
                <p className="text-lg sm:text-2xl font-bold text-emerald-600">{s.verified}</p>
              </div>
              <div className="p-1.5 sm:p-2.5 bg-emerald-100 rounded-lg sm:rounded-xl shadow-sm">
                <UserCheck className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-red-50 to-rose-50/50 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-2.5 sm:p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] sm:text-sm text-gray-500">Ditolak</p>
                <p className="text-lg sm:text-2xl font-bold text-red-600">{s.rejected}</p>
              </div>
              <div className="p-1.5 sm:p-2.5 bg-red-100 rounded-lg sm:rounded-xl shadow-sm">
                <UserX className="w-4 h-4 sm:w-5 sm:h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress */}
      <Card className="shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Progres Verifikasi {config.label}</span>
            <span className="text-sm text-gray-500">{progressPct}% selesai</span>
          </div>
          <Progress value={progressPct} className="h-3" />
          <div className="flex justify-between mt-2 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-gray-600">Diterima: {s.verified} ({verifiedPct}%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <span className="text-gray-600">Ditolak: {s.rejected} ({rejectedPct}%)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
              <span className="text-gray-600">Menunggu: {s.pending} ({pendingPct}%)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters & Search */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Cari nama, no. registrasi, atau NISN..."
                className="pl-9"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(1)
                }}
              />
            </div>
            <Button
              size="sm"
              variant={showAll ? 'default' : 'outline'}
              className={`h-9 gap-1.5 text-xs whitespace-nowrap ${showAll ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
              onClick={() => { setShowAll(!showAll); setPage(1) }}
            >
              <LayoutList className="w-3.5 h-3.5" />
              {showAll ? 'Tampilan Halaman' : 'Tampilkan Semua'}
            </Button>
            <Select
              value={verificationFilter}
              onValueChange={(v) => {
                setVerificationFilter(v)
                setPage(1)
              }}
            >
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Status Verifikasi" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="PENDING">Menunggu</SelectItem>
                <SelectItem value="VERIFIED">Diterima</SelectItem>
                <SelectItem value="REJECTED">Ditolak</SelectItem>
              </SelectContent>
            </Select>
            {selectedIds.size > 0 && (
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="bg-emerald-600 hover:bg-emerald-700"
                  onClick={() => {
                    setVerifyAction('VERIFIED')
                    setBulkVerifyDialogOpen(true)
                  }}
                >
                  <ThumbsUp className="w-4 h-4" />
                  Terima ({selectedIds.size})
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => {
                    setVerifyAction('REJECTED')
                    setBulkVerifyDialogOpen(true)
                  }}
                >
                  <ThumbsDown className="w-4 h-4" />
                  Tolak ({selectedIds.size})
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedIds(new Set())}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Verification Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 z-10 bg-white">
                <TableRow className={config.headerBg}>
                  <TableHead className="w-10 text-center">No</TableHead>
                  <TableHead className="w-10 text-center">
                    <Checkbox
                      checked={data ? data.registrations.length > 0 && selectedIds.size === data.registrations.length : false}
                      onCheckedChange={toggleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Skor Jarak</TableHead>
                  <TableHead>Skor Nilai Raport</TableHead>
                  <TableHead className="min-w-[200px]">Kekurangan Verifikasi</TableHead>
                  <TableHead>Tanggal Verif</TableHead>
                  <TableHead>Jam Verif</TableHead>
                  <TableHead>Terbit KK</TableHead>
                  <TableHead>Lama KK</TableHead>
                  <TableHead>No. Registrasi</TableHead>
                  <TableHead className="cursor-pointer select-none hover:bg-white/10 transition-colors" onClick={() => setLembarNamaSort(prev => prev === 'none' ? 'asc' : prev === 'asc' ? 'desc' : 'none')}>
                    <span className="inline-flex items-center gap-1">
                      Nama Peserta
                      {lembarNamaSort === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                       lembarNamaSort === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                       <ArrowUpDown className="w-3 h-3 opacity-30" />}
                    </span>
                  </TableHead>
                  <TableHead>Asal Sekolah</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={14} className="text-center py-12">
                      <Loader2 className="w-6 h-6 animate-spin mx-auto text-gray-400" />
                      <p className="text-sm text-gray-400 mt-2">Memuat data...</p>
                    </TableCell>
                  </TableRow>
                ) : !data || data.registrations.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={14} className="text-center py-12">
                      <Icon className={`w-10 h-10 mx-auto text-gray-300 mb-2`} />
                      <p className="text-gray-500 font-medium">Belum ada data pendaftar {config.label}</p>
                      <p className="text-sm text-gray-400">Import CSV untuk memulai verifikasi</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  (lembarNamaSort === 'none' ? data.registrations : [...data.registrations].sort((a, b) => {
                    const cmp = a.nama.localeCompare(b.nama, 'id')
                    return lembarNamaSort === 'asc' ? cmp : -cmp
                  })).map((reg, idx) => (
                    <TableRow key={reg.id} className={
                      reg.verificationStatus === 'VERIFIED' ? 'bg-emerald-50/40' :
                      reg.verificationStatus === 'REJECTED' ? 'bg-red-50/40' : ''
                    }>
                      {/* No */}
                      <TableCell className="text-center text-sm text-gray-500">
                        {(data.pagination.page - 1) * data.pagination.limit + idx + 1}
                      </TableCell>
                      {/* Checkbox */}
                      <TableCell className="text-center">
                        <Checkbox checked={selectedIds.has(reg.id)} onCheckedChange={() => toggleSelect(reg.id)} />
                      </TableCell>
                      {/* Skor Jarak */}
                      <TableCell className="text-sm text-center">
                        {reg.skorJarak || '-'}
                      </TableCell>
                      {/* Skor Nilai Raport — auto from portal, read-only */}
                      <TableCell className="text-sm text-center">
                        <span className="inline-flex items-center gap-1" title="Otomatis dari portal paste">
                          {reg.skorNilaiRaport || reg.nilaiRataRata || '-'}
                          <Globe className="w-3 h-3 text-sky-400 shrink-0" />
                        </span>
                      </TableCell>
                      {/* Kekurangan Verifikasi - auto-height based on content */}
                      <TableCell className="text-sm align-top">
                        <KekuranganVerifSelect
                          value={reg.kekuranganVerifikasi || ''}
                          onChange={(val) => commitEditDirect(reg.id, 'kekuranganVerifikasi', val)}
                        />
                      </TableCell>
                      {/* Tanggal Verif */}
                      <TableCell className="text-sm">
                        {editingCell === `${reg.id}-tanggalVerif` ? (
                          <input
                            type="date"
                            className="w-32 px-1.5 py-0.5 text-sm border border-sky-300 rounded bg-white focus:outline-none focus:ring-1 focus:ring-sky-500"
                            value={editingValue}
                            onChange={(e) => setEditingValue(e.target.value)}
                            onBlur={() => commitEdit(reg.id, 'tanggalVerif')}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') commitEdit(reg.id, 'tanggalVerif')
                              if (e.key === 'Escape') cancelEdit()
                            }}
                            autoFocus
                          />
                        ) : (
                          <span
                            className="cursor-pointer hover:bg-sky-50 px-1 py-0.5 rounded inline-flex items-center gap-1 group"
                            onClick={() => startEditing(reg.id, 'tanggalVerif', reg.tanggalVerif || '')}
                          >
                            {reg.tanggalVerif || '-'}
                            <Pencil className="w-3 h-3 text-gray-300 group-hover:text-sky-500" />
                          </span>
                        )}
                      </TableCell>
                      {/* Jam Verif */}
                      <TableCell className="text-sm">
                        {editingCell === `${reg.id}-jamVerif` ? (
                          <input
                            type="time"
                            className="w-24 px-1.5 py-0.5 text-sm border border-sky-300 rounded bg-white focus:outline-none focus:ring-1 focus:ring-sky-500"
                            value={editingValue}
                            onChange={(e) => setEditingValue(e.target.value)}
                            onBlur={() => commitEdit(reg.id, 'jamVerif')}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') commitEdit(reg.id, 'jamVerif')
                              if (e.key === 'Escape') cancelEdit()
                            }}
                            autoFocus
                          />
                        ) : (
                          <span
                            className="cursor-pointer hover:bg-sky-50 px-1 py-0.5 rounded inline-flex items-center gap-1 group"
                            onClick={() => startEditing(reg.id, 'jamVerif', reg.jamVerif || '')}
                          >
                            {reg.jamVerif || '-'}
                            <Pencil className="w-3 h-3 text-gray-300 group-hover:text-sky-500" />
                          </span>
                        )}
                      </TableCell>
                      {/* Terbit KK */}
                      <TableCell className="text-sm">
                        {editingCell === `${reg.id}-terbitKK` ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="date"
                              className="w-28 px-1.5 py-0.5 text-sm border border-sky-300 rounded bg-white focus:outline-none focus:ring-1 focus:ring-sky-500"
                              value={editingValue}
                              onChange={(e) => {
                                setEditingValue(e.target.value)
                              }}
                              onBlur={() => {
                                // Small delay to allow clear button click to register
                                setTimeout(() => {
                                  if (editingCell === `${reg.id}-terbitKK`) {
                                    commitTerbitKK(reg.id, editingValue)
                                  }
                                }, 150)
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  commitTerbitKK(reg.id, editingValue)
                                }
                                if (e.key === 'Escape') cancelEdit()
                              }}
                              autoFocus
                            />
                            <button
                              type="button"
                              className="p-0.5 rounded hover:bg-red-100 text-gray-400 hover:text-red-500 transition-colors"
                              title="Kosongkan tanggal"
                              onMouseDown={(e) => {
                                e.preventDefault() // Prevent blur from firing on the date input
                                commitTerbitKK(reg.id, '')
                              }}
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span
                            className="cursor-pointer hover:bg-sky-50 px-1 py-0.5 rounded inline-flex items-center gap-1 group"
                            onClick={() => startEditing(reg.id, 'terbitKK', reg.terbitKK || '')}
                          >
                            {reg.terbitKK || '-'}
                            <Pencil className="w-3 h-3 text-gray-300 group-hover:text-sky-500" />
                          </span>
                        )}
                      </TableCell>
                      {/* Lama KK - Auto-calculated from Terbit KK */}
                      <TableCell className="text-sm">
                        <span
                          className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-medium ${
                            !reg.terbitKK ? 'text-gray-400' :
                            isKKKurangSetahun(reg.terbitKK)
                              ? 'bg-red-100 text-red-700 border border-red-200'
                              : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                          }`}
                          title={reg.terbitKK ? `Terbit: ${reg.terbitKK}` : undefined}
                        >
                          {reg.terbitKK ? (
                            <>
                              <CalendarClock className="w-3 h-3" />
                              {reg.lamaKK || hitungLamaKK(reg.terbitKK) || '-'}
                            </>
                          ) : '-'}
                        </span>
                      </TableCell>
                      {/* No. Registrasi */}
                      <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                      {/* Nama Peserta */}
                      <TableCell className="font-medium text-sm">{reg.nama}</TableCell>
                      {/* Asal Sekolah */}
                      <TableCell className="text-sm text-gray-600">{reg.namaSekolahAsal}</TableCell>
                      {/* Status */}
                      <TableCell>
                        <Badge variant="outline" className={STATUS_COLORS[reg.verificationStatus]}>
                          {reg.verificationStatus === 'PENDING' && <Clock className="w-3 h-3" />}
                          {reg.verificationStatus === 'VERIFIED' && <CheckCircle2 className="w-3 h-3" />}
                          {reg.verificationStatus === 'REJECTED' && <XCircle className="w-3 h-3" />}
                          {reg.verificationStatus === 'PENDING' ? 'Menunggu' :
                           reg.verificationStatus === 'VERIFIED' ? 'Diterima' : 'Ditolak'}
                        </Badge>
                      </TableCell>
                      {/* Aksi */}
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="sm" onClick={() => onViewDetail(reg)} title="Lihat Detail">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}>
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-red-600 hover:text-white hover:bg-red-600" title="Hapus Data" onClick={() => openDeleteDialog(reg)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                          {reg.verificationStatus !== 'VERIFIED' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-emerald-600 hover:text-white hover:bg-emerald-600"
                              title="Terima Pendaftar"
                              onClick={() => {
                                setVerifyTargetId(reg.id)
                                setVerifyAction('VERIFIED')
                                setVerifyNote('')
                                setVerifyDialogOpen(true)
                              }}
                            >
                              <ThumbsUp className="w-4 h-4" />
                            </Button>
                          )}
                          {reg.verificationStatus !== 'REJECTED' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-600 hover:text-white hover:bg-red-600"
                              title="Tolak Pendaftar"
                              onClick={() => {
                                setVerifyTargetId(reg.id)
                                setVerifyAction('REJECTED')
                                setVerifyNote('')
                                setVerifyDialogOpen(true)
                              }}
                            >
                              <ThumbsDown className="w-4 h-4" />
                            </Button>
                          )}
                          {reg.verificationStatus === 'VERIFIED' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-yellow-600 hover:text-white hover:bg-yellow-500"
                              title="Kembalikan ke Menunggu"
                              onClick={() => {
                                setVerifyTargetId(reg.id)
                                setVerifyAction('REJECTED')
                                setVerifyNote('')
                                setVerifyDialogOpen(true)
                              }}
                            >
                              <RotateCcw className="w-4 h-4" />
                            </Button>
                          )}
                          {reg.verificationStatus === 'REJECTED' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-emerald-600 hover:text-white hover:bg-emerald-600"
                              title="Terima Ulang"
                              onClick={() => {
                                setVerifyTargetId(reg.id)
                                setVerifyAction('VERIFIED')
                                setVerifyNote('')
                                setVerifyDialogOpen(true)
                              }}
                            >
                              <RotateCcw className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {data && data.pagination.totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t">
              <p className="text-sm text-gray-500">
                Menampilkan {(data.pagination.page - 1) * data.pagination.limit + 1}-
                {Math.min(data.pagination.page * data.pagination.limit, data.pagination.total)} dari {data.pagination.total} pendaftar
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm text-gray-600">Hal {page} / {data.pagination.totalPages}</span>
                <Button variant="outline" size="sm" disabled={page >= data.pagination.totalPages} onClick={() => setPage(p => p + 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Single Verify Dialog */}
      <Dialog open={verifyDialogOpen} onOpenChange={setVerifyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-5 h-5 text-emerald-600" /> Terima Pendaftar</>
              ) : (
                <><ThumbsDown className="w-5 h-5 text-red-600" /> Tolak Pendaftar</>
              )}
            </DialogTitle>
            <DialogDescription>
              {verifyAction === 'VERIFIED'
                ? `Apakah Anda yakin ingin MENERIMA pendaftar ini di jalur ${config.label}?`
                : `Apakah Anda yakin ingin MENOLAK pendaftar ini di jalur ${config.label}?`}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {verifyAction === 'REJECTED' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-red-800">Perhatian!</p>
                    <p className="text-sm text-red-700">Pendaftar yang ditolak tetap dapat diterima kembali nanti.</p>
                  </div>
                </div>
              </div>
            )}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 block">
                {verifyAction === 'VERIFIED' ? 'Catatan Verifikasi' : 'Alasan Penolakan'}
              </label>
              <Textarea
                placeholder={verifyAction === 'VERIFIED' ? 'Catatan tambahan (opsional)...' : 'Tuliskan alasan penolakan...'}
                value={verifyNote}
                onChange={(e) => setVerifyNote(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setVerifyDialogOpen(false)}>Batal</Button>
            <Button
              onClick={handleVerify}
              disabled={verifying}
              className={verifyAction === 'VERIFIED' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              variant={verifyAction === 'REJECTED' ? 'destructive' : 'default'}
            >
              {verifying ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</>
              ) : verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-4 h-4" /> Terima</>
              ) : (
                <><ThumbsDown className="w-4 h-4" /> Tolak</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Verify Dialog */}
      <Dialog open={bulkVerifyDialogOpen} onOpenChange={setBulkVerifyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-5 h-5 text-emerald-600" /> Terima {selectedIds.size} Pendaftar</>
              ) : (
                <><ThumbsDown className="w-5 h-5 text-red-600" /> Tolak {selectedIds.size} Pendaftar</>
              )}
            </DialogTitle>
            <DialogDescription>
              {verifyAction === 'VERIFIED'
                ? `Terima ${selectedIds.size} pendaftar jalur ${config.label} yang dipilih?`
                : `Tolak ${selectedIds.size} pendaftar jalur ${config.label} yang dipilih?`}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {verifyAction === 'REJECTED' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-red-800">Perhatian!</p>
                    <p className="text-sm text-red-700">Pendaftar yang ditolak tetap dapat diterima kembali nanti.</p>
                  </div>
                </div>
              </div>
            )}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 block">
                {verifyAction === 'VERIFIED' ? 'Catatan Verifikasi' : 'Alasan Penolakan'}
              </label>
              <Textarea
                placeholder={verifyAction === 'VERIFIED' ? 'Catatan untuk semua pendaftar (opsional)...' : 'Alasan penolakan untuk semua...'}
                value={verifyNote}
                onChange={(e) => setVerifyNote(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkVerifyDialogOpen(false)}>Batal</Button>
            <Button
              onClick={handleBulkVerify}
              disabled={verifying}
              className={verifyAction === 'VERIFIED' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              variant={verifyAction === 'REJECTED' ? 'destructive' : 'default'}
            >
              {verifying ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</>
              ) : verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-4 h-4" /> Terima Semua</>
              ) : (
                <><ThumbsDown className="w-4 h-4" /> Tolak Semua</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-5 h-5 text-blue-600" /> Edit Data Pendaftar
            </DialogTitle>
            <DialogDescription>
              Edit data pendaftar <span className="font-semibold">{editTarget?.nama}</span> ({editTarget?.noRegistrasi})
            </DialogDescription>
          </DialogHeader>
          {editTarget && (
            <div className="space-y-6">
              {/* Data Pendaftar */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-gray-500" /> Data Pendaftar
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium">No. Registrasi</label>
                    <Input value={editForm.noRegistrasi || ''} onChange={e => setEditForm({...editForm, noRegistrasi: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Nama</label>
                    <Input value={editForm.nama || ''} onChange={e => setEditForm({...editForm, nama: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NISN</label>
                    <Input value={editForm.nisn || ''} onChange={e => setEditForm({...editForm, nisn: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Sub Jalur</label>
                    <Select value={editForm.subJalur || ''} onValueChange={v => setEditForm({...editForm, subJalur: v})}>
                      <SelectTrigger className="mt-1"><SelectValue placeholder="Pilih Sub Jalur" /></SelectTrigger>
                      <SelectContent>
                        {subJalurOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NIK</label>
                    <Input value={editForm.nik || ''} onChange={e => setEditForm({...editForm, nik: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Tanggal Lahir</label>
                    <Input type="date" value={editForm.tanggalLahir || ''} onChange={e => setEditForm({...editForm, tanggalLahir: e.target.value})} className="mt-1" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs text-gray-500 font-medium">Alamat</label>
                    <Input value={editForm.alamat || ''} onChange={e => setEditForm({...editForm, alamat: e.target.value})} className="mt-1" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs text-gray-500 font-medium">Alamat Lengkap</label>
                    <Textarea value={editForm.alamatLengkap || ''} onChange={e => setEditForm({...editForm, alamatLengkap: e.target.value})} className="mt-1" rows={2} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">No. Telp Siswa</label>
                    <Input value={editForm.noTelpSiswa || ''} onChange={e => setEditForm({...editForm, noTelpSiswa: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">No. Telp Orangtua</label>
                    <Input value={editForm.noTelpOrangtua || ''} onChange={e => setEditForm({...editForm, noTelpOrangtua: e.target.value})} className="mt-1" />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Data Sekolah */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <School className="w-4 h-4 text-gray-500" /> Data Sekolah
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NPSN Sekolah Pilihan</label>
                    <Input value={editForm.npsnSekolahPilihan || ''} onChange={e => setEditForm({...editForm, npsnSekolahPilihan: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Nama Sekolah Pilihan</label>
                    <Input value={editForm.namaSekolahPilihan || ''} onChange={e => setEditForm({...editForm, namaSekolahPilihan: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Jurusan</label>
                    <Input value={editForm.jurusan || ''} onChange={e => setEditForm({...editForm, jurusan: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NPSN Sekolah Asal</label>
                    <Input value={editForm.npsnSekolahAsal || ''} onChange={e => setEditForm({...editForm, npsnSekolahAsal: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Nama Sekolah Asal</label>
                    <Input value={editForm.namaSekolahAsal || ''} onChange={e => setEditForm({...editForm, namaSekolahAsal: e.target.value})} className="mt-1" />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Data Verifikasi */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <ClipboardCheck className="w-4 h-4 text-gray-500" /> Data Verifikasi
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Globe className="w-3 h-3 text-sky-400" /> Skor Jarak</label>
                    <Input value={editForm.skorJarak || ''} readOnly className="mt-1 bg-gray-50 text-gray-500 cursor-not-allowed border-dashed" title="Otomatis dari portal paste" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Globe className="w-3 h-3 text-sky-400" /> Skor Nilai Raport</label>
                    <Input value={editForm.skorNilaiRaport || ''} readOnly className="mt-1 bg-gray-50 text-gray-500 cursor-not-allowed border-dashed" title="Otomatis dari portal paste" />
                    <p className="text-[10px] text-sky-500 mt-0.5">↻ Otomatis dari portal paste</p>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs text-gray-500 font-medium">Kekurangan Verifikasi</label>
                    <div className="mt-1">
                      <Select value={editForm.kekuranganVerifikasi || ''} onValueChange={v => setEditForm({...editForm, kekuranganVerifikasi: v === '__none__' ? '' : v})}>
                        <SelectTrigger><SelectValue placeholder="Pilih kekurangan verifikasi" /></SelectTrigger>
                        <SelectContent className="max-h-64">
                          <SelectItem value="__none__">- Tidak Ada -</SelectItem>
                          {KEKURANGAN_VERIFIKASI_DEFAULTS.map(opt => (
                            <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Tanggal Verifikasi</label>
                    <Input type="date" value={editForm.tanggalVerif || ''} onChange={e => setEditForm({...editForm, tanggalVerif: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Jam Verifikasi</label>
                    <Input type="time" value={editForm.jamVerif || ''} onChange={e => setEditForm({...editForm, jamVerif: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Terbit KK</label>
                    <div className="flex items-center gap-1 mt-1">
                      <Input type="date" value={editForm.terbitKK || ''} onChange={e => setEditForm({...editForm, terbitKK: e.target.value})} className="flex-1" />
                      {editForm.terbitKK && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-700 hover:bg-red-50 h-9 px-2"
                          onClick={() => setEditForm({...editForm, terbitKK: ''})}
                          title="Kosongkan"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Lama KK</label>
                    <Input value={editForm.terbitKK ? hitungLamaKK(editForm.terbitKK) : ''} readOnly className="mt-1 bg-gray-50" />
                    <p className="text-xs text-gray-400 mt-1">Dihitung otomatis dari Terbit KK</p>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Data Lokasi & Nilai */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-gray-500" /> Lokasi & Nilai
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Latitude</label>
                    <Input value={editForm.latitude || ''} onChange={e => setEditForm({...editForm, latitude: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Longitude</label>
                    <Input value={editForm.longitude || ''} onChange={e => setEditForm({...editForm, longitude: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Lokasi Jarak</label>
                    <Input value={editForm.lokasiJarak || ''} onChange={e => setEditForm({...editForm, lokasiJarak: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Globe className="w-3 h-3 text-sky-400" /> Nilai Rata-Rata</label>
                    <Input value={editForm.nilaiRataRata || ''} readOnly className="mt-1 bg-gray-50 text-gray-500 cursor-not-allowed border-dashed" title="Otomatis dari portal paste" />
                    <p className="text-[10px] text-sky-500 mt-0.5">↻ Otomatis dari portal paste</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Batal</Button>
            <Button onClick={handleSaveEdit} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
              {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Menyimpan...</> : <><Pencil className="w-4 h-4" /> Simpan</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-600" /> Hapus Data Pendaftar
            </DialogTitle>
            <DialogDescription>
              Apakah Anda yakin ingin menghapus data pendaftar <span className="font-semibold">{deleteTarget?.nama}</span>? Tindakan ini tidak dapat dibatalkan.
            </DialogDescription>
          </DialogHeader>
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <div className="flex gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
              <p className="text-sm text-red-700">Data yang sudah dihapus tidak dapat dikembalikan. Pastikan Anda yakin sebelum melanjutkan.</p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Batal</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? <><Loader2 className="w-4 h-4 animate-spin" /> Menghapus...</> : <><Trash2 className="w-4 h-4" /> Hapus</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default function Home() {
  const { toast } = useToast()

  // ==================== AUTH STATE ====================
  const [authLoading, setAuthLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authUser, setAuthUser] = useState<{ id: string; username: string; namaLengkap: string; role: string } | null>(null)
  const [needsSetup, setNeedsSetup] = useState(false)

  // Login form state
  const [loginUsername, setLoginUsername] = useState('')
  const [loginPassword, setLoginPassword] = useState('')
  const [loginLoading, setLoginLoading] = useState(false)
  const [loginError, setLoginError] = useState('')
  const [showLoginPassword, setShowLoginPassword] = useState(false)

  // Setup form state
  const [setupUsername, setSetupUsername] = useState('')
  const [setupPassword, setSetupPassword] = useState('')
  const [setupNamaLengkap, setSetupNamaLengkap] = useState('')
  const [setupLoading, setSetupLoading] = useState(false)
  const [setupError, setSetupError] = useState('')

  // Check auth on mount — always show login page on refresh
  useEffect(() => {
    let cancelled = false

    const initAuth = async () => {
      try {
        // Always logout on page refresh to force login
        try {
          await fetch('/api/auth/logout', { method: 'POST' })
        } catch { /* ignore logout error */ }

        // Clear any cached auth state
        if (!cancelled) {
          setIsAuthenticated(false)
          setAuthUser(null)
          setLoginUsername('')
          setLoginPassword('')
        }

        // Check if setup is needed
        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 8000)

        const setupRes = await fetch('/api/auth/setup', { signal: controller.signal })
        clearTimeout(timeoutId)

        if (!setupRes.ok) {
          if (!cancelled) setAuthLoading(false)
          return
        }

        const setupData = await setupRes.json()
        if (setupData.needsSetup) {
          if (!cancelled) {
            setNeedsSetup(true)
            setAuthLoading(false)
          }
          return
        }

        // Not authenticated (we already logged out), show login form
      } catch {
        // If API fails (network error, timeout, etc), show login form
      } finally {
        if (!cancelled) setAuthLoading(false)
      }
    }

    initAuth()

    // Safety timeout: force auth loading off after 10 seconds no matter what
    const safetyTimeout = setTimeout(() => {
      if (!cancelled) setAuthLoading(false)
    }, 10000)

    return () => {
      cancelled = true
      clearTimeout(safetyTimeout)
    }
  }, [])

  // Remember username feature removed — fields always empty on login page

  // ==================== MAIN APP STATE (must be before conditional returns) ====================
  const [registrations, setRegistrations] = useState<Registration[]>([])
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [pagination, setPagination] = useState<PaginationInfo>({
    page: 1,
    limit: 15,
    total: 0,
    totalPages: 0,
  })

  // Filters
  const [search, setSearch] = useState('')
  const [subJalurFilter, setSubJalurFilter] = useState('all')
  const [verificationFilter, setVerificationFilter] = useState('all')
  const [jurusanFilter, setJurusanFilter] = useState('all')

  // Selection
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())

  // Dialogs
  const [importDialogOpen, setImportDialogOpen] = useState(false)
  const [verifyDialogOpen, setVerifyDialogOpen] = useState(false)
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)
  const [bulkVerifyDialogOpen, setBulkVerifyDialogOpen] = useState(false)

  // Verify dialog state
  const [verifyAction, setVerifyAction] = useState<'VERIFIED' | 'REJECTED'>('VERIFIED')
  const [verifyNote, setVerifyNote] = useState('')
  const [verifyTargetId, setVerifyTargetId] = useState<string | null>(null)

  // Detail dialog state
  const [detailTarget, setDetailTarget] = useState<Registration | null>(null)

  // Loading states
  const [importing, setImporting] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [loading, setLoading] = useState(false)

  // CSV file
  const [csvFile, setCsvFile] = useState<File | null>(null)

  // Active tab
  const [activeTab, setActiveTab] = useState('dashboard')

  // Lembar verifikasi sub-tab
  const [lembarTab, setLembarTab] = useState('')

  // Edit dialog state (Home component)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<Registration | null>(null)
  const [editForm, setEditForm] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  // Delete dialog state (Home component)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<Registration | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Report filter state
  const [diterimaFilterJalur, setDiterimaFilterJalur] = useState('all')
  const [diterimaFilterSekolah, setDiterimaFilterSekolah] = useState('all')
  const [ditolakFilterJalur, setDitolakFilterJalur] = useState('all')

  // Portal paste state
  const [portalPasteOpen, setPortalPasteOpen] = useState(false)
  const [portalRawText, setPortalRawText] = useState('')
  const [portalParsedData, setPortalParsedData] = useState<Record<string, string> | null>(null)
  const [portalParsing, setPortalParsing] = useState(false)
  const [portalSelectedJalur, setPortalSelectedJalur] = useState('')

  // PWA Install state
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [showInstallBanner, setShowInstallBanner] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)

  // PWA Install prompt listener
  useEffect(() => {
    if (typeof window === 'undefined') return

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true) {
      setIsInstalled(true)
      return
    }

    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)
      // Show install banner after a short delay
      setTimeout(() => setShowInstallBanner(true), 2000)
    }

    window.addEventListener('beforeinstallprompt', handler)

    // Listen for successful install
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true)
      setShowInstallBanner(false)
      setDeferredPrompt(null)
    })

    return () => {
      window.removeEventListener('beforeinstallprompt', handler)
    }
  }, [])

  const handleInstallClick = async () => {
    if (!deferredPrompt) {
      // Fallback: show manual instructions
      toast({
        title: 'Cara Install Aplikasi',
        description: 'Klik ikon ⋮ di Chrome → "Install app" atau "Add to Home Screen"',
      })
      return
    }
    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice
    if (outcome === 'accepted') {
      toast({ title: 'Aplikasi Terinstall!', description: 'SPMB 2026 berhasil ditambahkan ke perangkat Anda' })
    }
    setDeferredPrompt(null)
    setShowInstallBanner(false)
  }

  // Pengaturan state
  const [kuota, setKuota] = useState(0)
  const [jalurConfigs, setJalurConfigs] = useState<Array<{ id: string; nama: string; persentase: number; urutan: number; aktif: boolean }>>([])
  const [settingsLoading, setSettingsLoading] = useState(false)
  const [settingsSaving, setSettingsSaving] = useState(false)
  const [newJalurNama, setNewJalurNama] = useState('')
  const [newJalurPersentase, setNewJalurPersentase] = useState(0)
  const [addJalurOpen, setAddJalurOpen] = useState(false)

  // User management state
  const [users, setUsers] = useState<Array<{id: string; username: string; namaLengkap: string; role: string; aktif: boolean; lastLogin: string | null; createdAt: string}>>([])
  const [usersLoading, setUsersLoading] = useState(false)
  const [addUserOpen, setAddUserOpen] = useState(false)
  const [editUserOpen, setEditUserOpen] = useState(false)
  const [editUserTarget, setEditUserTarget] = useState<{id: string; username: string; namaLengkap: string; role: string; aktif: boolean} | null>(null)
  const [newUserUsername, setNewUserUsername] = useState('')
  const [newUserPassword, setNewUserPassword] = useState('')
  const [newUserNama, setNewUserNama] = useState('')
  const [newUserRole, setNewUserRole] = useState('verifikator')
  const [editUserPassword, setEditUserPassword] = useState('')
  const [savingUser, setSavingUser] = useState(false)

  // Ranking state
  const [rankingJalur, setRankingJalur] = useState('all')
  const [rankingSekolah, setRankingSekolah] = useState('all')
  const [rankingJurusan, setRankingJurusan] = useState('all')
  const [rankingTampilan, setRankingTampilan] = useState('jarak') // jarak | nilai | komposit
  const [rankingStatus, setRankingStatus] = useState('all')
  const [rankingData, setRankingData] = useState<Array<Record<string, unknown>>>([])
  const [rankingFilters, setRankingFilters] = useState<{ jalurOptions: string[]; sekolahOptions: string[]; jurusanOptions: string[] }>({ jalurOptions: [], sekolahOptions: [], jurusanOptions: [] })
  const [rankingKuota, setRankingKuota] = useState(0)
  const [rankingKuotaPerJalur, setRankingKuotaPerJalur] = useState<Array<{ nama: string; persentase: number; kuota: number }>>([])
  const [rankingLoading, setRankingLoading] = useState(false)

  // Kelulusan & Daftar Ulang filter state
  const [lulusFilterJalur, setLulusFilterJalur] = useState('all')
  const [tidakLulusFilterJalur, setTidakLulusFilterJalur] = useState('all')
  const [daftarUlangFilterJalur, setDaftarUlangFilterJalur] = useState('all')
  const [tidakDaftarUlangFilterJalur, setTidakDaftarUlangFilterJalur] = useState('all')

  // Sort state for all tables: 'none' | 'asc' | 'desc'
  const [namaSortDir, setNamaSortDir] = useState<'none' | 'asc' | 'desc'>('none')
  // Show all state for each table section
  const [showAllData, setShowAllData] = useState(false)
  const [showAllLembar, setShowAllLembar] = useState(false)
  const [showAllDiterima, setShowAllDiterima] = useState(false)
  const [showAllDitolak, setShowAllDitolak] = useState(false)
  const [showAllLulus, setShowAllLulus] = useState(false)
  const [showAllTidakLulus, setShowAllTidakLulus] = useState(false)
  const [showAllDaftarUlang, setShowAllDaftarUlang] = useState(false)
  const [showAllTidakDaftarUlang, setShowAllTidakDaftarUlang] = useState(false)
  const [showAllRanking, setShowAllRanking] = useState(false)

  // Sort helper - sort by nama
  const sortByName = (list: Registration[], dir: 'none' | 'asc' | 'desc'): Registration[] => {
    if (dir === 'none') return list
    return [...list].sort((a, b) => {
      const cmp = a.nama.localeCompare(b.nama, 'id')
      return dir === 'asc' ? cmp : -cmp
    })
  }

  // Toggle nama sort
  const toggleNamaSort = () => {
    setNamaSortDir(prev => prev === 'none' ? 'asc' : prev === 'asc' ? 'desc' : 'none')
  }

  // Export PDF helper
  const exportPDF = (title: string, subtitle: string, headers: string[], rows: string[][], filename: string) => {
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' })
    doc.setFontSize(16)
    doc.text(title, doc.internal.pageSize.getWidth() / 2, 15, { align: 'center' })
    doc.setFontSize(10)
    doc.setTextColor(100)
    doc.text(subtitle, doc.internal.pageSize.getWidth() / 2, 22, { align: 'center' })
    doc.text(`Dicetak: ${new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}`, doc.internal.pageSize.getWidth() / 2, 28, { align: 'center' })
    autoTable(doc, {
      head: [headers],
      body: rows,
      startY: 33,
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [22, 163, 74], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [240, 253, 244] },
      margin: { left: 10, right: 10 },
    })
    doc.save(filename)
  }

  // Export Excel helper
  const exportExcel = (title: string, headers: string[], rows: (string | number)[][], filename: string) => {
    const ws = XLSX.utils.aoa_to_sheet([[title], [], headers, ...rows])
    ws['!cols'] = headers.map(() => ({ wch: 18 }))
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, title.substring(0, 31))
    XLSX.writeFile(wb, filename)
  }

  // Preview dialog state
  const [previewOpen, setPreviewOpen] = useState(false)
  const [previewData, setPreviewData] = useState<{
    title: string
    subtitle: string
    headers: string[]
    rows: string[][]
    type: 'diterima' | 'ditolak' | 'lulus' | 'tidak-lulus' | 'daftar-ulang' | 'tidak-daftar-ulang' | 'ranking'
    exportType: 'print' | 'pdf' | 'excel'
    filename: string
  } | null>(null)

  const openPreview = (type: 'diterima' | 'ditolak' | 'lulus' | 'tidak-lulus' | 'daftar-ulang' | 'tidak-daftar-ulang' | 'ranking', exportType: 'print' | 'pdf' | 'excel') => {
    let list: Registration[] = []
    let title = ''
    let subtitle = 'SPMB 2026'
    let filename = ''
    let headers: string[] = []
    let rows: string[][] = []

    if (type === 'ranking') {
      headers = ['No', 'Jalur', 'Nama', 'NISN', 'Sekolah Pilihan', 'Jurusan', 'Jarak', 'Nilai Rata-rata', 'Skor', 'Status']
      rows = rankingData.map((r: Record<string, unknown>, idx: number) => [
        String(idx + 1), (r.subJalur as string) || '-', (r.nama as string) || '-', (r.nisn as string) || '-',
        (r.namaSekolahPilihan as string) || '-', (r.jurusan as string) || '-',
        (r.lokasiJarak as string) || '-', (r.nilaiRataRata as string || r.skorNilaiRaport as string) || '-',
        (r.skor as string) || '-',
        r.verificationStatus === 'VERIFIED' ? 'Diterima' : r.verificationStatus === 'REJECTED' ? 'Ditolak' : 'Menunggu',
      ])
      const jalurLabel = rankingJalur === 'all' ? 'Semua Jalur' : rankingJalur
      title = `PERANGKINGAN ${jalurLabel.toUpperCase()}`
      filename = exportType === 'pdf' ? `Perangkingan_${jalurLabel}.pdf` : `Perangkingan_${jalurLabel}.xlsx`
    } else {
      if (type === 'diterima') { list = stats?.verifiedList || []; title = 'LAPORAN PESERTA DITERIMA'; filename = exportType === 'pdf' ? 'Peserta_Diterima.pdf' : 'Peserta_Diterima.xlsx' }
      else if (type === 'ditolak') { list = stats?.rejectedList || []; title = 'LAPORAN PESERTA DITOLAK'; filename = exportType === 'pdf' ? 'Peserta_Ditolak.pdf' : 'Peserta_Ditolak.xlsx' }
      else if (type === 'lulus') { list = stats?.lulusList || []; title = 'DAFTAR PESERTA LULUS'; filename = exportType === 'pdf' ? 'Peserta_Lulus.pdf' : 'Peserta_Lulus.xlsx' }
      else if (type === 'tidak-lulus') { list = stats?.tidakLulusList || []; title = 'DAFTAR PESERTA TIDAK LULUS'; filename = exportType === 'pdf' ? 'Peserta_Tidak_Lulus.pdf' : 'Peserta_Tidak_Lulus.pdf'; if (exportType !== 'pdf') filename = 'Peserta_Tidak_Lulus.xlsx' }
      else if (type === 'daftar-ulang') { list = stats?.daftarUlangList || []; title = 'DAFTAR PESERTA DAFTAR ULANG'; filename = exportType === 'pdf' ? 'Peserta_Daftar_Ulang.pdf' : 'Peserta_Daftar_Ulang.xlsx' }
      else if (type === 'tidak-daftar-ulang') { list = stats?.tidakDaftarUlangList || []; title = 'DAFTAR PESERTA TIDAK DAFTAR ULANG'; filename = exportType === 'pdf' ? 'Peserta_Tidak_Daftar_Ulang.pdf' : 'Peserta_Tidak_Daftar_Ulang.xlsx' }
      headers = type === 'ditolak'
        ? ['No', 'No. Registrasi', 'Nama', 'NISN', 'Sub Jalur', 'Sekolah Pilihan', 'Jurusan', 'Alasan Penolakan']
        : ['No', 'No. Registrasi', 'Nama', 'NISN', 'Sub Jalur', 'Sekolah Pilihan', 'Jurusan']
      rows = list.map((reg, idx) => type === 'ditolak'
        ? [String(idx + 1), reg.noRegistrasi, reg.nama, reg.nisn, reg.subJalur, reg.namaSekolahPilihan, reg.jurusan, reg.verificationNote || '-']
        : [String(idx + 1), reg.noRegistrasi, reg.nama, reg.nisn, reg.subJalur, reg.namaSekolahPilihan, reg.jurusan]
      )
    }

    setPreviewData({ title, subtitle, headers, rows, type, exportType, filename })
    setPreviewOpen(true)
  }

  const confirmPreview = () => {
    if (!previewData) return
    const { title, subtitle, headers, rows, type, exportType, filename } = previewData
    if (exportType === 'pdf') {
      exportPDF(title, subtitle, headers, rows, filename)
    } else if (exportType === 'excel') {
      const excelRows: (string | number)[][] = rows.map(r => r.map((c, i) => i === 0 ? Number(c) || c : c))
      exportExcel(type === 'ranking' ? title : title.replace('LAPORAN ', '').replace('DAFTAR ', ''), headers, excelRows, filename)
    } else if (exportType === 'print') {
      handlePrintReport(type as 'diterima' | 'ditolak' | 'lulus' | 'tidak-lulus' | 'daftar-ulang' | 'tidak-daftar-ulang')
    }
    setPreviewOpen(false)
    setPreviewData(null)
  }

  // Admin password change state
  const [adminPasswordOpen, setAdminPasswordOpen] = useState(false)
  const [adminPasswordNew, setAdminPasswordNew] = useState('')
  const [adminPasswordConfirm, setAdminPasswordConfirm] = useState('')
  const [adminPasswordSaving, setAdminPasswordSaving] = useState(false)
  const [showAdminPassword, setShowAdminPassword] = useState(false)

  // Build lembar verifikasi from jalurConfigs
  const lembarVerifikasi = buildLembarVerifikasi(jalurConfigs)

  // Available subJalur options for dropdowns
  const subJalurOptions = jalurConfigs
    .filter(j => j.aktif)
    .map(j => {
      const filter = getJalurSubFilter(j.nama)
      return { label: j.nama, value: filter }
    })

  // Auto-set lembarTab to first tab when configs load
  useEffect(() => {
    if (jalurConfigs.length > 0 && !lembarTab) {
      const firstKey = lembarVerifikasi[0]?.key
      if (firstKey) setLembarTab(firstKey)
    }
  }, [jalurConfigs, lembarTab, lembarVerifikasi])

  // Portal Sync state
  const [portalSyncOpen, setPortalSyncOpen] = useState(false)
  const [portalSyncEmail, setPortalSyncEmail] = useState('')
  const [portalSyncPassword, setPortalSyncPassword] = useState('')
  const [portalSyncStatus, setPortalSyncStatus] = useState('accepted')
  const [portalSyncPages, setPortalSyncPages] = useState(10)
  const [portalSyncing, setPortalSyncing] = useState(false)
  const [portalSyncResult, setPortalSyncResult] = useState<{ success: boolean; message: string; created?: number; updated?: number; unchanged?: number; total?: number } | null>(null)

  // ==================== AUTH HANDLERS ====================
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginLoading(true)
    setLoginError('')
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername, password: loginPassword }),
      })
      const data = await res.json()
      if (data.success) {
        setIsAuthenticated(true)
        setAuthUser(data.user)
        // Clear form fields after login
        setLoginPassword('')
        setShowLoginPassword(false)
        setLoginUsername('')
        toast({ title: 'Login Berhasil', description: `Selamat datang, ${data.user.namaLengkap}!` })
      } else {
        setLoginError(data.error || 'Login gagal')
      }
    } catch {
      setLoginError('Terjadi kesalahan koneksi')
    } finally {
      setLoginLoading(false)
    }
  }

  const handleSetup = async (e: React.FormEvent) => {
    e.preventDefault()
    setSetupLoading(true)
    setSetupError('')
    try {
      const res = await fetch('/api/auth/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: setupUsername, password: setupPassword, namaLengkap: setupNamaLengkap }),
      })
      const data = await res.json()
      if (data.success) {
        setNeedsSetup(false)
        const loginRes = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: setupUsername, password: setupPassword }),
        })
        const loginData = await loginRes.json()
        if (loginData.success) {
          setIsAuthenticated(true)
          setAuthUser(loginData.user)
          toast({ title: 'Setup Berhasil', description: `Akun admin berhasil dibuat. Selamat datang, ${loginData.user.namaLengkap}!` })
        }
        setSetupUsername('')
        setSetupPassword('')
        setSetupNamaLengkap('')
      } else {
        setSetupError(data.error || 'Setup gagal')
      }
    } catch {
      setSetupError('Terjadi kesalahan koneksi')
    } finally {
      setSetupLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      setIsAuthenticated(false)
      setAuthUser(null)
      setLoginUsername('')
      setLoginPassword('')
      setShowLoginPassword(false)
      toast({ title: 'Logout Berhasil', description: 'Anda telah keluar dari sistem' })
    } catch {
      toast({ title: 'Gagal Logout', description: 'Terjadi kesalahan', variant: 'destructive' })
    }
  }

  // ==================== DATA FETCHING HOOKS (must be before conditional returns) ====================
  const fetchRegistrations = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('page', pagination.page.toString())
      params.set('limit', pagination.limit.toString())
      if (search) params.set('search', search)
      if (subJalurFilter !== 'all') params.set('subJalur', subJalurFilter)
      if (verificationFilter !== 'all') params.set('verificationStatus', verificationFilter)
      if (jurusanFilter !== 'all') params.set('jurusan', jurusanFilter)

      const res = await fetch(`/api/registrations?${params}`)
      const data = await res.json()
      setRegistrations(data.data || [])
      setPagination(prev => ({ ...prev, ...data.pagination }))
    } catch {
      toast({ title: 'Error', description: 'Gagal memuat data pendaftar', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [pagination.page, pagination.limit, search, subJalurFilter, verificationFilter, jurusanFilter, toast])

  const fetchStats = useCallback(async () => {
    try {
      const res = await fetch('/api/dashboard')
      const data = await res.json()
      setStats(data)
    } catch {
      toast({ title: 'Error', description: 'Gagal memuat statistik', variant: 'destructive' })
    }
  }, [toast])

  const fetchSettings = useCallback(async () => {
    setSettingsLoading(true)
    try {
      const res = await fetch('/api/settings')
      const data = await res.json()
      setKuota(data.kuota || 0)
      setJalurConfigs(data.jalurConfigs || [])
    } catch {
      toast({ title: 'Error', description: 'Gagal memuat pengaturan', variant: 'destructive' })
    } finally {
      setSettingsLoading(false)
    }
  }, [toast])

  const fetchUsers = useCallback(async () => {
    setUsersLoading(true)
    try {
      const res = await fetch('/api/users')
      if (res.ok) {
        const data = await res.json()
        setUsers(data.users || [])
      }
    } catch {
      // ignore
    } finally {
      setUsersLoading(false)
    }
  }, [])

  const handleAddUser = async () => {
    if (!newUserUsername.trim() || !newUserPassword.trim() || !newUserNama.trim()) {
      toast({ title: 'Gagal', description: 'Semua field wajib diisi', variant: 'destructive' })
      return
    }
    setSavingUser(true)
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: newUserUsername.trim(), password: newUserPassword, namaLengkap: newUserNama.trim(), role: newUserRole }),
      })
      const data = await res.json()
      if (res.ok) {
        toast({ title: 'Berhasil', description: `Pengguna ${newUserNama} berhasil ditambahkan` })
        setAddUserOpen(false)
        setNewUserUsername(''); setNewUserPassword(''); setNewUserNama(''); setNewUserRole('verifikator')
        fetchUsers()
      } else {
        toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setSavingUser(false)
    }
  }

  const handleEditUser = async () => {
    if (!editUserTarget) return
    setSavingUser(true)
    try {
      const body: Record<string, unknown> = {
        id: editUserTarget.id,
        username: editUserTarget.username,
        namaLengkap: editUserTarget.namaLengkap,
        role: editUserTarget.role,
        aktif: editUserTarget.aktif,
      }
      if (editUserPassword.trim()) body.password = editUserPassword
      const res = await fetch('/api/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      const data = await res.json()
      if (res.ok) {
        toast({ title: 'Berhasil', description: 'Data pengguna berhasil diperbarui' })
        setEditUserOpen(false); setEditUserTarget(null); setEditUserPassword('')
        fetchUsers()
      } else {
        toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setSavingUser(false)
    }
  }

  const handleDeleteUser = async (id: string, nama: string) => {
    if (!confirm(`Hapus pengguna "${nama}"?`)) return
    try {
      const res = await fetch(`/api/users?id=${id}`, { method: 'DELETE' })
      const data = await res.json()
      if (res.ok) {
        toast({ title: 'Berhasil', description: `Pengguna ${nama} berhasil dihapus` })
        fetchUsers()
      } else {
        toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    }
  }

  const handleToggleUserAktif = async (id: string, currentAktif: boolean, nama: string) => {
    try {
      const res = await fetch('/api/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, aktif: !currentAktif }),
      })
      if (res.ok) {
        toast({ title: 'Berhasil', description: `${nama} ${!currentAktif ? 'diaktifkan' : 'dinonaktifkan'}` })
        fetchUsers()
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    }
  }

  // Update kelulusan status (LULUS/TIDAK_LULUS) for a student
  const handleUpdateKelulusan = async (regId: string, status: string) => {
    try {
      const res = await fetch(`/api/registrations/${regId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ field: 'statusKelulusan', value: status }),
      })
      const result = await res.json()
      if (result.success) {
        toast({ title: 'Berhasil', description: `Status kelulusan diperbarui` })
        fetchStats()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal memperbarui', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    }
  }

  // Update daftar ulang status for a student
  const handleUpdateDaftarUlang = async (regId: string, status: string) => {
    try {
      const res = await fetch(`/api/registrations/${regId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ field: 'statusDaftarUlang', value: status }),
      })
      const result = await res.json()
      if (result.success) {
        toast({ title: 'Berhasil', description: `Status daftar ulang diperbarui` })
        fetchStats()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal memperbarui', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    }
  }

  // Admin change own password
  const handleAdminChangePassword = async () => {
    if (!adminPasswordNew || adminPasswordNew.length < 6) {
      toast({ title: 'Gagal', description: 'Password minimal 6 karakter', variant: 'destructive' })
      return
    }
    if (adminPasswordNew !== adminPasswordConfirm) {
      toast({ title: 'Gagal', description: 'Konfirmasi password tidak cocok', variant: 'destructive' })
      return
    }
    setAdminPasswordSaving(true)
    try {
      const res = await fetch('/api/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: authUser?.id, password: adminPasswordNew }),
      })
      const data = await res.json()
      if (res.ok) {
        toast({ title: 'Berhasil', description: 'Password berhasil diubah' })
        setAdminPasswordOpen(false)
        setAdminPasswordNew('')
        setAdminPasswordConfirm('')
        setShowAdminPassword(false)
      } else {
        toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setAdminPasswordSaving(false)
    }
  }

  useEffect(() => {
    if (isAuthenticated) fetchRegistrations()
  }, [fetchRegistrations, isAuthenticated])

  useEffect(() => {
    if (isAuthenticated) fetchStats()
  }, [fetchStats, isAuthenticated])

  useEffect(() => {
    if (isAuthenticated) {
      fetchSettings()
      fetchUsers()
    }
  }, [fetchSettings, fetchUsers, isAuthenticated])

  // Fetch ranking data
  const fetchRanking = useCallback(async () => {
    setRankingLoading(true)
    try {
      const params = new URLSearchParams()
      if (rankingJalur !== 'all') params.set('jalur', rankingJalur)
      if (rankingSekolah !== 'all') params.set('sekolah', rankingSekolah)
      if (rankingJurusan !== 'all') params.set('jurusan', rankingJurusan)
      params.set('tampilan', rankingTampilan)
      if (rankingStatus !== 'all') params.set('status', rankingStatus)

      const res = await fetch(`/api/ranking?${params}`)
      const data = await res.json()
      if (data.success) {
        setRankingData(data.data || [])
        setRankingFilters(data.filters || { jalurOptions: [], sekolahOptions: [], jurusanOptions: [] })
        setRankingKuota(data.kuota || 0)
        setRankingKuotaPerJalur(data.kuotaPerJalur || [])
      }
    } catch {
      toast({ title: 'Error', description: 'Gagal memuat data perangkingan', variant: 'destructive' })
    } finally {
      setRankingLoading(false)
    }
  }, [rankingJalur, rankingSekolah, rankingJurusan, rankingTampilan, rankingStatus, toast])

  useEffect(() => {
    if (isAuthenticated) fetchRanking()
  }, [fetchRanking, isAuthenticated])

  // ==================== CONDITIONAL RENDERS ====================
  // Auth loading screen
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-600/20 flex items-center justify-center animate-pulse">
            <ShieldCheck className="w-8 h-8 text-emerald-400" />
          </div>
          <p className="text-emerald-200 text-sm mb-3">Memuat sistem...</p>
          <p className="text-emerald-200/40 text-xs">Jika halaman tidak memuat, coba refresh</p>
        </div>
      </div>
    )
  }

  // ==================== SETUP SCREEN (First Time) ====================
  if (needsSetup) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900 p-4">
        <div className="w-full max-w-md">
          {/* Logo & Title */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-2xl shadow-emerald-500/30">
              <ShieldCheck className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">SPMB 2026</h1>
            <p className="text-emerald-200/80 text-sm">Sistem Verifikasi Penerimaan Peserta Didik Baru</p>
            <div className="mt-4 inline-flex items-center gap-2 bg-amber-500/20 border border-amber-400/30 rounded-full px-4 py-1.5">
              <AlertCircle className="w-4 h-4 text-amber-300" />
              <span className="text-amber-200 text-xs font-medium">Pengaturan Awal — Buat Akun Admin</span>
            </div>
          </div>

          {/* Setup Form */}
          <Card className="bg-white/10 backdrop-blur-xl border-white/20 shadow-2xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-white text-lg">Buat Akun Administrator</CardTitle>
              <CardDescription className="text-emerald-200/60 text-xs">
                Ini adalah akun pertama yang akan digunakan untuk mengelola sistem verifikasi SPMB 2026.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSetup} className="space-y-4">
                {setupError && (
                  <div className="bg-red-500/20 border border-red-400/30 rounded-lg p-3 flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-red-300 shrink-0" />
                    <p className="text-red-200 text-sm">{setupError}</p>
                  </div>
                )}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-emerald-100">Nama Lengkap</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-300/50" />
                    <Input
                      value={setupNamaLengkap}
                      onChange={(e) => setSetupNamaLengkap(e.target.value)}
                      placeholder="Nama lengkap Anda"
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-emerald-200/40 focus:border-emerald-400/50 focus:ring-emerald-400/30"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-emerald-100">Username</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-300/50" />
                    <Input
                      value={setupUsername}
                      onChange={(e) => setSetupUsername(e.target.value)}
                      placeholder="Username untuk login"
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-emerald-200/40 focus:border-emerald-400/50 focus:ring-emerald-400/30"
                      required
                      minLength={3}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-emerald-100">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-300/50" />
                    <Input
                      type="password"
                      value={setupPassword}
                      onChange={(e) => setSetupPassword(e.target.value)}
                      placeholder="Minimal 6 karakter"
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-emerald-200/40 focus:border-emerald-400/50 focus:ring-emerald-400/30"
                      required
                      minLength={6}
                    />
                  </div>
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg shadow-emerald-500/30 h-11"
                  disabled={setupLoading}
                >
                  {setupLoading ? (
                    <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Membuat Akun...</>
                  ) : (
                    <><Save className="w-4 h-4 mr-2" /> Buat Akun & Mulai</>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // ==================== LOGIN SCREEN ====================
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-emerald-900 to-slate-900 p-4 relative overflow-hidden">
        {/* Background decorations */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl" />
        </div>

        <div className="w-full max-w-md relative z-10">
          {/* Logo & Title */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-2xl shadow-emerald-500/30 animate-in fade-in zoom-in duration-500">
              <ShieldCheck className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">SPMB 2026</h1>
            <p className="text-emerald-200/80 text-sm">Sistem Verifikasi Penerimaan Peserta Didik Baru</p>
          </div>

          {/* Login Form */}
          <Card className="bg-white/10 backdrop-blur-xl border-white/20 shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
            <CardHeader className="pb-4">
              <CardTitle className="text-white text-lg flex items-center gap-2">
                <Lock className="w-5 h-5 text-emerald-400" />
                Masuk ke Sistem
              </CardTitle>
              <CardDescription className="text-emerald-200/60 text-xs">
                Masukkan username dan password untuk mengakses sistem verifikasi.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4" autoComplete="off">
                {loginError && (
                  <div className="bg-red-500/20 border border-red-400/30 rounded-lg p-3 flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-300">
                    <XCircle className="w-4 h-4 text-red-300 shrink-0" />
                    <p className="text-red-200 text-sm">{loginError}</p>
                  </div>
                )}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-emerald-100">Username</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-300/50" />
                    <Input
                      value={loginUsername}
                      onChange={(e) => setLoginUsername(e.target.value)}
                      placeholder="Masukkan username"
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-emerald-200/40 focus:border-emerald-400/50 focus:ring-emerald-400/30"
                      required
                      autoFocus
                      autoComplete="new-password"
                      data-1p-ignore
                      data-lpignore="true"
                      name="_spmb_usr_x9k2"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-emerald-100">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-300/50" />
                    <Input
                      type={showLoginPassword ? 'text' : 'password'}
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Masukkan password"
                      className="pl-10 pr-10 bg-white/10 border-white/20 text-white placeholder:text-emerald-200/40 focus:border-emerald-400/50 focus:ring-emerald-400/30"
                      required
                      autoComplete="new-password"
                      data-1p-ignore
                      data-lpignore="true"
                      name="_spmb_pwd_m4q7"
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-emerald-300/50 hover:text-emerald-300 transition-colors"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      tabIndex={-1}
                    >
                      {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg shadow-emerald-500/30 h-11 transition-all duration-200 hover:shadow-emerald-500/40"
                  disabled={loginLoading}
                >
                  {loginLoading ? (
                    <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Memproses...</>
                  ) : (
                    <><Lock className="w-4 h-4 mr-2" /> Masuk</>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Footer */}
          <div className="mt-6 space-y-3">
            {/* PWA Install Button on Login Page */}
            {!isInstalled && (
              <button
                onClick={handleInstallClick}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-white/10 hover:bg-white/15 border border-white/20 text-emerald-200 hover:text-white transition-all duration-200 text-sm"
              >
                <Download className="w-4 h-4" />
                Install Aplikasi di Perangkat Ini
              </button>
            )}
            <p className="text-center text-emerald-200/40 text-xs">
              © 2026 SPMB Verifikasi System
            </p>
          </div>
        </div>
      </div>
    )
  }

  // Portal SPMB text parser
  const parsePortalText = (text: string): Record<string, string> => {
    const result: Record<string, string> = {}
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean)

    // Helper: find value after a label line
    const findValueAfter = (label: string, startFrom = 0): { value: string; index: number } | null => {
      for (let i = startFrom; i < lines.length; i++) {
        if (lines[i].toLowerCase().includes(label.toLowerCase())) {
          // Check if value is on same line after ":"
          const colonIdx = lines[i].indexOf(':')
          if (colonIdx !== -1 && lines[i].length > colonIdx + 1) {
            return { value: lines[i].substring(colonIdx + 1).trim(), index: i }
          }
          // Value is on the next line
          if (i + 1 < lines.length) {
            return { value: lines[i + 1].trim(), index: i + 1 }
          }
        }
      }
      return null
    }

    // Helper: find value for a label that's on its own line
    const findNextLine = (label: string): string => {
      const found = findValueAfter(label)
      return found?.value || ''
    }

    // No. Registrasi - from "No. Registrasi:" pattern
    const noRegMatch = text.match(/No\.\s*Registrasi\s*:\s*(\S+)/i)
    if (noRegMatch) result['noRegistrasi'] = noRegMatch[1]

    // Sub Jalur - detect from the text using dynamic jalur from Pengaturan
    // Build detection list from jalurConfigs (active jalur names + their subJalur mappings)
    const activeJalurNames = jalurConfigs.filter(j => j.aktif).map(j => j.nama)
    // Also include common aliases that might appear in portal text
    const portalAliases: Record<string, string> = {
      'Afirmasi': 'Afirmasi (KTM)',
      'Keluarga Tidak Mampu': 'Afirmasi (KTM)',
      'KTM': 'Afirmasi (KTM)',
      'Penyandang Disabilitas': 'Disabilitas',
      'Mutasi Orang tua/ Wali': 'Mutasi',
      'Perpindahan Orang Tua': 'Mutasi',
      'Prestasi Akademik': 'Prestasi Nilai Rapor',
      'Prestasi Nonakademik': 'Prestasi Non Akademik',
      'Non Akademik': 'Prestasi Non Akademik',
      'Terdampak Bencana Alam': 'Terdampak Bencana Alam',
    }
    // Combine: active jalur names + their known aliases (only if alias maps to an active jalur)
    const allDetectableNames = new Set<string>()
    for (const name of activeJalurNames) {
      allDetectableNames.add(name)
    }
    for (const [alias, targetJalur] of Object.entries(portalAliases)) {
      if (activeJalurNames.includes(targetJalur)) {
        allDetectableNames.add(alias)
      }
    }
    // Try to detect jalur name from pasted text
    for (const jalur of allDetectableNames) {
      for (const line of lines) {
        if (line === jalur || line.toLowerCase() === jalur.toLowerCase()) {
          // Map alias to actual jalur config name, then to subJalur filter
          const jalurConfigName = portalAliases[jalur] || jalur
          result['subJalur'] = getJalurSubFilter(jalurConfigName)
          result['_detectedJalurNama'] = jalurConfigName // store the jalur config name for dropdown
          break
        }
      }
      if (result['subJalur']) break
    }

    // Nama - after "Nama Peserta"
    result['nama'] = findNextLine('Nama Peserta')
    // Fallback: first line might be the name
    if (!result['nama'] && lines.length > 0) {
      // Check if first line looks like a name (not starting with a number or known label)
      const firstLine = lines[0]
      if (firstLine && !firstLine.match(/^\d/) && !firstLine.toLowerCase().includes('no.') && !firstLine.toLowerCase().includes('registrasi')) {
        result['nama'] = firstLine
      }
    }

    // Tanggal Lahir
    result['tanggalLahir'] = findNextLine('Tanggal Lahir')

    // NIK
    result['nik'] = findNextLine('NIK')

    // NISN
    result['nisn'] = findNextLine('NISN')

    // Alamat
    result['alamat'] = findNextLine('Alamat')
    // But "Alamat Lengkap" should be separate - handle that
    const alamatLengkap = findNextLine('Alamat Lengkap')
    if (alamatLengkap) {
      result['alamatLengkap'] = alamatLengkap
    }

    // Phone numbers
    result['noTelpSiswa'] = findNextLine('No.Telp/Hp Siswa') || findNextLine('No. Telp/Hp Siswa') || findNextLine('NoTelp/Hp Siswa')
    result['noTelpOrangtua'] = findNextLine('No.Telp/Hp Orangtua') || findNextLine('No. Telp/Hp Orangtua') || findNextLine('NoTelp/Hp Orangtua/Wali')

    // Asal Sekolah
    result['namaSekolahAsal'] = findNextLine('Asal Sekolah')

    // Sekolah Pilihan
    result['namaSekolahPilihan'] = findNextLine('Sekolah Pilihan')

    // Waktu Pendaftaran
    result['waktuDaftar'] = findNextLine('Waktu Pendaftaran')

    // Lokasi dan Jarak
    result['lokasiJarak'] = findNextLine('Lokasi dan Jarak')

    // Latitude / Longitude
    result['latitude'] = findNextLine('Latitude')
    result['longitude'] = findNextLine('Longitude')

    // Nilai Rapor - parse subject grades
    const subjects = ['Pendidikan Agama', 'PPKn', 'Bahasa Indonesia', 'Matematika', 'Ilmu Pengetahuan Alam', 'Ilmu Pengetahuan Sosial', 'Bahasa Inggris']
    const grades: Record<string, string> = {}
    for (const subject of subjects) {
      // Find pattern: "Subject\n: value" or "Subject : value"
      for (let i = 0; i < lines.length; i++) {
        if (lines[i] === subject || lines[i].startsWith(subject)) {
          // Check if value is on same line after ":"
          if (lines[i].includes(':')) {
            const val = lines[i].split(':').pop()?.trim()
            if (val && val.match(/\d+/)) {
              grades[subject] = val
              break
            }
          }
          // Check next line for ": value"
          if (i + 1 < lines.length) {
            const nextLine = lines[i + 1]
            const match = nextLine.match(/:\s*(\d+[\.,]?\d*)/)
            if (match) {
              grades[subject] = match[1]
              break
            }
          }
        }
      }
    }
    if (Object.keys(grades).length > 0) {
      result['nilaiRapor'] = JSON.stringify(grades)
    }

    // Nilai Rata-rata - from the Ringkasan Informasi section (2nd occurrence)
    // The portal has TWO "Nilai Rata-rata": 
    // 1st = average of semester rapor grades (e.g. 88.857)
    // 2nd = normalized score in Ringkasan (e.g. 90.143) — THIS is what we want
    let nilaiRataRataFound = false
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].toLowerCase().includes('nilai rata-rata')) {
        if (!nilaiRataRataFound) {
          // Skip the first occurrence (from rapor section)
          nilaiRataRataFound = true
          continue
        }
        // This is the second occurrence (from Ringkasan Informasi)
        // Check same line for value
        const colonIdx = lines[i].indexOf(':')
        if (colonIdx !== -1 && lines[i].length > colonIdx + 1) {
          const val = lines[i].substring(colonIdx + 1).trim()
          const match = val.match(/([\d]+[\.,]?[\d]*)/)
          if (match) {
            result['nilaiRataRata'] = match[1]
            break
          }
        }
        // Check next lines for value (skip empty lines)
        for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
          const nextVal = lines[j].trim()
          if (!nextVal) continue // skip empty lines
          const match = nextVal.match(/([\d]+[\.,]?[\d]*)/)
          if (match) {
            result['nilaiRataRata'] = match[1]
            break
          }
          // If we hit a non-empty, non-number line, stop looking
          break
        }
        if (result['nilaiRataRata']) break
      }
    }
    // Fallback: if no 2nd occurrence found, use the 1st one
    if (!result['nilaiRataRata']) {
      const firstNilai = findNextLine('Nilai Rata-rata')
      if (firstNilai) {
        const match = firstNilai.match(/([\d]+[\.,]?[\d]*)/)
        result['nilaiRataRata'] = match ? match[1] : firstNilai
      }
    }

    // Skor Jarak (from Ringkasan section)
    const skorJarak = findNextLine('Skor Jarak')
    if (skorJarak) result['skorJarak'] = skorJarak

    // Skor (from Ringkasan section) - need to find the LAST "Skor" line
    for (let i = lines.length - 1; i >= 0; i--) {
      if (lines[i].trim() === 'Skor') {
        // Check next lines for value (skip empty lines)
        for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
          const nextVal = lines[j].trim()
          if (!nextVal) continue
          const match = nextVal.match(/([\d]+[\.,]?[\d]*)/)
          if (match) {
            result['skor'] = match[1]
            break
          }
          break
        }
        if (result['skor']) break
      }
    }

    // Skor Nilai Raport - from "Skor Nilai Raport" or derive from nilaiRataRata
    const skorNilaiRaport = findNextLine('Skor Nilai Raport')
    if (skorNilaiRaport) {
      const match = skorNilaiRaport.match(/([\d]+[\.,]?[\d]*)/)
      result['skorNilaiRaport'] = match ? match[1] : skorNilaiRaport
    } else if (result['nilaiRataRata']) {
      // If no explicit Skor Nilai Raport, use nilaiRataRata as fallback
      result['skorNilaiRaport'] = result['nilaiRataRata']
    }

    // Dokumen - parse from "Dokumen" section
    const dokumenSection = findNextLine('Dokumen')
    if (dokumenSection) {
      result['dokumen'] = dokumenSection
    }

    // NPSN - we don't have this from portal, use empty
    result['npsnSekolahPilihan'] = ''
    result['npsnSekolahAsal'] = ''
    result['jurusan'] = ''
    result['status'] = 'ON PROGRESS'

    return result
  }

  const handlePortalPaste = () => {
    if (!portalRawText.trim()) return
    setPortalParsing(true)
    try {
      const parsed = parsePortalText(portalRawText)
      setPortalParsedData(parsed)
      // Initialize selected jalur from detected jalur or first active jalur
      const detectedJalur = parsed['_detectedJalurNama'] || ''
      if (detectedJalur) {
        setPortalSelectedJalur(detectedJalur)
      } else {
        // Default to first active jalur
        const firstActive = jalurConfigs.find(j => j.aktif)
        setPortalSelectedJalur(firstActive?.nama || '')
      }
    } catch {
      toast({ title: 'Gagal', description: 'Tidak dapat memparse teks portal', variant: 'destructive' })
    } finally {
      setPortalParsing(false)
    }
  }

  const handlePortalSave = async () => {
    if (!portalParsedData) return
    setImporting(true)
    try {
      // Use the selected jalur from dropdown (overrides auto-detected subJalur)
      const saveData = { ...portalParsedData }
      if (portalSelectedJalur) {
        saveData['subJalur'] = getJalurSubFilter(portalSelectedJalur)
      }
      // Remove internal temp fields before sending
      delete saveData['_detectedJalurNama']

      const res = await fetch('/api/registrations/portal-paste', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(saveData),
      })
      const data = await res.json()
      if (data.success) {
        const nisnLabel = portalParsedData.nisn ? ` (NISN: ${portalParsedData.nisn})` : ''
        if (data.action === 'created') {
          toast({
            title: '✅ Data Baru Disimpan',
            description: data.message || `Data ${portalParsedData.nama || 'pendaftar'}${nisnLabel} berhasil ditambahkan sebagai data baru`,
          })
        } else if (data.action === 'updated') {
          toast({
            title: '🔄 Data Diperbarui',
            description: data.message || `Data ${portalParsedData.nama || 'pendaftar'}${nisnLabel} berhasil diperbarui — field kosong telah diisi`,
          })
        } else {
          toast({
            title: 'ℹ️ Data Sudah Lengkap',
            description: data.message || `Data ${portalParsedData.nama || 'pendaftar'}${nisnLabel} sudah lengkap, tidak ada perubahan`,
          })
        }
        setPortalPasteOpen(false)
        setPortalRawText('')
        setPortalParsedData(null)
        setPortalSelectedJalur('')
        fetchRegistrations()
        fetchStats()
      } else {
        toast({ title: 'Gagal', description: data.error || 'Terjadi kesalahan', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setImporting(false)
    }
  }

  // Save kuota
  const saveKuota = async () => {
    setSettingsSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kuota }),
      })
      const data = await res.json()
      if (data.success) {
        toast({ title: 'Tersimpan', description: `Kuota siswa: ${kuota}` })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Gagal menyimpan kuota', variant: 'destructive' })
    } finally {
      setSettingsSaving(false)
    }
  }

  // Update jalur persentase
  const updateJalurPersentase = async (id: string, persentase: number) => {
    try {
      const res = await fetch('/api/settings/jalur', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, persentase }),
      })
      const data = await res.json()
      if (data.success) {
        setJalurConfigs(prev => prev.map(j => j.id === id ? { ...j, persentase } : j))
      }
    } catch {
      toast({ title: 'Gagal', description: 'Gagal memperbarui persentase', variant: 'destructive' })
    }
  }

  // Add new jalur
  const addJalur = async () => {
    if (!newJalurNama.trim()) {
      toast({ title: 'Gagal', description: 'Nama jalur wajib diisi', variant: 'destructive' })
      return
    }
    try {
      const res = await fetch('/api/settings/jalur', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nama: newJalurNama.trim(), persentase: newJalurPersentase }),
      })
      const data = await res.json()
      if (data.success) {
        setJalurConfigs(prev => [...prev, data.data])
        setNewJalurNama('')
        setNewJalurPersentase(0)
        setAddJalurOpen(false)
        toast({ title: 'Berhasil', description: `Jalur "${data.data.nama}" berhasil ditambahkan` })
      } else {
        toast({ title: 'Gagal', description: data.error || 'Gagal menambah jalur', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Gagal menambah jalur', variant: 'destructive' })
    }
  }

  // Delete jalur
  const deleteJalur = async (id: string, nama: string) => {
    if (!confirm(`Hapus jalur "${nama}"?`)) return
    try {
      const res = await fetch(`/api/settings/jalur?id=${id}`, { method: 'DELETE' })
      const data = await res.json()
      if (data.success) {
        setJalurConfigs(prev => prev.filter(j => j.id !== id))
        toast({ title: 'Berhasil', description: data.message })
      } else {
        toast({ title: 'Gagal', description: data.error || 'Gagal menghapus jalur', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Gagal menghapus jalur', variant: 'destructive' })
    }
  }

  // Toggle jalur aktif
  const toggleJalurAktif = async (id: string, aktif: boolean) => {
    try {
      const res = await fetch('/api/settings/jalur', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, aktif }),
      })
      const data = await res.json()
      if (data.success) {
        setJalurConfigs(prev => prev.map(j => j.id === id ? { ...j, aktif } : j))
      }
    } catch {
      toast({ title: 'Gagal', description: 'Gagal mengubah status jalur', variant: 'destructive' })
    }
  }

  // Portal Sync function
  const handlePortalSync = async () => {
    if (!portalSyncEmail.trim() || !portalSyncPassword.trim()) {
      toast({ title: 'Gagal', description: 'Email dan password portal wajib diisi', variant: 'destructive' })
      return
    }
    setPortalSyncing(true)
    setPortalSyncResult(null)
    try {
      const res = await fetch('/api/portal-sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: portalSyncEmail.trim(),
          password: portalSyncPassword,
          pages: portalSyncPages,
          status: portalSyncStatus,
        }),
      })
      const data = await res.json()
      if (data.error) {
        setPortalSyncResult({ success: false, message: data.error })
        toast({ title: 'Gagal', description: data.error, variant: 'destructive' })
      } else {
        setPortalSyncResult({
          success: true,
          message: data.message,
          created: data.created,
          updated: data.updated,
          unchanged: data.unchanged,
          total: data.total,
        })
        toast({
          title: '✅ Sinkronisasi Berhasil',
          description: data.message,
        })
        fetchRegistrations()
        fetchStats()
      }
    } catch {
      const errMsg = 'Terjadi kesalahan saat sinkronisasi'
      setPortalSyncResult({ success: false, message: errMsg })
      toast({ title: 'Gagal', description: errMsg, variant: 'destructive' })
    } finally {
      setPortalSyncing(false)
    }
  }

  const parseCSVClientSide = (text: string) => {
    const lines = text.trim().split('\n')
    if (lines.length < 2) return []

    const headers = lines[0].split(',').map(h => h.replace(/^"|"$/g, '').trim())
    const rows: Record<string, string>[] = []

    for (let i = 1; i < lines.length; i++) {
      const values: string[] = []
      let current = ''
      let inQuotes = false

      for (const char of lines[i]) {
        if (char === '"') {
          inQuotes = !inQuotes
        } else if (char === ',' && !inQuotes) {
          values.push(current.trim())
          current = ''
        } else {
          current += char
        }
      }
      values.push(current.trim())

      if (values.length === headers.length) {
        const row: Record<string, string> = {}
        headers.forEach((header, index) => {
          row[header] = values[index] || ''
        })
        rows.push(row)
      }
    }

    return rows
  }

  const handleImport = async () => {
    if (!csvFile) return

    setImporting(true)
    try {
      const text = await csvFile.text()
      const csvRows = parseCSVClientSide(text)

      if (csvRows.length === 0) {
        throw new Error('File CSV kosong atau format tidak valid')
      }

      const mappedRows = csvRows.map(row => ({
        noRegistrasi: row['No.Registrasi'] || '',
        nama: row['Nama'] || '',
        nisn: row['NISN'] || '',
        subJalur: row['Sub Jalur'] || '',
        npsnSekolahPilihan: row['NPSN Sekolah Pilihan'] || '',
        namaSekolahPilihan: row['Nama Sekolah Pilihan'] || '',
        jurusan: row['Jurusan'] || '',
        npsnSekolahAsal: row['NPSN Sekolah Asal'] || '',
        namaSekolahAsal: row['Nama Sekolah Asal'] || '',
        status: row['Status'] || 'ON PROGRESS',
        waktuDaftar: row['Waktu Daftar'] || '',
      }))

      const importRes = await fetch('/api/registrations/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows: mappedRows }),
      })

      const importData = await importRes.json()

      if (importData.success) {
        const createdCount = importData.created || 0
        const updatedCount = importData.updated || 0
        const skippedCount = importData.skipped || 0
        toast({
          title: 'Import Berhasil',
          description: `${createdCount} data baru, ${updatedCount} data diperbarui, ${skippedCount} dilewati`,
        })
        setImportDialogOpen(false)
        setCsvFile(null)
        fetchRegistrations()
        fetchStats()
      } else {
        toast({
          title: 'Import Gagal',
          description: importData.error || 'Terjadi kesalahan',
          variant: 'destructive',
        })
      }
    } catch (err) {
      toast({
        title: 'Import Gagal',
        description: err instanceof Error ? err.message : 'Terjadi kesalahan',
        variant: 'destructive',
      })
    } finally {
      setImporting(false)
    }
  }

  const handleVerify = async () => {
    if (!verifyTargetId) return

    setVerifying(true)
    try {
      const res = await fetch('/api/registrations/verify', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: verifyTargetId,
          verificationStatus: verifyAction,
          verificationNote: verifyNote || undefined,
        }),
      })

      const data = await res.json()

      if (data.success) {
        toast({
          title: verifyAction === 'VERIFIED' ? 'Pendaftar Diterima' : 'Pendaftar Ditolak',
          description: verifyAction === 'VERIFIED'
            ? 'Data pendaftar telah diverifikasi dan diterima'
            : 'Data pendaftar telah ditolak',
        })
        setVerifyDialogOpen(false)
        setVerifyNote('')
        setVerifyTargetId(null)
        fetchRegistrations()
        fetchStats()
      } else {
        toast({
          title: 'Verifikasi Gagal',
          description: data.error || 'Terjadi kesalahan',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'Verifikasi Gagal',
        description: 'Terjadi kesalahan',
        variant: 'destructive',
      })
    } finally {
      setVerifying(false)
    }
  }

  const handleBulkVerify = async () => {
    if (selectedIds.size === 0) return

    setVerifying(true)
    try {
      const res = await fetch('/api/registrations/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: Array.from(selectedIds),
          verificationStatus: verifyAction,
          verificationNote: verifyNote || undefined,
        }),
      })

      const data = await res.json()

      if (data.success) {
        toast({
          title: verifyAction === 'VERIFIED' ? 'Pendaftar Diterima' : 'Pendaftar Ditolak',
          description: `${data.updated} pendaftar ${verifyAction === 'VERIFIED' ? 'diterima' : 'ditolak'}`,
        })
        setBulkVerifyDialogOpen(false)
        setVerifyNote('')
        setSelectedIds(new Set())
        fetchRegistrations()
        fetchStats()
      } else {
        toast({
          title: 'Verifikasi Gagal',
          description: data.error || 'Terjadi kesalahan',
          variant: 'destructive',
        })
      }
    } catch {
      toast({
        title: 'Verifikasi Gagal',
        description: 'Terjadi kesalahan',
        variant: 'destructive',
      })
    } finally {
      setVerifying(false)
    }
  }

  const toggleSelectAll = () => {
    if (selectedIds.size === registrations.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(registrations.map(r => r.id)))
    }
  }

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds)
    if (next.has(id)) {
      next.delete(id)
    } else {
      next.add(id)
    }
    setSelectedIds(next)
  }

  const verificationPercent = stats
    ? stats.total > 0
      ? Math.round(((stats.verified + stats.rejected) / stats.total) * 100)
      : 0
    : 0

  const verifiedPercent = stats && stats.total > 0 ? Math.round((stats.verified / stats.total) * 100) : 0
  const rejectedPercent = stats && stats.total > 0 ? Math.round((stats.rejected / stats.total) * 100) : 0
  const pendingPercent = stats && stats.total > 0 ? Math.round((stats.pending / stats.total) * 100) : 0

  // Get pending count per lembar verifikasi for badges
  const getPendingForLembar = (subJalurFilter: string) => {
    if (!stats) return 0
    const jalurNames = subJalurFilter.split(',').map(s => s.trim())
    const relevantPending = stats.bySubJalur
      .filter(item => jalurNames.includes(item.name))
      .reduce((acc, item) => {
        const verified = stats.verifiedBySubJalur.find(v => v.name === item.name)?.count || 0
        const rejected = stats.rejectedBySubJalur.find(r => r.name === item.name)?.count || 0
        return acc + item.count - verified - rejected
      }, 0)
    return relevantPending
  }

  const handleViewDetail = (reg: Registration) => {
    setDetailTarget(reg)
    setDetailDialogOpen(true)
  }

  // Edit dialog functions (Home component)
  const openEditDialog = (reg: Registration) => {
    setEditTarget(reg)
    setEditForm({
      noRegistrasi: reg.noRegistrasi || '',
      nama: reg.nama || '',
      nisn: reg.nisn || '',
      subJalur: reg.subJalur || '',
      nik: reg.nik || '',
      tanggalLahir: reg.tanggalLahir || '',
      alamat: reg.alamat || '',
      alamatLengkap: reg.alamatLengkap || '',
      noTelpSiswa: reg.noTelpSiswa || '',
      noTelpOrangtua: reg.noTelpOrangtua || '',
      npsnSekolahPilihan: reg.npsnSekolahPilihan || '',
      namaSekolahPilihan: reg.namaSekolahPilihan || '',
      jurusan: reg.jurusan || '',
      npsnSekolahAsal: reg.npsnSekolahAsal || '',
      namaSekolahAsal: reg.namaSekolahAsal || '',
      skorJarak: reg.skorJarak || '',
      skorNilaiRaport: reg.skorNilaiRaport || '',
      kekuranganVerifikasi: reg.kekuranganVerifikasi || '',
      tanggalVerif: reg.tanggalVerif || '',
      jamVerif: reg.jamVerif || '',
      terbitKK: reg.terbitKK || '',
      latitude: reg.latitude || '',
      longitude: reg.longitude || '',
      lokasiJarak: reg.lokasiJarak || '',
      statusKelulusan: reg.statusKelulusan || '',
      statusDaftarUlang: reg.statusDaftarUlang || '',
      nilaiRataRata: reg.nilaiRataRata || '',
    })
    setEditDialogOpen(true)
  }

  const handleSaveEdit = async () => {
    if (!editTarget) return
    setSaving(true)
    try {
      const updateData = { ...editForm }
      if (updateData.terbitKK) {
        const calculatedLama = hitungLamaKK(updateData.terbitKK)
        if (calculatedLama) updateData['lamaKK'] = calculatedLama
      }
      const res = await fetch(`/api/registrations/${editTarget.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData),
      })
      const result = await res.json()
      if (result.success) {
        toast({ title: 'Berhasil', description: `Data ${editTarget.nama} berhasil diperbarui` })
        setEditDialogOpen(false)
        setEditTarget(null)
        fetchRegistrations()
        fetchStats()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal menyimpan', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  // Delete dialog functions (Home component)
  const openDeleteDialog = (reg: Registration) => {
    setDeleteTarget(reg)
    setDeleteDialogOpen(true)
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/registrations/${deleteTarget.id}`, {
        method: 'DELETE',
      })
      const result = await res.json()
      if (result.success) {
        toast({ title: 'Berhasil', description: `Data ${deleteTarget.nama} berhasil dihapus` })
        setDeleteDialogOpen(false)
        setDeleteTarget(null)
        fetchRegistrations()
        fetchStats()
      } else {
        toast({ title: 'Gagal', description: result.error || 'Gagal menghapus', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan', variant: 'destructive' })
    } finally {
      setDeleting(false)
    }
  }

  // Print report function
  const handlePrintReport = (type: 'diterima' | 'ditolak' | 'lulus' | 'tidak-lulus' | 'daftar-ulang' | 'tidak-daftar-ulang') => {
    let list: Registration[] = []
    let title = ''
    let extraCol = ''
    if (type === 'diterima') { list = stats?.verifiedList || []; title = 'LAPORAN PESERTA DITERIMA' }
    else if (type === 'ditolak') { list = stats?.rejectedList || []; title = 'LAPORAN PESERTA DITOLAK'; extraCol = 'alasan' }
    else if (type === 'lulus') { list = stats?.lulusList || []; title = 'DAFTAR PESERTA LULUS' }
    else if (type === 'tidak-lulus') { list = stats?.tidakLulusList || []; title = 'DAFTAR PESERTA TIDAK LULUS' }
    else if (type === 'daftar-ulang') { list = stats?.daftarUlangList || []; title = 'DAFTAR PESERTA DAFTAR ULANG' }
    else if (type === 'tidak-daftar-ulang') { list = stats?.tidakDaftarUlangList || []; title = 'DAFTAR PESERTA TIDAK DAFTAR ULANG' }
    const printWindow = window.open('', '_blank')
    if (!printWindow) return
    const rows = list.map((reg, idx) => `
      <tr>
        <td style="padding:6px 8px;border:1px solid #ddd;text-align:center">${idx + 1}</td>
        <td style="padding:6px 8px;border:1px solid #ddd">${reg.noRegistrasi}</td>
        <td style="padding:6px 8px;border:1px solid #ddd">${reg.nama}</td>
        <td style="padding:6px 8px;border:1px solid #ddd">${reg.nisn}</td>
        <td style="padding:6px 8px;border:1px solid #ddd">${reg.subJalur}</td>
        <td style="padding:6px 8px;border:1px solid #ddd">${reg.namaSekolahPilihan}</td>
        <td style="padding:6px 8px;border:1px solid #ddd">${reg.jurusan}</td>
        <td style="padding:6px 8px;border:1px solid #ddd">${reg.tanggalVerif || '-'}</td>
        ${type === 'ditolak' ? `<td style="padding:6px 8px;border:1px solid #ddd">${reg.verificationNote || '-'}</td>` : ''}
      </tr>
    `).join('')
    printWindow.document.write(`<!DOCTYPE html><html><head><title>${title}</title>
      <style>body{font-family:Arial,sans-serif;margin:20px}table{width:100%;border-collapse:collapse}th{background:#f5f5f5;padding:8px;border:1px solid #ddd;text-align:left}h1{text-align:center;font-size:18px}h2{text-align:center;font-size:14px;color:#666}</style></head>
      <body><h1>${title}</h1><h2>SPMB 2026</h2><p style="text-align:center;color:#888">Dicetak pada: ${new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
      <table><thead><tr><th>No</th><th>No. Registrasi</th><th>Nama</th><th>NISN</th><th>Sub Jalur</th><th>Sekolah Pilihan</th><th>Jurusan</th><th>Tanggal Verif</th>${type === 'ditolak' ? '<th>Alasan Penolakan</th>' : ''}</tr></thead><tbody>${rows}</tbody></table></body></html>`)
    printWindow.document.close()
    printWindow.print()
  }

  // Export PDF per tab
  const handleExportTabPDF = (type: 'diterima' | 'ditolak' | 'lulus' | 'tidak-lulus' | 'daftar-ulang' | 'tidak-daftar-ulang' | 'ranking') => {
    if (type === 'ranking') {
      const headers = ['No', 'Jalur', 'Nama', 'NISN', 'Sekolah Pilihan', 'Jurusan', 'Jarak', 'Nilai Rata-rata', 'Skor', 'Status']
      const rows = rankingData.map((r: Record<string, unknown>, idx: number) => [
        String(idx + 1), (r.subJalur as string) || '-', (r.nama as string) || '-', (r.nisn as string) || '-',
        (r.namaSekolahPilihan as string) || '-', (r.jurusan as string) || '-',
        (r.lokasiJarak as string) || '-', (r.nilaiRataRata as string || r.skorNilaiRaport as string) || '-',
        (r.skor as string) || '-',
        r.verificationStatus === 'VERIFIED' ? 'Diterima' : r.verificationStatus === 'REJECTED' ? 'Ditolak' : 'Menunggu',
      ])
      const jalurLabel = rankingJalur === 'all' ? 'Semua Jalur' : rankingJalur
      exportPDF(`PERANGKINGAN ${jalurLabel.toUpperCase()}`, 'SPMB 2026', headers, rows, `Perangkingan_${jalurLabel}.pdf`)
      return
    }
    let list: Registration[] = []
    let title = ''
    let filename = ''
    if (type === 'diterima') { list = stats?.verifiedList || []; title = 'LAPORAN PESERTA DITERIMA'; filename = 'Peserta_Diterima.pdf' }
    else if (type === 'ditolak') { list = stats?.rejectedList || []; title = 'LAPORAN PESERTA DITOLAK'; filename = 'Peserta_Ditolak.pdf' }
    else if (type === 'lulus') { list = stats?.lulusList || []; title = 'DAFTAR PESERTA LULUS'; filename = 'Peserta_Lulus.pdf' }
    else if (type === 'tidak-lulus') { list = stats?.tidakLulusList || []; title = 'DAFTAR PESERTA TIDAK LULUS'; filename = 'Peserta_Tidak_Lulus.pdf' }
    else if (type === 'daftar-ulang') { list = stats?.daftarUlangList || []; title = 'DAFTAR PESERTA DAFTAR ULANG'; filename = 'Peserta_Daftar_Ulang.pdf' }
    else if (type === 'tidak-daftar-ulang') { list = stats?.tidakDaftarUlangList || []; title = 'DAFTAR PESERTA TIDAK DAFTAR ULANG'; filename = 'Peserta_Tidak_Daftar_Ulang.pdf' }
    const headers = type === 'ditolak'
      ? ['No', 'No. Registrasi', 'Nama', 'NISN', 'Sub Jalur', 'Sekolah Pilihan', 'Jurusan', 'Alasan Penolakan']
      : ['No', 'No. Registrasi', 'Nama', 'NISN', 'Sub Jalur', 'Sekolah Pilihan', 'Jurusan']
    const rows = list.map((reg, idx) => type === 'ditolak'
      ? [String(idx + 1), reg.noRegistrasi, reg.nama, reg.nisn, reg.subJalur, reg.namaSekolahPilihan, reg.jurusan, reg.verificationNote || '-']
      : [String(idx + 1), reg.noRegistrasi, reg.nama, reg.nisn, reg.subJalur, reg.namaSekolahPilihan, reg.jurusan]
    )
    exportPDF(title, 'SPMB 2026', headers, rows, filename)
  }

  // Export Excel per tab
  const handleExportTabExcel = (type: 'diterima' | 'ditolak' | 'lulus' | 'tidak-lulus' | 'daftar-ulang' | 'tidak-daftar-ulang' | 'ranking') => {
    if (type === 'ranking') {
      const headers = ['No', 'Jalur', 'Nama', 'NISN', 'Sekolah Pilihan', 'Jurusan', 'Jarak', 'Nilai Rata-rata', 'Skor', 'Status']
      const rows: (string | number)[][] = rankingData.map((r: Record<string, unknown>, idx: number) => [
        idx + 1, (r.subJalur as string) || '-', (r.nama as string) || '-', (r.nisn as string) || '-',
        (r.namaSekolahPilihan as string) || '-', (r.jurusan as string) || '-',
        (r.lokasiJarak as string) || '-', (r.nilaiRataRata as string || r.skorNilaiRaport as string) || '-',
        (r.skor as string) || '-',
        r.verificationStatus === 'VERIFIED' ? 'Diterima' : r.verificationStatus === 'REJECTED' ? 'Ditolak' : 'Menunggu',
      ])
      const jalurLabel = rankingJalur === 'all' ? 'Semua Jalur' : rankingJalur
      exportExcel(`Perangkingan ${jalurLabel}`, headers, rows, `Perangkingan_${jalurLabel}.xlsx`)
      return
    }
    let list: Registration[] = []
    let title = ''
    let filename = ''
    if (type === 'diterima') { list = stats?.verifiedList || []; title = 'Peserta Diterima'; filename = 'Peserta_Diterima.xlsx' }
    else if (type === 'ditolak') { list = stats?.rejectedList || []; title = 'Peserta Ditolak'; filename = 'Peserta_Ditolak.xlsx' }
    else if (type === 'lulus') { list = stats?.lulusList || []; title = 'Peserta Lulus'; filename = 'Peserta_Lulus.xlsx' }
    else if (type === 'tidak-lulus') { list = stats?.tidakLulusList || []; title = 'Peserta Tidak Lulus'; filename = 'Peserta_Tidak_Lulus.xlsx' }
    else if (type === 'daftar-ulang') { list = stats?.daftarUlangList || []; title = 'Peserta Daftar Ulang'; filename = 'Peserta_Daftar_Ulang.xlsx' }
    else if (type === 'tidak-daftar-ulang') { list = stats?.tidakDaftarUlangList || []; title = 'Peserta Tidak Daftar Ulang'; filename = 'Peserta_Tidak_Daftar_Ulang.xlsx' }
    const headers = type === 'ditolak'
      ? ['No', 'No. Registrasi', 'Nama', 'NISN', 'Sub Jalur', 'Sekolah Pilihan', 'Jurusan', 'Alasan Penolakan']
      : ['No', 'No. Registrasi', 'Nama', 'NISN', 'Sub Jalur', 'Sekolah Pilihan', 'Jurusan']
    const rows: (string | number)[][] = list.map((reg, idx) => type === 'ditolak'
      ? [idx + 1, reg.noRegistrasi, reg.nama, reg.nisn, reg.subJalur, reg.namaSekolahPilihan, reg.jurusan, reg.verificationNote || '-']
      : [idx + 1, reg.noRegistrasi, reg.nama, reg.nisn, reg.subJalur, reg.namaSekolahPilihan, reg.jurusan]
    )
    exportExcel(title, headers, rows, filename)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-gray-50 to-emerald-50/30">
      {/* PWA Install Banner */}
      {showInstallBanner && !isInstalled && (
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-4 py-2.5 flex items-center justify-between gap-3 animate-in slide-in-from-top duration-500 z-50">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold">Install SPMB 2026</p>
              <p className="text-xs text-emerald-100 truncate">Tambahkan ke perangkat untuk akses cepat</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button
              size="sm"
              className="bg-white text-emerald-700 hover:bg-emerald-50 h-8 text-xs font-semibold px-4"
              onClick={handleInstallClick}
            >
              Install
            </Button>
            <button
              className="text-white/60 hover:text-white p-1"
              onClick={() => setShowInstallBanner(false)}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
      {/* Header */}
      <header className="sticky top-0 z-40 bg-gradient-to-r from-slate-900 via-emerald-900 to-slate-900 border-b border-emerald-400/20 shadow-lg">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 sm:h-18">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-emerald-600 text-white ring-2 ring-emerald-400/30 shadow-lg shadow-emerald-500/20">
                <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <div>
                <h1 className="text-base sm:text-xl font-bold text-white tracking-tight">SPMB 2026</h1>
                <p className="text-[10px] sm:text-xs text-emerald-200 hidden xs:block">Sistem Verifikasi Pendaftaran</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Button
                onClick={() => setPortalPasteOpen(true)}
                variant="outline"
                size="sm"
                className="bg-white/10 hover:bg-white/20 text-white border-white/20 h-8 sm:h-9 px-2 sm:px-3"
              >
                <ClipboardPaste className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Paste Portal</span>
              </Button>
              {authUser?.role === 'admin' && (
              <Button
                onClick={() => setImportDialogOpen(true)}
                size="sm"
                className="bg-white/10 hover:bg-white/20 text-white border border-white/20 h-8 sm:h-9 px-2 sm:px-3"
              >
                <Upload className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Import CSV</span>
              </Button>
              )}
              {/* Install PWA button — only show if not yet installed */}
              {!isInstalled && (
              <Button
                onClick={handleInstallClick}
                variant="outline"
                size="sm"
                className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border-emerald-400/30 h-8 sm:h-9 px-2 sm:px-3"
                title="Install aplikasi SPMB 2026 di perangkat Anda"
              >
                <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Install</span>
              </Button>
              )}
              {/* User info & Logout */}
              <div className="hidden sm:flex items-center gap-2 ml-1 pl-2 border-l border-white/20">
                <div className="flex items-center gap-1.5">
                  <div className="w-7 h-7 rounded-full bg-emerald-600/40 flex items-center justify-center">
                    <span className="text-xs font-bold text-white">{authUser?.namaLengkap?.charAt(0) || 'U'}</span>
                  </div>
                  <div className="hidden md:block">
                    <p className="text-xs font-medium text-white leading-tight">{authUser?.namaLengkap}</p>
                    <p className="text-[10px] text-emerald-200/60 leading-tight">{authUser?.role === 'admin' ? 'Administrator' : 'Verifikator'}</p>
                  </div>
                </div>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                size="sm"
                className="bg-white/5 hover:bg-red-500/20 text-white/70 hover:text-red-300 border-white/10 hover:border-red-400/30 h-8 sm:h-9 px-2"
                title="Keluar"
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden lg:inline ml-1">Keluar</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Tab Navigation - Responsive with grouping */}
          <div className="space-y-2">
            {/* Row 1: Utama */}
            <div>
              <p className="text-[10px] sm:text-xs text-gray-400 font-semibold uppercase tracking-wider mb-1.5 px-1">Menu Utama</p>
              <div className="overflow-x-auto -mx-3 px-3 sm:mx-0 sm:px-0 [&::-webkit-scrollbar]:h-1 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-gray-300 [&::-webkit-scrollbar-track]:bg-transparent">
                <TabsList className="flex-nowrap bg-white/80 backdrop-blur-sm border border-gray-200/60 rounded-xl p-1 shadow-sm w-max sm:w-full sm:justify-start gap-0.5 sm:gap-1">
                  <TabsTrigger value="dashboard" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    Dashboard
                  </TabsTrigger>
                  <TabsTrigger value="lembar-verifikasi" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-amber-100 data-[state=active]:text-amber-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <ClipboardCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Lembar Verifikasi</span>
                    <span className="sm:hidden">Verifikasi</span>
                    {stats && stats.pending > 0 && (
                      <Badge className="ml-0.5 sm:ml-1 bg-amber-500 text-white text-[10px] sm:text-xs px-1 sm:px-1.5 py-0 min-w-[16px] sm:min-w-[20px] h-4 sm:h-5 flex items-center justify-center">
                        {stats.pending}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="data" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-blue-100 data-[state=active]:text-blue-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <FileSpreadsheet className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Data Pendaftar</span>
                    <span className="sm:hidden">Data</span>
                  </TabsTrigger>
                  <TabsTrigger value="ranking" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-amber-100 data-[state=active]:text-amber-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <Trophy className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Perangkingan</span>
                    <span className="sm:hidden">Ranking</span>
                  </TabsTrigger>
                  <TabsTrigger value="pengaturan" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-sky-100 data-[state=active]:text-sky-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Pengaturan</span>
                    <span className="sm:hidden">Setting</span>
                  </TabsTrigger>
                </TabsList>
              </div>
            </div>

            {/* Row 2: Status & Kelulusan */}
            <div>
              <p className="text-[10px] sm:text-xs text-gray-400 font-semibold uppercase tracking-wider mb-1.5 px-1">Status Verifikasi & Kelulusan</p>
              <div className="overflow-x-auto -mx-3 px-3 sm:mx-0 sm:px-0 [&::-webkit-scrollbar]:h-1 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-gray-300 [&::-webkit-scrollbar-track]:bg-transparent">
                <TabsList className="flex-nowrap bg-white/80 backdrop-blur-sm border border-gray-200/60 rounded-xl p-1 shadow-sm w-max sm:w-full sm:justify-start gap-0.5 sm:gap-1">
                  <TabsTrigger value="diterima" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <ThumbsUp className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    Diterima
                    {stats && stats.verified > 0 && (
                      <Badge className="ml-0.5 sm:ml-1 bg-emerald-600 text-white text-[10px] sm:text-xs px-1 sm:px-1.5 py-0 min-w-[16px] sm:min-w-[20px] h-4 sm:h-5 flex items-center justify-center">
                        {stats.verified}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="ditolak" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-red-100 data-[state=active]:text-red-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <ThumbsDown className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    Ditolak
                    {stats && stats.rejected > 0 && (
                      <Badge className="ml-0.5 sm:ml-1 bg-red-600 text-white text-[10px] sm:text-xs px-1 sm:px-1.5 py-0 min-w-[16px] sm:min-w-[20px] h-4 sm:h-5 flex items-center justify-center">
                        {stats.rejected}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <div className="w-px h-6 bg-gray-200 self-center mx-0.5 sm:mx-1" />
                  <TabsTrigger value="lulus" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-green-100 data-[state=active]:text-green-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <CircleCheckBig className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    Lulus
                    {stats && stats.lulus > 0 && (
                      <Badge className="ml-0.5 sm:ml-1 bg-green-600 text-white text-[10px] sm:text-xs px-1 sm:px-1.5 py-0 min-w-[16px] sm:min-w-[20px] h-4 sm:h-5 flex items-center justify-center">
                        {stats.lulus}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="tidak-lulus" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-orange-100 data-[state=active]:text-orange-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <CircleX className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Tidak Lulus</span>
                    <span className="sm:hidden">T. Lulus</span>
                    {stats && stats.tidakLulus > 0 && (
                      <Badge className="ml-0.5 sm:ml-1 bg-orange-600 text-white text-[10px] sm:text-xs px-1 sm:px-1.5 py-0 min-w-[16px] sm:min-w-[20px] h-4 sm:h-5 flex items-center justify-center">
                        {stats.tidakLulus}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <div className="w-px h-6 bg-gray-200 self-center mx-0.5 sm:mx-1" />
                  <TabsTrigger value="daftar-ulang" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-teal-100 data-[state=active]:text-teal-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <ClipboardList className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Daftar Ulang</span>
                    <span className="sm:hidden">D. Ulang</span>
                    {stats && stats.daftarUlang > 0 && (
                      <Badge className="ml-0.5 sm:ml-1 bg-teal-600 text-white text-[10px] sm:text-xs px-1 sm:px-1.5 py-0 min-w-[16px] sm:min-w-[20px] h-4 sm:h-5 flex items-center justify-center">
                        {stats.daftarUlang}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="tidak-daftar-ulang" className="gap-1 rounded-lg px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm transition-all duration-200 data-[state=active]:bg-rose-100 data-[state=active]:text-rose-800 data-[state=active]:shadow-sm whitespace-nowrap">
                    <UserMinus className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Tidak Daftar Ulang</span>
                    <span className="sm:hidden">T.D. Ulang</span>
                    {stats && stats.tidakDaftarUlang > 0 && (
                      <Badge className="ml-0.5 sm:ml-1 bg-rose-600 text-white text-[10px] sm:text-xs px-1 sm:px-1.5 py-0 min-w-[16px] sm:min-w-[20px] h-4 sm:h-5 flex items-center justify-center">
                        {stats.tidakDaftarUlang}
                      </Badge>
                    )}
                  </TabsTrigger>
                </TabsList>
              </div>
            </div>
          </div>

          {/* ==================== DASHBOARD TAB ==================== */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Hero Welcome Section */}
            <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 rounded-xl sm:rounded-2xl p-4 sm:p-6 text-white shadow-lg shadow-emerald-200/50">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
                <div>
                  <h2 className="text-lg sm:text-2xl font-bold tracking-tight">Selamat Datang di SPMB 2026</h2>
                  <p className="text-emerald-100 mt-0.5 text-xs sm:text-sm">Sistem Verifikasi Penerimaan Peserta Didik Baru</p>
                </div>
                <div className="flex gap-2 sm:gap-3">
                  <div className="bg-white/15 backdrop-blur-sm rounded-lg sm:rounded-xl px-3 sm:px-4 py-1.5 sm:py-2 text-center">
                    <p className="text-xl sm:text-2xl font-bold">{stats?.total || 0}</p>
                    <p className="text-[10px] sm:text-xs text-emerald-100">Pendaftar</p>
                  </div>
                  <div className="bg-white/15 backdrop-blur-sm rounded-lg sm:rounded-xl px-3 sm:px-4 py-1.5 sm:py-2 text-center">
                    <p className="text-xl sm:text-2xl font-bold">{verificationPercent}%</p>
                    <p className="text-[10px] sm:text-xs text-emerald-100">Terverifikasi</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
              <Card className="bg-gradient-to-br from-slate-50 to-slate-100/50 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs sm:text-sm text-gray-500">Total Pendaftar</p>
                      <p className="text-xl sm:text-2xl font-bold">{stats?.total || 0}</p>
                    </div>
                    <div className="p-2 sm:p-2.5 bg-gray-100 rounded-lg sm:rounded-xl shadow-sm">
                      <Users className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-amber-50 to-yellow-50/50 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs sm:text-sm text-gray-500">Menunggu</p>
                      <p className="text-xl sm:text-2xl font-bold text-yellow-600">{stats?.pending || 0}</p>
                    </div>
                    <div className="p-2 sm:p-2.5 bg-amber-100 rounded-lg sm:rounded-xl shadow-sm">
                      <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-emerald-50 to-teal-50/50 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => setActiveTab('diterima')}>
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs sm:text-sm text-gray-500">Diterima</p>
                      <p className="text-xl sm:text-2xl font-bold text-emerald-600">{stats?.verified || 0}</p>
                    </div>
                    <div className="p-2 sm:p-2.5 bg-emerald-100 rounded-lg sm:rounded-xl shadow-sm">
                      <UserCheck className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-red-50 to-rose-50/50 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => setActiveTab('ditolak')}>
                <CardContent className="p-3 sm:p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs sm:text-sm text-gray-500">Ditolak</p>
                      <p className="text-xl sm:text-2xl font-bold text-red-600">{stats?.rejected || 0}</p>
                    </div>
                    <div className="p-2 sm:p-2.5 bg-red-100 rounded-lg sm:rounded-xl shadow-sm">
                      <UserX className="w-4 h-4 sm:w-5 sm:h-5 text-red-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Progress */}
            <Card className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Progres Verifikasi</CardTitle>
                <CardDescription>
                  {verificationPercent}% pendaftar telah diproses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={verificationPercent} className="h-4" />
                <div className="flex justify-between mt-3 text-xs">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-emerald-500" />
                    <span className="text-gray-600">Diterima: {stats?.verified || 0} ({verifiedPercent}%)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <span className="text-gray-600">Ditolak: {stats?.rejected || 0} ({rejectedPercent}%)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <span className="text-gray-600">Menunggu: {stats?.pending || 0} ({pendingPercent}%)</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Charts Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* By Sub Jalur */}
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    Berdasarkan Sub Jalur
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {stats?.bySubJalur.map((item) => (
                      <StatBar key={item.name} label={item.name} count={item.count} total={stats.total} color="bg-emerald-500" />
                    ))}
                    {(!stats?.bySubJalur || stats.bySubJalur.length === 0) && (
                      <p className="text-sm text-gray-400 text-center py-4">Belum ada data</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* By Sekolah Pilihan */}
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <School className="w-4 h-4" />
                    Berdasarkan Sekolah Pilihan
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {stats?.bySekolahPilihan.map((item) => (
                      <StatBar key={item.name} label={item.name} count={item.count} total={stats.total} color="bg-sky-500" />
                    ))}
                    {(!stats?.bySekolahPilihan || stats.bySekolahPilihan.length === 0) && (
                      <p className="text-sm text-gray-400 text-center py-4">Belum ada data</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* By Jurusan */}
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <GraduationCap className="w-4 h-4" />
                    Berdasarkan Jurusan
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {stats?.byJurusan.map((item) => (
                      <StatBar key={item.name} label={item.name} count={item.count} total={stats.total} color="bg-violet-500" />
                    ))}
                    {(!stats?.byJurusan || stats.byJurusan.length === 0) && (
                      <p className="text-sm text-gray-400 text-center py-4">Belum ada data</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Verification Status */}
              <Card className="shadow-sm">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4" />
                    Ringkasan Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <StatBar label="Diterima (Terverifikasi)" count={stats?.verified || 0} total={stats?.total || 0} color="bg-emerald-500" />
                    <StatBar label="Ditolak" count={stats?.rejected || 0} total={stats?.total || 0} color="bg-red-500" />
                    <StatBar label="Menunggu Verifikasi" count={stats?.pending || 0} total={stats?.total || 0} color="bg-yellow-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Lembar Verifikasi Quick Links */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <ClipboardCheck className="w-4 h-4" />
                  Lembar Verifikasi per Jalur
                </CardTitle>
                <CardDescription>Klik untuk membuka lembar verifikasi masing-masing jalur</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {lembarVerifikasi.map((lv) => {
                    const LvIcon = lv.icon
                    const pendingCount = getPendingForLembar(lv.subJalurFilter)
                    return (
                      <Card
                        key={lv.key}
                        className={`border-2 cursor-pointer hover:scale-[1.02] hover:shadow-xl transition-all duration-300 ${lv.borderColor} ${lv.bgColor}`}
                        onClick={() => { setActiveTab('lembar-verifikasi'); setLembarTab(lv.key) }}
                      >
                        <CardContent className="p-3 sm:p-4 text-center">
                          <LvIcon className={`w-7 h-7 sm:w-8 sm:h-8 mx-auto mb-1.5 ${lv.iconColor}`} />
                          <p className="font-semibold text-gray-900 text-sm sm:text-base">{lv.label}</p>
                          <p className="text-xs text-gray-500 mt-0.5">{pendingCount} menunggu verifikasi</p>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== LEMBAR VERIFIKASI TAB ==================== */}
          <TabsContent value="lembar-verifikasi" className="space-y-6">
            <Tabs value={lembarTab} onValueChange={setLembarTab}>
              <div className="overflow-x-auto -mx-3 px-3 sm:mx-0 sm:px-0 scrollbar-hide">
                <TabsList className="flex-nowrap sm:flex-wrap h-auto gap-1 bg-white/60 backdrop-blur-sm border rounded-xl p-1 shadow-sm w-max sm:w-auto">
                  {lembarVerifikasi.map((lv) => {
                    const LvIcon = lv.icon
                    const pendingCount = getPendingForLembar(lv.subJalurFilter)
                    return (
                      <TabsTrigger
                        key={lv.key}
                        value={lv.key}
                        className="gap-1 text-xs sm:text-sm px-2 sm:px-3 py-1.5 rounded-lg transition-all duration-200 whitespace-nowrap"
                      >
                        <LvIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                        <span className="hidden md:inline">{lv.label}</span>
                        <span className="md:hidden">{lv.label.length > 10 ? lv.label.substring(0, 8) + '..' : lv.label}</span>
                        {pendingCount > 0 && (
                          <Badge className="ml-0.5 bg-amber-500 text-white text-[10px] sm:text-xs px-1 py-0 min-w-[14px] sm:min-w-[16px] h-3.5 sm:h-4 flex items-center justify-center">
                            {pendingCount}
                          </Badge>
                        )}
                      </TabsTrigger>
                    )
                  })}
                </TabsList>
              </div>

              {lembarVerifikasi.map((lv) => (
                <TabsContent key={lv.key} value={lv.key} className="mt-6">
                  <LembarVerifikasiSheet
                    config={lv}
                    subJalurOptions={subJalurOptions}
                    onVerify={() => {}}
                    onBulkVerify={() => {}}
                    onViewDetail={handleViewDetail}
                    toast={toast}
                  />
                </TabsContent>
              ))}
            </Tabs>
          </TabsContent>

          {/* ==================== DATA PENDAFTAR TAB ==================== */}
          <TabsContent value="data" className="space-y-4">
            {/* Filters */}
            <Card className="shadow-sm">
              <CardContent className="p-3 sm:p-4">
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="Cari nama, NISN..."
                      className="pl-9 h-9 sm:h-10 text-sm"
                      value={search}
                      onChange={(e) => {
                        setSearch(e.target.value)
                        setPagination(prev => ({ ...prev, page: 1 }))
                      }}
                    />
                  </div>
                  <Button
                    size="sm"
                    variant={showAllData ? 'default' : 'outline'}
                    className={`h-9 sm:h-10 gap-1.5 text-xs whitespace-nowrap ${showAllData ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
                    onClick={() => { setShowAllData(!showAllData); setPagination(prev => ({ ...prev, page: 1, limit: showAllData ? 15 : 9999 })) }}
                  >
                    <LayoutList className="w-3.5 h-3.5" />
                    {showAllData ? 'Tampilan Halaman' : 'Tampilkan Semua'}
                  </Button>
                  <div className="grid grid-cols-2 sm:flex gap-2">
                    <Select
                      value={subJalurFilter}
                      onValueChange={(v) => {
                        setSubJalurFilter(v)
                        setPagination(prev => ({ ...prev, page: 1 }))
                      }}
                    >
                      <SelectTrigger className="w-full sm:w-[180px] h-9 sm:h-10 text-xs sm:text-sm">
                        <SelectValue placeholder="Sub Jalur" />
                      </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Jalur</SelectItem>
                      {subJalurOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={verificationFilter}
                    onValueChange={(v) => {
                      setVerificationFilter(v)
                      setPagination(prev => ({ ...prev, page: 1 }))
                    }}
                  >
                    <SelectTrigger className="w-full sm:w-[180px] h-9 sm:h-10 text-xs sm:text-sm">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Status</SelectItem>
                      <SelectItem value="PENDING">Menunggu</SelectItem>
                      <SelectItem value="VERIFIED">Diterima</SelectItem>
                      <SelectItem value="REJECTED">Ditolak</SelectItem>
                    </SelectContent>
                  </Select>
                  </div>
                  {selectedIds.size > 0 && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="bg-emerald-600 hover:bg-emerald-700"
                        onClick={() => {
                          setVerifyAction('VERIFIED')
                          setBulkVerifyDialogOpen(true)
                        }}
                      >
                        <ThumbsUp className="w-4 h-4" />
                        Terima ({selectedIds.size})
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => {
                          setVerifyAction('REJECTED')
                          setBulkVerifyDialogOpen(true)
                        }}
                      >
                        <ThumbsDown className="w-4 h-4" />
                        Tolak ({selectedIds.size})
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedIds(new Set())}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Table */}
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-white">
                      <TableRow className="bg-gray-50/80">
                        <TableHead className="w-10 text-center">No</TableHead>
                        <TableHead className="w-10">
                          <Checkbox
                            checked={registrations.length > 0 && selectedIds.size === registrations.length}
                            onCheckedChange={toggleSelectAll}
                          />
                        </TableHead>
                        <TableHead>No. Reg</TableHead>
                        <TableHead className="cursor-pointer select-none hover:bg-gray-100/80 transition-colors" onClick={toggleNamaSort}>
                          <span className="inline-flex items-center gap-1">
                            Nama
                            {namaSortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                             namaSortDir === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                             <ArrowUpDown className="w-3 h-3 opacity-30" />}
                          </span>
                        </TableHead>
                        <TableHead className="hidden md:table-cell">NISN</TableHead>
                        <TableHead>Sub Jalur</TableHead>
                        <TableHead className="hidden lg:table-cell">Sekolah Pilihan</TableHead>
                        <TableHead className="hidden lg:table-cell">Jurusan</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        <TableRow>
                          <TableCell colSpan={10} className="text-center py-12">
                            <Loader2 className="w-6 h-6 animate-spin mx-auto text-gray-400" />
                            <p className="text-sm text-gray-400 mt-2">Memuat data...</p>
                          </TableCell>
                        </TableRow>
                      ) : registrations.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={10} className="text-center py-12">
                            <FileSpreadsheet className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                            <p className="text-gray-500 font-medium">Belum ada data pendaftar</p>
                            <p className="text-sm text-gray-400">Import CSV untuk memulai verifikasi</p>
                            {authUser?.role === 'admin' && (
                            <Button className="mt-3 bg-emerald-600 hover:bg-emerald-700" onClick={() => setImportDialogOpen(true)}>
                              <Upload className="w-4 h-4" />
                              Import CSV
                            </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ) : (
                        sortByName(registrations, namaSortDir).map((reg, idx) => (
                          <TableRow key={reg.id} className={
                            reg.verificationStatus === 'VERIFIED' ? 'bg-emerald-50/40' :
                            reg.verificationStatus === 'REJECTED' ? 'bg-red-50/40' : ''
                          }>
                            <TableCell className="text-center text-sm text-gray-500">
                              {(pagination.page - 1) * pagination.limit + idx + 1}
                            </TableCell>
                            <TableCell>
                              <Checkbox checked={selectedIds.has(reg.id)} onCheckedChange={() => toggleSelect(reg.id)} />
                            </TableCell>
                            <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                            <TableCell className="font-medium">{reg.nama}</TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-gray-500">{reg.nisn}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className={SUB_JALUR_COLORS[reg.subJalur] || 'bg-gray-100 text-gray-800 border-gray-200'}>
                                {reg.subJalur}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">{reg.namaSekolahPilihan}</TableCell>
                            <TableCell className="hidden lg:table-cell">
                              <Badge variant="secondary">{reg.jurusan}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={STATUS_COLORS[reg.verificationStatus]}>
                                {reg.verificationStatus === 'PENDING' && <Clock className="w-3 h-3" />}
                                {reg.verificationStatus === 'VERIFIED' && <CheckCircle2 className="w-3 h-3" />}
                                {reg.verificationStatus === 'REJECTED' && <XCircle className="w-3 h-3" />}
                                {reg.verificationStatus === 'PENDING' ? 'Menunggu' :
                                 reg.verificationStatus === 'VERIFIED' ? 'Diterima' : 'Ditolak'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => { setDetailTarget(reg); setDetailDialogOpen(true) }} title="Lihat Detail">
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}>
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-red-600 hover:text-white hover:bg-red-600" title="Hapus Data" onClick={() => openDeleteDialog(reg)}>
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                                {reg.verificationStatus !== 'VERIFIED' && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-emerald-600 hover:text-white hover:bg-emerald-600"
                                    title="Terima Pendaftar"
                                    onClick={() => {
                                      setVerifyTargetId(reg.id)
                                      setVerifyAction('VERIFIED')
                                      setVerifyNote('')
                                      setVerifyDialogOpen(true)
                                    }}
                                  >
                                    <ThumbsUp className="w-4 h-4" />
                                  </Button>
                                )}
                                {reg.verificationStatus !== 'REJECTED' && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-red-600 hover:text-white hover:bg-red-600"
                                    title="Tolak Pendaftar"
                                    onClick={() => {
                                      setVerifyTargetId(reg.id)
                                      setVerifyAction('REJECTED')
                                      setVerifyNote('')
                                      setVerifyDialogOpen(true)
                                    }}
                                  >
                                    <ThumbsDown className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>

                {/* Pagination */}
                {pagination.totalPages > 1 && (
                  <div className="flex items-center justify-between px-4 py-3 border-t">
                    <p className="text-sm text-gray-500">
                      Menampilkan {(pagination.page - 1) * pagination.limit + 1}-
                      {Math.min(pagination.page * pagination.limit, pagination.total)} dari {pagination.total} pendaftar
                    </p>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" disabled={pagination.page <= 1} onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}>
                        <ChevronLeft className="w-4 h-4" />
                      </Button>
                      <span className="text-sm text-gray-600">Hal {pagination.page} / {pagination.totalPages}</span>
                      <Button variant="outline" size="sm" disabled={pagination.page >= pagination.totalPages} onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}>
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== RANKING TAB ==================== */}
          <TabsContent value="ranking" className="space-y-6">
            {/* Header */}
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-yellow-600 p-4 sm:p-6 text-white">
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="p-2 sm:p-3 bg-white/20 rounded-xl">
                    <Trophy className="w-6 h-6 sm:w-8 sm:h-8" />
                  </div>
                  <div>
                    <h2 className="text-xl sm:text-2xl font-bold">Perangkingan</h2>
                    <p className="text-amber-100 text-xs sm:text-sm mt-1">Rangking pendaftar berdasarkan jarak, nilai, dan skor komposit</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Kuota Info */}
            {rankingKuota > 0 && (
              <Card className="bg-gradient-to-r from-sky-50 to-cyan-50 border-sky-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Award className="w-5 h-5 text-sky-600" />
                    <h3 className="font-semibold text-sky-900">Kuota Per Jalur</h3>
                    <span className="text-sm text-sky-600 ml-auto">Total Kuota: <strong>{rankingKuota}</strong></span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {rankingKuotaPerJalur.map((kj) => (
                      <div key={kj.nama} className="bg-white rounded-lg p-2.5 border border-sky-100 shadow-sm">
                        <p className="text-[10px] sm:text-xs text-gray-500 truncate">{kj.nama}</p>
                        <p className="text-lg sm:text-xl font-bold text-sky-700">{kj.kuota}</p>
                        <p className="text-[10px] text-gray-400">{kj.persentase}%</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Filters */}
            <Card className="shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <h3 className="font-semibold text-sm text-gray-700">Filter & Urutan</h3>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
                  {/* Tampilan / Sort */}
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-500">Urutkan Berdasarkan</label>
                    <Select value={rankingTampilan} onValueChange={setRankingTampilan}>
                      <SelectTrigger className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="jarak">📏 Jarak (Terdekat → Terjauh)</SelectItem>
                        <SelectItem value="nilai">📝 Nilai (Tertinggi → Terendah)</SelectItem>
                        <SelectItem value="komposit">🏆 Skor Komposit (Tertinggi → Terendah)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {/* Jalur Filter */}
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-500">Jalur</label>
                    <Select value={rankingJalur} onValueChange={setRankingJalur}>
                      <SelectTrigger className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Jalur</SelectItem>
                        {rankingFilters.jalurOptions.filter((j: string) => j && j.trim() !== '').map((j: string) => (
                          <SelectItem key={j} value={j}>{j}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {/* Sekolah Filter */}
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-500">Sekolah Pilihan</label>
                    <Select value={rankingSekolah} onValueChange={setRankingSekolah}>
                      <SelectTrigger className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Sekolah</SelectItem>
                        {rankingFilters.sekolahOptions.map((s: string) => (
                          <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {/* Jurusan Filter */}
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-500">Jurusan</label>
                    <Select value={rankingJurusan} onValueChange={setRankingJurusan}>
                      <SelectTrigger className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Jurusan</SelectItem>
                        {rankingFilters.jurusanOptions.filter((j: string) => j && j.trim() !== '').map((j: string) => (
                          <SelectItem key={j} value={j}>{j}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {/* Status Filter */}
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-500">Status Verifikasi</label>
                    <Select value={rankingStatus} onValueChange={setRankingStatus}>
                      <SelectTrigger className="h-9 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Status</SelectItem>
                        <SelectItem value="PENDING">Menunggu</SelectItem>
                        <SelectItem value="VERIFIED">Diterima</SelectItem>
                        <SelectItem value="REJECTED">Ditolak</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {/* Show All toggle */}
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-500">Tampilkan</label>
                    <Button
                      size="sm"
                      variant={showAllRanking ? 'default' : 'outline'}
                      className={`h-9 w-full gap-1.5 text-xs whitespace-nowrap ${showAllRanking ? 'bg-amber-600 hover:bg-amber-700' : ''}`}
                      onClick={() => setShowAllRanking(!showAllRanking)}
                    >
                      <LayoutList className="w-3.5 h-3.5" />
                      {showAllRanking ? 'Batasi (50)' : 'Semua'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick View Cards: Domisili & Prestasi Ranking Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Domisili: Jarak Terdekat */}
              <Card className="border-sky-200 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="p-1.5 bg-sky-100 rounded-lg">
                      <MapPinned className="w-4 h-4 text-sky-600" />
                    </div>
                    <h4 className="font-semibold text-sm text-sky-900">Domisili — Jarak Terdekat</h4>
                  </div>
                  {(() => {
                    const domisiliData = rankingData
                      .filter((r: Record<string, unknown>) => (r.subJalur as string) === 'Domisili' && r._jarakNum as number > 0)
                      .sort((a: Record<string, unknown>, b: Record<string, unknown>) => (a._jarakNum as number) - (b._jarakNum as number))
                      .slice(0, 5)
                    if (domisiliData.length === 0) return <p className="text-xs text-gray-400 text-center py-3">Belum ada data jarak untuk Domisili</p>
                    const domKuota = rankingKuotaPerJalur.find(k => k.nama === 'Domisili')?.kuota || 0
                    return (
                      <div className="space-y-1.5">
                        {domisiliData.map((r: Record<string, unknown>, idx: number) => (
                          <div key={r.id as string} className={`flex items-center gap-2 p-2 rounded-lg ${idx < domKuota && domKuota > 0 ? 'bg-emerald-50 border border-emerald-200' : 'bg-gray-50 border border-gray-100'}`}>
                            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${idx < domKuota && domKuota > 0 ? 'bg-emerald-500 text-white' : 'bg-gray-300 text-white'}`}>
                              {idx + 1}
                            </span>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-gray-900 truncate">{r.nama as string}</p>
                              <p className="text-[10px] text-gray-500">{r.namaSekolahPilihan as string} — {r.jurusan as string}</p>
                            </div>
                            <div className="text-right shrink-0">
                              <p className="text-xs font-bold text-sky-700">{r.lokasiJarak as string || '-'}</p>
                              <p className="text-[10px] text-gray-400">jarak</p>
                            </div>
                          </div>
                        ))}
                        {domKuota > 0 && <p className="text-[10px] text-emerald-600 text-center mt-1">🟢 Hijau = masuk kuota ({domKuota})</p>}
                      </div>
                    )
                  })()}
                </CardContent>
              </Card>

              {/* Prestasi: Nilai Tertinggi */}
              <Card className="border-emerald-200 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="p-1.5 bg-emerald-100 rounded-lg">
                      <Award className="w-4 h-4 text-emerald-600" />
                    </div>
                    <h4 className="font-semibold text-sm text-emerald-900">Prestasi — Nilai Tertinggi</h4>
                  </div>
                  {(() => {
                    const prestasiData = rankingData
                      .filter((r: Record<string, unknown>) => {
                        const sj = (r.subJalur as string || '').toLowerCase()
                        return (sj.includes('prestasi') || sj.includes('akademik') || sj.includes('non')) && (r._nilaiNum as number) > 0
                      })
                      .sort((a: Record<string, unknown>, b: Record<string, unknown>) => (b._nilaiNum as number) - (a._nilaiNum as number))
                      .slice(0, 5)
                    if (prestasiData.length === 0) return <p className="text-xs text-gray-400 text-center py-3">Belum ada data nilai untuk Prestasi</p>
                    const presKuota = rankingKuotaPerJalur.find(k => k.nama.toLowerCase().includes('prestasi'))?.kuota || 0
                    return (
                      <div className="space-y-1.5">
                        {prestasiData.map((r: Record<string, unknown>, idx: number) => (
                          <div key={r.id as string} className={`flex items-center gap-2 p-2 rounded-lg ${idx < presKuota && presKuota > 0 ? 'bg-emerald-50 border border-emerald-200' : 'bg-gray-50 border border-gray-100'}`}>
                            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${idx < presKuota && presKuota > 0 ? 'bg-emerald-500 text-white' : 'bg-gray-300 text-white'}`}>
                              {idx + 1}
                            </span>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-gray-900 truncate">{r.nama as string}</p>
                              <p className="text-[10px] text-gray-500">{r.namaSekolahPilihan as string} — {r.jurusan as string}</p>
                            </div>
                            <div className="text-right shrink-0">
                              <p className="text-xs font-bold text-emerald-700">{r.nilaiRataRata as string || r.skorNilaiRaport as string || '-'}</p>
                              <p className="text-[10px] text-gray-400">Nilai Rata-rata</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )
                  })()}
                </CardContent>
              </Card>
            </div>

            {/* Full Ranking Table */}
            <Card className="shadow-sm">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base sm:text-lg flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-amber-500" />
                      Tabel Perangkingan
                      {rankingTampilan === 'jarak' && <Badge className="bg-sky-100 text-sky-700 border-sky-200">Jarak Terdekat</Badge>}
                      {rankingTampilan === 'nilai' && <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">Nilai Tertinggi</Badge>}
                      {rankingTampilan === 'komposit' && <Badge className="bg-amber-100 text-amber-700 border-amber-200">Skor Komposit</Badge>}
                    </CardTitle>
                    <CardDescription className="text-xs mt-1">
                      {rankingData.length} pendaftar
                      {rankingKuota > 0 && ` · Kuota: ${rankingKuota}`}
                      {rankingJalur !== 'all' && ` · Jalur: ${rankingJalur}`}
                    </CardDescription>
                  </div>
                  <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => fetchRanking()}>
                    <RefreshCw className="w-3 h-3" />
                    Refresh
                  </Button>
                  <div className="flex gap-1">
                    <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => openPreview('ranking', 'pdf')}>
                      <FileDown className="w-3 h-3" />
                      PDF
                    </Button>
                    <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => openPreview('ranking', 'excel')}>
                      <FileExcel className="w-3 h-3" />
                      Excel
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {rankingLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
                    <span className="ml-2 text-sm text-gray-500">Memuat data perangkingan...</span>
                  </div>
                ) : rankingData.length === 0 ? (
                  <div className="text-center py-12">
                    <Trophy className="w-12 h-12 mx-auto text-gray-300 mb-3" />
                    <p className="text-gray-500 text-sm">Belum ada data perangkingan</p>
                    <p className="text-gray-400 text-xs mt-1">Import data pendaftar terlebih dahulu</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50/80">
                          <TableHead className="w-10 text-center font-semibold text-xs">No</TableHead>
                          <TableHead className="w-10 text-center font-semibold text-xs">Jalur</TableHead>
                          <TableHead className="font-semibold text-xs">Nama Pendaftar</TableHead>
                          <TableHead className="font-semibold text-xs">Sekolah Pilihan</TableHead>
                          <TableHead className="font-semibold text-xs">Jurusan</TableHead>
                          <TableHead className="text-right font-semibold text-xs cursor-pointer select-none hover:bg-gray-100/80" onClick={() => setRankingTampilan('jarak')}>
                            <span className="inline-flex items-center gap-1 justify-end">
                              Jarak {rankingTampilan === 'jarak' ? <ArrowUp className="w-3 h-3 rotate-180" /> : <ArrowUpDown className="w-3 h-3 opacity-30" />}
                            </span>
                          </TableHead>
                          <TableHead className="text-right font-semibold text-xs cursor-pointer select-none hover:bg-gray-100/80" onClick={() => setRankingTampilan('nilai')}>
                            <span className="inline-flex items-center gap-1 justify-end">
                              Nilai Rata-rata {rankingTampilan === 'nilai' ? <ArrowDown className="w-3 h-3" /> : <ArrowUpDown className="w-3 h-3 opacity-30" />}
                            </span>
                          </TableHead>
                          <TableHead className="text-right font-semibold text-xs">Skor</TableHead>
                          <TableHead className="text-center font-semibold text-xs">Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(showAllRanking ? rankingData : rankingData.slice(0, 50)).map((r: Record<string, unknown>, idx: number) => {
                          const rankNum = (r._ranking as number) || (idx + 1)
                          const jalurRank = (r._jalurRank as number) || -1
                          const jarakNum = r._jarakNum as number
                          const nilaiNum = r._nilaiNum as number
                          const skorNum = r._skorNum as number
                          const isVerified = r.verificationStatus === 'VERIFIED'

                          // Determine kuota cutoff for current jalur
                          const currentKuota = rankingKuotaPerJalur.find(k => {
                            const jalurName = (r.subJalur as string || '').toLowerCase()
                            return k.nama.toLowerCase().includes(jalurName) || jalurName.includes(k.nama.toLowerCase())
                              || (k.nama.toLowerCase().includes('prestasi') && jalurName.includes('prestasi'))
                              || (k.nama.toLowerCase().includes('domisili') && jalurName.includes('domisili'))
                              || (k.nama.toLowerCase().includes('mutasi') && jalurName.includes('mutasi'))
                              || (k.nama.toLowerCase().includes('afirmasi') && (jalurName.includes('keluarga') || jalurName.includes('ktm')))
                          })?.kuota || 0

                          // Count how many of the same jalur are above this rank
                          const sameJalurAbove = rankingData
                            .filter((other: Record<string, unknown>) =>
                              (other.subJalur as string) === (r.subJalur as string) &&
                              ((other._ranking as number) || 0) < rankNum
                            ).length

                          const withinKuota = currentKuota > 0 && sameJalurAbove < currentKuota

                          return (
                            <TableRow key={r.id as string} className={`${withinKuota && !isVerified ? 'bg-emerald-50/50' : ''} ${isVerified ? 'bg-emerald-50' : ''} hover:bg-gray-50/80 transition-colors`}>
                              <TableCell className="text-center">
                                <span className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold ${
                                  rankNum === 1 ? 'bg-amber-400 text-white' :
                                  rankNum === 2 ? 'bg-gray-300 text-gray-700' :
                                  rankNum === 3 ? 'bg-amber-700 text-white' :
                                  withinKuota ? 'bg-emerald-100 text-emerald-700' :
                                  'bg-gray-100 text-gray-500'
                                }`}>
                                  {rankNum}
                                </span>
                              </TableCell>
                              <TableCell className="text-center">
                                <div className="flex flex-col items-center gap-0.5">
                                  <Badge variant="outline" className={`text-[10px] ${SUB_JALUR_COLORS[r.subJalur as string] || 'bg-gray-100 text-gray-700 border-gray-200'}`}>
                                    {r.subJalur as string}
                                  </Badge>
                                  {jalurRank > 0 && (
                                    <span className="inline-flex items-center justify-center w-5 h-5 rounded-full text-[9px] font-bold bg-sky-100 text-sky-700">
                                      #{jalurRank}
                                    </span>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                <div>
                                  <p className="text-xs font-medium text-gray-900">{r.nama as string}</p>
                                  <p className="text-[10px] text-gray-400">NISN: {r.nisn as string}</p>
                                </div>
                              </TableCell>
                              <TableCell className="text-xs text-gray-700">{r.namaSekolahPilihan as string}</TableCell>
                              <TableCell className="text-xs text-gray-600">{r.jurusan as string}</TableCell>
                              <TableCell className="text-right">
                                <span className={`text-xs font-semibold ${jarakNum > 0 ? 'text-sky-700' : 'text-gray-300'}`}>
                                  {r.lokasiJarak as string || '-'}
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                <span className={`text-xs font-semibold ${nilaiNum > 0 ? 'text-emerald-700' : 'text-gray-300'}`}>
                                  {r.nilaiRataRata as string || r.skorNilaiRaport as string || '-'}
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                <span className={`text-xs font-semibold ${skorNum > 0 ? 'text-amber-700' : 'text-gray-300'}`}>
                                  {r.skor as string || '-'}
                                </span>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={`text-[10px] ${STATUS_COLORS[r.verificationStatus as string] || 'bg-gray-100 text-gray-700'}`}>
                                  {r.verificationStatus === 'VERIFIED' ? 'Diterima' : r.verificationStatus === 'REJECTED' ? 'Ditolak' : 'Menunggu'}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== DITERIMA TAB ==================== */}
          <TabsContent value="diterima" className="space-y-6">
            {/* Elegant Header */}
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-600 p-4 sm:p-6 text-white">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
                  <div>
                    <h2 className="text-lg sm:text-2xl font-bold tracking-wide">LAPORAN PESERTA DITERIMA</h2>
                    <p className="text-emerald-100 mt-0.5 sm:mt-1 text-xs sm:text-sm">SPMB 2026 — Sistem Verifikasi Penerimaan Peserta Didik Baru</p>
                  </div>
                  <div className="flex gap-2">
                  <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('diterima', 'print')}>
                    <Printer className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Cetak</span>
                  </Button>
                  <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('diterima', 'pdf')}>
                    <FileDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">PDF</span>
                  </Button>
                  <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('diterima', 'excel')}>
                    <FileExcel className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Excel</span>
                  </Button>
                  </div>
                </div>
              </div>
              <CardContent className="p-3 sm:p-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4">
                  <div className="bg-emerald-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-emerald-100">
                    <p className="text-xl sm:text-3xl font-bold text-emerald-700">{stats?.verified || 0}</p>
                    <p className="text-[10px] sm:text-xs text-emerald-600 font-medium mt-0.5 sm:mt-1">Total Diterima</p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-emerald-100">
                    <p className="text-xl sm:text-3xl font-bold text-emerald-700">{stats?.total || 0}</p>
                    <p className="text-[10px] sm:text-xs text-emerald-600 font-medium mt-0.5 sm:mt-1">Total Pendaftar</p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-emerald-100">
                    <p className="text-xl sm:text-3xl font-bold text-emerald-700">{verifiedPercent}%</p>
                    <p className="text-[10px] sm:text-xs text-emerald-600 font-medium mt-0.5 sm:mt-1">Persentase Diterima</p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-emerald-100">
                    <p className="text-xl sm:text-3xl font-bold text-emerald-700">{stats?.verifiedBySubJalur?.length || 0}</p>
                    <p className="text-[10px] sm:text-xs text-emerald-600 font-medium mt-0.5 sm:mt-1">Jalur Aktif</p>
                  </div>
                </div>

                {/* Per Jalur Breakdown with Progress Bars */}
                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Distribusi Per Sub Jalur</h3>
                  <div className="space-y-2.5">
                    {stats?.verifiedBySubJalur.map((item) => (
                      <div key={item.name} className="flex items-center gap-3">
                        <Badge variant="outline" className={`${SUB_JALUR_COLORS[item.name] || 'bg-gray-100 text-gray-800'} min-w-[130px] justify-center text-xs`}>
                          {item.name}
                        </Badge>
                        <div className="flex-1 bg-gray-100 rounded-full h-5 relative overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                            style={{ width: stats?.verified ? `${(item.count / stats.verified) * 100}%` : '0%' }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-700 min-w-[40px] text-right">{item.count}</span>
                      </div>
                    ))}
                    {(!stats?.verifiedBySubJalur || stats.verifiedBySubJalur.length === 0) && (
                      <p className="text-xs text-gray-400 text-center py-2">Belum ada data</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filter Bar */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Filter className="w-4 h-4" /> Filter:
                  </div>
                  <Select value={diterimaFilterJalur} onValueChange={setDiterimaFilterJalur}>
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Sub Jalur" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Jalur</SelectItem>
                      {subJalurOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  <Select value={diterimaFilterSekolah} onValueChange={setDiterimaFilterSekolah}>
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Sekolah Pilihan" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Sekolah</SelectItem>
                      {stats?.verifiedBySekolah.map((item) => (
                        <SelectItem key={item.name} value={item.name}>{item.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    variant={showAllDiterima ? 'default' : 'outline'}
                    className={`h-8 gap-1.5 text-xs whitespace-nowrap ${showAllDiterima ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
                    onClick={() => setShowAllDiterima(!showAllDiterima)}
                  >
                    <LayoutList className="w-3.5 h-3.5" />
                    {showAllDiterima ? 'Batasi' : 'Semua'}
                  </Button>
                  <div className="sm:ml-auto text-sm text-gray-500">
                    Menampilkan {(() => {
                      const list = stats?.verifiedList || []
                      const filtered = list.filter(r =>
                        (diterimaFilterJalur === 'all' || r.subJalur === diterimaFilterJalur) &&
                        (diterimaFilterSekolah === 'all' || r.namaSekolahPilihan === diterimaFilterSekolah)
                      )
                      return filtered.length
                    })()} dari {stats?.verified || 0} peserta
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Table */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <ListChecks className="w-5 h-5 text-emerald-600" />
                  Daftar Peserta Diterima
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-white">
                      <TableRow className="bg-emerald-50/80">
                        <TableHead className="w-12 text-center">No</TableHead>
                        <TableHead>No. Registrasi</TableHead>
                        <TableHead className="cursor-pointer select-none hover:bg-emerald-100/80 transition-colors" onClick={toggleNamaSort}>
                          <span className="inline-flex items-center gap-1">
                            Nama
                            {namaSortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                             namaSortDir === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                             <ArrowUpDown className="w-3 h-3 opacity-30" />}
                          </span>
                        </TableHead>
                        <TableHead className="hidden md:table-cell">NISN</TableHead>
                        <TableHead>Sub Jalur</TableHead>
                        <TableHead className="hidden lg:table-cell">Sekolah Pilihan</TableHead>
                        <TableHead className="hidden lg:table-cell">Jurusan</TableHead>
                        <TableHead className="hidden sm:table-cell">Tanggal Verif</TableHead>
                        <TableHead className="text-center">Kelulusan</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(() => {
                        const list = stats?.verifiedList || []
                        const filtered = list.filter(r =>
                          (diterimaFilterJalur === 'all' || r.subJalur === diterimaFilterJalur) &&
                          (diterimaFilterSekolah === 'all' || r.namaSekolahPilihan === diterimaFilterSekolah)
                        )
                        const sorted = sortByName(filtered, namaSortDir)
                        const displayed = showAllDiterima ? sorted : sorted.slice(0, 20)
                        return displayed.length > 0 ? displayed.map((reg, idx) => (
                          <TableRow key={reg.id} className="hover:bg-emerald-50/30">
                            <TableCell className="text-center text-sm text-gray-500">{idx + 1}</TableCell>
                            <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                            <TableCell className="font-medium">{reg.nama}</TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-gray-500">{reg.nisn}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className={SUB_JALUR_COLORS[reg.subJalur] || 'bg-gray-100 text-gray-800'}>
                                {reg.subJalur}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">{reg.namaSekolahPilihan}</TableCell>
                            <TableCell className="hidden lg:table-cell">
                              <Badge variant="secondary">{reg.jurusan}</Badge>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell text-xs text-gray-500">
                              {reg.tanggalVerif || (reg.updatedAt ? new Date(reg.updatedAt).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }) : '-')}
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={`h-7 px-2 text-xs ${reg.statusKelulusan === 'LULUS' ? 'bg-green-100 text-green-700 hover:bg-green-200 font-bold' : 'text-gray-400 hover:bg-green-50 hover:text-green-600'}`}
                                  onClick={() => handleUpdateKelulusan(reg.id, 'LULUS')}
                                  title="Lulus"
                                >
                                  <CircleCheckBig className="w-3.5 h-3.5 mr-0.5" /> Lulus
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={`h-7 px-2 text-xs ${reg.statusKelulusan === 'TIDAK_LULUS' ? 'bg-orange-100 text-orange-700 hover:bg-orange-200 font-bold' : 'text-gray-400 hover:bg-orange-50 hover:text-orange-600'}`}
                                  onClick={() => handleUpdateKelulusan(reg.id, 'TIDAK_LULUS')}
                                  title="Tidak Lulus"
                                >
                                  <CircleX className="w-3.5 h-3.5 mr-0.5" /> Tidak
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => { setDetailTarget(reg); setDetailDialogOpen(true) }} title="Lihat Detail">
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}>
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-red-600 hover:text-white hover:bg-red-600" title="Hapus Data" onClick={() => openDeleteDialog(reg)}>
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={10} className="text-center py-12">
                              <UserCheck className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500 font-medium">Belum ada pendaftar yang diterima</p>
                              <p className="text-sm text-gray-400">Verifikasi pendaftar untuk menerimanya</p>
                            </TableCell>
                          </TableRow>
                        )
                      })()}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== DITOLAK TAB ==================== */}
          <TabsContent value="ditolak" className="space-y-6">
            {/* Elegant Header - Red Theme */}
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-red-700 via-red-600 to-rose-600 p-4 sm:p-6 text-white">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
                  <div>
                    <h2 className="text-lg sm:text-2xl font-bold tracking-wide">LAPORAN PESERTA DITOLAK</h2>
                    <p className="text-red-100 mt-0.5 sm:mt-1 text-xs sm:text-sm">SPMB 2026 — Sistem Verifikasi Penerimaan Peserta Didik Baru</p>
                  </div>
                  <div className="flex gap-2">
                  <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('ditolak', 'print')}>
                    <Printer className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Cetak</span>
                  </Button>
                  <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('ditolak', 'pdf')}>
                    <FileDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">PDF</span>
                  </Button>
                  <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('ditolak', 'excel')}>
                    <FileExcel className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Excel</span>
                  </Button>
                  </div>
                </div>
              </div>
              <CardContent className="p-3 sm:p-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4">
                  <div className="bg-red-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-red-100">
                    <p className="text-xl sm:text-3xl font-bold text-red-700">{stats?.rejected || 0}</p>
                    <p className="text-[10px] sm:text-xs text-red-600 font-medium mt-0.5 sm:mt-1">Total Ditolak</p>
                  </div>
                  <div className="bg-red-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-red-100">
                    <p className="text-xl sm:text-3xl font-bold text-red-700">{stats?.total || 0}</p>
                    <p className="text-[10px] sm:text-xs text-red-600 font-medium mt-0.5 sm:mt-1">Total Pendaftar</p>
                  </div>
                  <div className="bg-red-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-red-100">
                    <p className="text-xl sm:text-3xl font-bold text-red-700">{rejectedPercent}%</p>
                    <p className="text-[10px] sm:text-xs text-red-600 font-medium mt-0.5 sm:mt-1">Persentase Ditolak</p>
                  </div>
                  <div className="bg-red-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-red-100">
                    <p className="text-xl sm:text-3xl font-bold text-red-700">{stats?.rejectedBySubJalur?.length || 0}</p>
                    <p className="text-[10px] sm:text-xs text-red-600 font-medium mt-0.5 sm:mt-1">Jalur Aktif</p>
                  </div>
                </div>

                {/* Per Jalur Breakdown with Progress Bars */}
                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Distribusi Per Sub Jalur</h3>
                  <div className="space-y-2.5">
                    {stats?.rejectedBySubJalur.map((item) => (
                      <div key={item.name} className="flex items-center gap-3">
                        <Badge variant="outline" className={`${SUB_JALUR_COLORS[item.name] || 'bg-gray-100 text-gray-800'} min-w-[130px] justify-center text-xs`}>
                          {item.name}
                        </Badge>
                        <div className="flex-1 bg-gray-100 rounded-full h-5 relative overflow-hidden">
                          <div
                            className="h-full bg-red-500 rounded-full transition-all duration-500"
                            style={{ width: stats?.rejected ? `${(item.count / stats.rejected) * 100}%` : '0%' }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-700 min-w-[40px] text-right">{item.count}</span>
                      </div>
                    ))}
                    {(!stats?.rejectedBySubJalur || stats.rejectedBySubJalur.length === 0) && (
                      <p className="text-xs text-gray-400 text-center py-2">Belum ada data</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filter Bar */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Filter className="w-4 h-4" /> Filter:
                  </div>
                  <Select value={ditolakFilterJalur} onValueChange={setDitolakFilterJalur}>
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Sub Jalur" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Jalur</SelectItem>
                      {subJalurOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    variant={showAllDitolak ? 'default' : 'outline'}
                    className={`h-8 gap-1.5 text-xs whitespace-nowrap ${showAllDitolak ? 'bg-red-600 hover:bg-red-700' : ''}`}
                    onClick={() => setShowAllDitolak(!showAllDitolak)}
                  >
                    <LayoutList className="w-3.5 h-3.5" />
                    {showAllDitolak ? 'Batasi' : 'Semua'}
                  </Button>
                  <div className="sm:ml-auto text-sm text-gray-500">
                    Menampilkan {(() => {
                      const list = stats?.rejectedList || []
                      const filtered = list.filter(r => ditolakFilterJalur === 'all' || r.subJalur === ditolakFilterJalur)
                      return filtered.length
                    })()} dari {stats?.rejected || 0} peserta
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Table */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <FileText className="w-5 h-5 text-red-600" />
                  Daftar Peserta Ditolak
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-white">
                      <TableRow className="bg-red-50/80">
                        <TableHead className="w-12 text-center">No</TableHead>
                        <TableHead>No. Registrasi</TableHead>
                        <TableHead className="cursor-pointer select-none hover:bg-red-100/80 transition-colors" onClick={toggleNamaSort}>
                          <span className="inline-flex items-center gap-1">
                            Nama
                            {namaSortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                             namaSortDir === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                             <ArrowUpDown className="w-3 h-3 opacity-30" />}
                          </span>
                        </TableHead>
                        <TableHead className="hidden md:table-cell">NISN</TableHead>
                        <TableHead>Sub Jalur</TableHead>
                        <TableHead className="hidden lg:table-cell">Sekolah Pilihan</TableHead>
                        <TableHead className="hidden lg:table-cell">Jurusan</TableHead>
                        <TableHead className="hidden sm:table-cell">Alasan Penolakan</TableHead>
                        <TableHead className="text-center">Kelulusan</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(() => {
                        const list = stats?.rejectedList || []
                        const filtered = list.filter(r => ditolakFilterJalur === 'all' || r.subJalur === ditolakFilterJalur)
                        const sorted = sortByName(filtered, namaSortDir)
                        const displayed = showAllDitolak ? sorted : sorted.slice(0, 20)
                        return displayed.length > 0 ? displayed.map((reg, idx) => (
                          <TableRow key={reg.id} className="hover:bg-red-50/30">
                            <TableCell className="text-center text-sm text-gray-500">{idx + 1}</TableCell>
                            <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                            <TableCell className="font-medium">{reg.nama}</TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-gray-500">{reg.nisn}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className={SUB_JALUR_COLORS[reg.subJalur] || 'bg-gray-100 text-gray-800'}>
                                {reg.subJalur}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">{reg.namaSekolahPilihan}</TableCell>
                            <TableCell className="hidden lg:table-cell">
                              <Badge variant="secondary">{reg.jurusan}</Badge>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell text-sm text-gray-500 max-w-[200px] truncate">
                              {reg.verificationNote || <span className="text-gray-400 italic">Tidak ada alasan</span>}
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={`h-7 px-2 text-xs ${reg.statusKelulusan === 'LULUS' ? 'bg-green-100 text-green-700 hover:bg-green-200 font-bold' : 'text-gray-400 hover:bg-green-50 hover:text-green-600'}`}
                                  onClick={() => handleUpdateKelulusan(reg.id, 'LULUS')}
                                  title="Lulus"
                                >
                                  <CircleCheckBig className="w-3.5 h-3.5 mr-0.5" /> Lulus
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={`h-7 px-2 text-xs ${reg.statusKelulusan === 'TIDAK_LULUS' ? 'bg-orange-100 text-orange-700 hover:bg-orange-200 font-bold' : 'text-gray-400 hover:bg-orange-50 hover:text-orange-600'}`}
                                  onClick={() => handleUpdateKelulusan(reg.id, 'TIDAK_LULUS')}
                                  title="Tidak Lulus"
                                >
                                  <CircleX className="w-3.5 h-3.5 mr-0.5" /> Tidak
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => { setDetailTarget(reg); setDetailDialogOpen(true) }} title="Lihat Detail">
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}>
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" className="text-red-600 hover:text-white hover:bg-red-600" title="Hapus Data" onClick={() => openDeleteDialog(reg)}>
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={10} className="text-center py-12">
                              <UserX className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500 font-medium">Belum ada pendaftar yang ditolak</p>
                              <p className="text-sm text-gray-400">Semua pendaftar dalam proses verifikasi</p>
                            </TableCell>
                          </TableRow>
                        )
                      })()}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== LULUS TAB ==================== */}
          <TabsContent value="lulus" className="space-y-6">
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-green-700 via-green-600 to-emerald-600 p-4 sm:p-6 text-white">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
                  <div>
                    <h2 className="text-lg sm:text-2xl font-bold tracking-wide">DAFTAR PESERTA LULUS</h2>
                    <p className="text-green-100 mt-0.5 sm:mt-1 text-xs sm:text-sm">SPMB 2026 — Peserta yang dinyatakan Lulus</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('lulus', 'pdf')}>
                      <FileDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">PDF</span>
                    </Button>
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('lulus', 'excel')}>
                      <FileExcel className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Excel</span>
                    </Button>
                  </div>
                </div>
              </div>
              <CardContent className="p-3 sm:p-6">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 sm:gap-4">
                  <div className="bg-green-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-green-100">
                    <p className="text-xl sm:text-3xl font-bold text-green-700">{stats?.lulus || 0}</p>
                    <p className="text-[10px] sm:text-xs text-green-600 font-medium mt-0.5 sm:mt-1">Total Lulus</p>
                  </div>
                  <div className="bg-green-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-green-100">
                    <p className="text-xl sm:text-3xl font-bold text-green-700">{stats?.daftarUlang || 0}</p>
                    <p className="text-[10px] sm:text-xs text-green-600 font-medium mt-0.5 sm:mt-1">Daftar Ulang</p>
                  </div>
                  <div className="bg-orange-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-orange-100 col-span-2 md:col-span-1">
                    <p className="text-xl sm:text-3xl font-bold text-orange-700">{stats?.tidakDaftarUlang || 0}</p>
                    <p className="text-[10px] sm:text-xs text-orange-600 font-medium mt-0.5 sm:mt-1">Tidak Daftar Ulang</p>
                  </div>
                </div>
                {/* Per Jalur Breakdown */}
                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Distribusi Per Sub Jalur</h3>
                  <div className="space-y-2.5">
                    {stats?.lulusBySubJalur.map((item) => (
                      <div key={item.name} className="flex items-center gap-3">
                        <Badge variant="outline" className={`${SUB_JALUR_COLORS[item.name] || 'bg-gray-100 text-gray-800'} min-w-[130px] justify-center text-xs`}>
                          {item.name}
                        </Badge>
                        <div className="flex-1 bg-gray-100 rounded-full h-5 relative overflow-hidden">
                          <div className="h-full bg-green-500 rounded-full transition-all duration-500" style={{ width: stats?.lulus ? `${(item.count / stats.lulus) * 100}%` : '0%' }} />
                        </div>
                        <span className="text-sm font-semibold text-gray-700 min-w-[40px] text-right">{item.count}</span>
                      </div>
                    ))}
                    {(!stats?.lulusBySubJalur || stats.lulusBySubJalur.length === 0) && (
                      <p className="text-xs text-gray-400 text-center py-2">Belum ada data</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filter Bar */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <div className="flex items-center gap-2 text-sm text-gray-500"><Filter className="w-4 h-4" /> Filter:</div>
                  <Select value={lulusFilterJalur} onValueChange={setLulusFilterJalur}>
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Sub Jalur" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Jalur</SelectItem>
                      {subJalurOptions.map(opt => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    variant={showAllLulus ? 'default' : 'outline'}
                    className={`h-8 gap-1.5 text-xs whitespace-nowrap ${showAllLulus ? 'bg-green-600 hover:bg-green-700' : ''}`}
                    onClick={() => setShowAllLulus(!showAllLulus)}
                  >
                    <LayoutList className="w-3.5 h-3.5" />
                    {showAllLulus ? 'Batasi' : 'Semua'}
                  </Button>
                  <div className="sm:ml-auto text-sm text-gray-500">
                    Menampilkan {(() => {
                      const list = stats?.lulusList || []
                      return list.filter(r => lulusFilterJalur === 'all' || r.subJalur === lulusFilterJalur).length
                    })()} dari {stats?.lulus || 0} peserta
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Table */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <CircleCheckBig className="w-5 h-5 text-green-600" />
                  Daftar Peserta Lulus
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-white">
                      <TableRow className="bg-green-50/80">
                        <TableHead className="w-12 text-center">No</TableHead>
                        <TableHead>No. Registrasi</TableHead>
                        <TableHead className="cursor-pointer select-none hover:bg-green-100/80 transition-colors" onClick={toggleNamaSort}>
                          <span className="inline-flex items-center gap-1">
                            Nama
                            {namaSortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                             namaSortDir === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                             <ArrowUpDown className="w-3 h-3 opacity-30" />}
                          </span>
                        </TableHead>
                        <TableHead className="hidden md:table-cell">NISN</TableHead>
                        <TableHead>Sub Jalur</TableHead>
                        <TableHead className="hidden lg:table-cell">Sekolah Pilihan</TableHead>
                        <TableHead className="hidden lg:table-cell">Jurusan</TableHead>
                        <TableHead className="text-center">Daftar Ulang</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(() => {
                        const list = stats?.lulusList || []
                        const filtered = list.filter(r => lulusFilterJalur === 'all' || r.subJalur === lulusFilterJalur)
                        const sorted = sortByName(filtered, namaSortDir)
                        const displayed = showAllLulus ? sorted : sorted.slice(0, 20)
                        return displayed.length > 0 ? displayed.map((reg, idx) => (
                          <TableRow key={reg.id} className="hover:bg-green-50/30">
                            <TableCell className="text-center text-sm text-gray-500">{idx + 1}</TableCell>
                            <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                            <TableCell className="font-medium">{reg.nama}</TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-gray-500">{reg.nisn}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className={SUB_JALUR_COLORS[reg.subJalur] || 'bg-gray-100 text-gray-800'}>{reg.subJalur}</Badge>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">{reg.namaSekolahPilihan}</TableCell>
                            <TableCell className="hidden lg:table-cell"><Badge variant="secondary">{reg.jurusan}</Badge></TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-1">
                                <Button variant="ghost" size="sm" className={`h-7 px-2 text-xs ${reg.statusDaftarUlang === 'DAFTAR_ULANG' ? 'bg-teal-100 text-teal-700 hover:bg-teal-200 font-bold' : 'text-gray-400 hover:bg-teal-50 hover:text-teal-600'}`} onClick={() => handleUpdateDaftarUlang(reg.id, 'DAFTAR_ULANG')} title="Daftar Ulang">
                                  <ClipboardList className="w-3.5 h-3.5 mr-0.5" /> Ya
                                </Button>
                                <Button variant="ghost" size="sm" className={`h-7 px-2 text-xs ${reg.statusDaftarUlang === 'TIDAK_DAFTAR_ULANG' ? 'bg-rose-100 text-rose-700 hover:bg-rose-200 font-bold' : 'text-gray-400 hover:bg-rose-50 hover:text-rose-600'}`} onClick={() => handleUpdateDaftarUlang(reg.id, 'TIDAK_DAFTAR_ULANG')} title="Tidak Daftar Ulang">
                                  <UserMinus className="w-3.5 h-3.5 mr-0.5" /> Tidak
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => { setDetailTarget(reg); setDetailDialogOpen(true) }} title="Lihat Detail"><Eye className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}><Pencil className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="sm" className="text-red-600 hover:text-white hover:bg-red-600" title="Hapus Data" onClick={() => openDeleteDialog(reg)}><Trash2 className="w-4 h-4" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-12">
                              <CircleCheckBig className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500 font-medium">Belum ada peserta yang lulus</p>
                              <p className="text-sm text-gray-400">Tentukan status kelulusan pada menu Diterima atau Ditolak</p>
                            </TableCell>
                          </TableRow>
                        )
                      })()}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== TIDAK LULUS TAB ==================== */}
          <TabsContent value="tidak-lulus" className="space-y-6">
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-orange-700 via-orange-600 to-amber-600 p-4 sm:p-6 text-white">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
                  <div>
                    <h2 className="text-lg sm:text-2xl font-bold tracking-wide">DAFTAR PESERTA TIDAK LULUS</h2>
                    <p className="text-orange-100 mt-0.5 sm:mt-1 text-xs sm:text-sm">SPMB 2026 — Peserta yang dinyatakan Tidak Lulus</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('tidak-lulus', 'pdf')}>
                      <FileDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">PDF</span>
                    </Button>
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('tidak-lulus', 'excel')}>
                      <FileExcel className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Excel</span>
                    </Button>
                  </div>
                </div>
              </div>
              <CardContent className="p-3 sm:p-6">
                <div className="grid grid-cols-2 gap-2 sm:gap-4">
                  <div className="bg-orange-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-orange-100">
                    <p className="text-xl sm:text-3xl font-bold text-orange-700">{stats?.tidakLulus || 0}</p>
                    <p className="text-[10px] sm:text-xs text-orange-600 font-medium mt-0.5 sm:mt-1">Total Tidak Lulus</p>
                  </div>
                  <div className="bg-orange-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-orange-100">
                    <p className="text-xl sm:text-3xl font-bold text-orange-700">{stats?.total || 0}</p>
                    <p className="text-[10px] sm:text-xs text-orange-600 font-medium mt-0.5 sm:mt-1">Total Pendaftar</p>
                  </div>
                </div>
                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Distribusi Per Sub Jalur</h3>
                  <div className="space-y-2.5">
                    {stats?.tidakLulusBySubJalur.map((item) => (
                      <div key={item.name} className="flex items-center gap-3">
                        <Badge variant="outline" className={`${SUB_JALUR_COLORS[item.name] || 'bg-gray-100 text-gray-800'} min-w-[130px] justify-center text-xs`}>{item.name}</Badge>
                        <div className="flex-1 bg-gray-100 rounded-full h-5 relative overflow-hidden">
                          <div className="h-full bg-orange-500 rounded-full transition-all duration-500" style={{ width: stats?.tidakLulus ? `${(item.count / stats.tidakLulus) * 100}%` : '0%' }} />
                        </div>
                        <span className="text-sm font-semibold text-gray-700 min-w-[40px] text-right">{item.count}</span>
                      </div>
                    ))}
                    {(!stats?.tidakLulusBySubJalur || stats.tidakLulusBySubJalur.length === 0) && (<p className="text-xs text-gray-400 text-center py-2">Belum ada data</p>)}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filter Bar */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <div className="flex items-center gap-2 text-sm text-gray-500"><Filter className="w-4 h-4" /> Filter:</div>
                  <Select value={tidakLulusFilterJalur} onValueChange={setTidakLulusFilterJalur}>
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Sub Jalur" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Jalur</SelectItem>
                      {subJalurOptions.map(opt => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    variant={showAllTidakLulus ? 'default' : 'outline'}
                    className={`h-8 gap-1.5 text-xs whitespace-nowrap ${showAllTidakLulus ? 'bg-orange-600 hover:bg-orange-700' : ''}`}
                    onClick={() => setShowAllTidakLulus(!showAllTidakLulus)}
                  >
                    <LayoutList className="w-3.5 h-3.5" />
                    {showAllTidakLulus ? 'Batasi' : 'Semua'}
                  </Button>
                  <div className="sm:ml-auto text-sm text-gray-500">
                    Menampilkan {(() => {
                      const list = stats?.tidakLulusList || []
                      return list.filter(r => tidakLulusFilterJalur === 'all' || r.subJalur === tidakLulusFilterJalur).length
                    })()} dari {stats?.tidakLulus || 0} peserta
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Table */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <CircleX className="w-5 h-5 text-orange-600" />
                  Daftar Peserta Tidak Lulus
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-white">
                      <TableRow className="bg-orange-50/80">
                        <TableHead className="w-12 text-center">No</TableHead>
                        <TableHead>No. Registrasi</TableHead>
                        <TableHead className="cursor-pointer select-none hover:bg-orange-100/80 transition-colors" onClick={toggleNamaSort}>
                          <span className="inline-flex items-center gap-1">
                            Nama
                            {namaSortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                             namaSortDir === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                             <ArrowUpDown className="w-3 h-3 opacity-30" />}
                          </span>
                        </TableHead>
                        <TableHead className="hidden md:table-cell">NISN</TableHead>
                        <TableHead>Sub Jalur</TableHead>
                        <TableHead className="hidden lg:table-cell">Sekolah Pilihan</TableHead>
                        <TableHead className="hidden lg:table-cell">Jurusan</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(() => {
                        const list = stats?.tidakLulusList || []
                        const filtered = list.filter(r => tidakLulusFilterJalur === 'all' || r.subJalur === tidakLulusFilterJalur)
                        const sorted = sortByName(filtered, namaSortDir)
                        const displayed = showAllTidakLulus ? sorted : sorted.slice(0, 20)
                        return displayed.length > 0 ? displayed.map((reg, idx) => (
                          <TableRow key={reg.id} className="hover:bg-orange-50/30">
                            <TableCell className="text-center text-sm text-gray-500">{idx + 1}</TableCell>
                            <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                            <TableCell className="font-medium">{reg.nama}</TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-gray-500">{reg.nisn}</TableCell>
                            <TableCell><Badge variant="outline" className={SUB_JALUR_COLORS[reg.subJalur] || 'bg-gray-100 text-gray-800'}>{reg.subJalur}</Badge></TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">{reg.namaSekolahPilihan}</TableCell>
                            <TableCell className="hidden lg:table-cell"><Badge variant="secondary">{reg.jurusan}</Badge></TableCell>
                            <TableCell className="text-center">
                              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs bg-green-50 text-green-700 hover:bg-green-100" onClick={() => handleUpdateKelulusan(reg.id, 'LULUS')} title="Ubah ke Lulus">
                                <CircleCheckBig className="w-3.5 h-3.5 mr-0.5" /> Luluskan
                              </Button>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => { setDetailTarget(reg); setDetailDialogOpen(true) }} title="Lihat Detail"><Eye className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}><Pencil className="w-4 h-4" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-12">
                              <CircleX className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500 font-medium">Belum ada peserta yang tidak lulus</p>
                              <p className="text-sm text-gray-400">Tentukan status kelulusan pada menu Diterima atau Ditolak</p>
                            </TableCell>
                          </TableRow>
                        )
                      })()}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== DAFTAR ULANG TAB ==================== */}
          <TabsContent value="daftar-ulang" className="space-y-6">
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-teal-700 via-teal-600 to-cyan-600 p-4 sm:p-6 text-white">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
                  <div>
                    <h2 className="text-lg sm:text-2xl font-bold tracking-wide">DAFTAR PESERTA DAFTAR ULANG</h2>
                    <p className="text-teal-100 mt-0.5 sm:mt-1 text-xs sm:text-sm">SPMB 2026 — Peserta Lulus yang melakukan Daftar Ulang</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('daftar-ulang', 'pdf')}>
                      <FileDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">PDF</span>
                    </Button>
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('daftar-ulang', 'excel')}>
                      <FileExcel className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Excel</span>
                    </Button>
                  </div>
                </div>
              </div>
              <CardContent className="p-3 sm:p-6">
                <div className="grid grid-cols-2 gap-2 sm:gap-4">
                  <div className="bg-teal-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-teal-100">
                    <p className="text-xl sm:text-3xl font-bold text-teal-700">{stats?.daftarUlang || 0}</p>
                    <p className="text-[10px] sm:text-xs text-teal-600 font-medium mt-0.5 sm:mt-1">Total Daftar Ulang</p>
                  </div>
                  <div className="bg-teal-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-teal-100">
                    <p className="text-xl sm:text-3xl font-bold text-teal-700">{stats?.lulus || 0}</p>
                    <p className="text-[10px] sm:text-xs text-teal-600 font-medium mt-0.5 sm:mt-1">Total Lulus</p>
                  </div>
                </div>
                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Distribusi Per Sub Jalur</h3>
                  <div className="space-y-2.5">
                    {stats?.daftarUlangBySubJalur.map((item) => (
                      <div key={item.name} className="flex items-center gap-3">
                        <Badge variant="outline" className={`${SUB_JALUR_COLORS[item.name] || 'bg-gray-100 text-gray-800'} min-w-[130px] justify-center text-xs`}>{item.name}</Badge>
                        <div className="flex-1 bg-gray-100 rounded-full h-5 relative overflow-hidden">
                          <div className="h-full bg-teal-500 rounded-full transition-all duration-500" style={{ width: stats?.daftarUlang ? `${(item.count / stats.daftarUlang) * 100}%` : '0%' }} />
                        </div>
                        <span className="text-sm font-semibold text-gray-700 min-w-[40px] text-right">{item.count}</span>
                      </div>
                    ))}
                    {(!stats?.daftarUlangBySubJalur || stats.daftarUlangBySubJalur.length === 0) && (<p className="text-xs text-gray-400 text-center py-2">Belum ada data</p>)}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filter Bar */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <div className="flex items-center gap-2 text-sm text-gray-500"><Filter className="w-4 h-4" /> Filter:</div>
                  <Select value={daftarUlangFilterJalur} onValueChange={setDaftarUlangFilterJalur}>
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Sub Jalur" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Jalur</SelectItem>
                      {subJalurOptions.map(opt => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    variant={showAllDaftarUlang ? 'default' : 'outline'}
                    className={`h-8 gap-1.5 text-xs whitespace-nowrap ${showAllDaftarUlang ? 'bg-teal-600 hover:bg-teal-700' : ''}`}
                    onClick={() => setShowAllDaftarUlang(!showAllDaftarUlang)}
                  >
                    <LayoutList className="w-3.5 h-3.5" />
                    {showAllDaftarUlang ? 'Batasi' : 'Semua'}
                  </Button>
                  <div className="sm:ml-auto text-sm text-gray-500">
                    Menampilkan {(() => {
                      const list = stats?.daftarUlangList || []
                      return list.filter(r => daftarUlangFilterJalur === 'all' || r.subJalur === daftarUlangFilterJalur).length
                    })()} dari {stats?.daftarUlang || 0} peserta
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Table */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <ClipboardList className="w-5 h-5 text-teal-600" />
                  Daftar Peserta Daftar Ulang
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-white">
                      <TableRow className="bg-teal-50/80">
                        <TableHead className="w-12 text-center">No</TableHead>
                        <TableHead>No. Registrasi</TableHead>
                        <TableHead className="cursor-pointer select-none hover:bg-teal-100/80 transition-colors" onClick={toggleNamaSort}>
                          <span className="inline-flex items-center gap-1">
                            Nama
                            {namaSortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                             namaSortDir === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                             <ArrowUpDown className="w-3 h-3 opacity-30" />}
                          </span>
                        </TableHead>
                        <TableHead className="hidden md:table-cell">NISN</TableHead>
                        <TableHead>Sub Jalur</TableHead>
                        <TableHead className="hidden lg:table-cell">Sekolah Pilihan</TableHead>
                        <TableHead className="hidden lg:table-cell">Jurusan</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(() => {
                        const list = stats?.daftarUlangList || []
                        const filtered = list.filter(r => daftarUlangFilterJalur === 'all' || r.subJalur === daftarUlangFilterJalur)
                        const sorted = sortByName(filtered, namaSortDir)
                        const displayed = showAllDaftarUlang ? sorted : sorted.slice(0, 20)
                        return displayed.length > 0 ? displayed.map((reg, idx) => (
                          <TableRow key={reg.id} className="hover:bg-teal-50/30">
                            <TableCell className="text-center text-sm text-gray-500">{idx + 1}</TableCell>
                            <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                            <TableCell className="font-medium">{reg.nama}</TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-gray-500">{reg.nisn}</TableCell>
                            <TableCell><Badge variant="outline" className={SUB_JALUR_COLORS[reg.subJalur] || 'bg-gray-100 text-gray-800'}>{reg.subJalur}</Badge></TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">{reg.namaSekolahPilihan}</TableCell>
                            <TableCell className="hidden lg:table-cell"><Badge variant="secondary">{reg.jurusan}</Badge></TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => { setDetailTarget(reg); setDetailDialogOpen(true) }} title="Lihat Detail"><Eye className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}><Pencil className="w-4 h-4" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-12">
                              <ClipboardList className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500 font-medium">Belum ada peserta yang daftar ulang</p>
                              <p className="text-sm text-gray-400">Tentukan status daftar ulang pada menu Lulus</p>
                            </TableCell>
                          </TableRow>
                        )
                      })()}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== TIDAK DAFTAR ULANG TAB ==================== */}
          <TabsContent value="tidak-daftar-ulang" className="space-y-6">
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-rose-700 via-rose-600 to-pink-600 p-4 sm:p-6 text-white">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
                  <div>
                    <h2 className="text-lg sm:text-2xl font-bold tracking-wide">DAFTAR PESERTA TIDAK DAFTAR ULANG</h2>
                    <p className="text-rose-100 mt-0.5 sm:mt-1 text-xs sm:text-sm">SPMB 2026 — Peserta Lulus yang Tidak Daftar Ulang</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('tidak-daftar-ulang', 'pdf')}>
                      <FileDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">PDF</span>
                    </Button>
                    <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-white/30" onClick={() => openPreview('tidak-daftar-ulang', 'excel')}>
                      <FileExcel className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1 sm:mr-2" /> <span className="text-xs sm:text-sm">Excel</span>
                    </Button>
                  </div>
                </div>
              </div>
              <CardContent className="p-3 sm:p-6">
                <div className="grid grid-cols-2 gap-2 sm:gap-4">
                  <div className="bg-rose-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-rose-100">
                    <p className="text-xl sm:text-3xl font-bold text-rose-700">{stats?.tidakDaftarUlang || 0}</p>
                    <p className="text-[10px] sm:text-xs text-rose-600 font-medium mt-0.5 sm:mt-1">Total Tidak Daftar Ulang</p>
                  </div>
                  <div className="bg-rose-50 rounded-lg sm:rounded-xl p-3 sm:p-4 text-center border border-rose-100">
                    <p className="text-xl sm:text-3xl font-bold text-rose-700">{stats?.lulus || 0}</p>
                    <p className="text-[10px] sm:text-xs text-rose-600 font-medium mt-0.5 sm:mt-1">Total Lulus</p>
                  </div>
                </div>
                <div className="mt-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-3">Distribusi Per Sub Jalur</h3>
                  <div className="space-y-2.5">
                    {stats?.tidakDaftarUlangBySubJalur.map((item) => (
                      <div key={item.name} className="flex items-center gap-3">
                        <Badge variant="outline" className={`${SUB_JALUR_COLORS[item.name] || 'bg-gray-100 text-gray-800'} min-w-[130px] justify-center text-xs`}>{item.name}</Badge>
                        <div className="flex-1 bg-gray-100 rounded-full h-5 relative overflow-hidden">
                          <div className="h-full bg-rose-500 rounded-full transition-all duration-500" style={{ width: stats?.tidakDaftarUlang ? `${(item.count / stats.tidakDaftarUlang) * 100}%` : '0%' }} />
                        </div>
                        <span className="text-sm font-semibold text-gray-700 min-w-[40px] text-right">{item.count}</span>
                      </div>
                    ))}
                    {(!stats?.tidakDaftarUlangBySubJalur || stats.tidakDaftarUlangBySubJalur.length === 0) && (<p className="text-xs text-gray-400 text-center py-2">Belum ada data</p>)}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filter Bar */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  <div className="flex items-center gap-2 text-sm text-gray-500"><Filter className="w-4 h-4" /> Filter:</div>
                  <Select value={tidakDaftarUlangFilterJalur} onValueChange={setTidakDaftarUlangFilterJalur}>
                    <SelectTrigger className="w-full sm:w-[200px]"><SelectValue placeholder="Sub Jalur" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Jalur</SelectItem>
                      {subJalurOptions.map(opt => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    variant={showAllTidakDaftarUlang ? 'default' : 'outline'}
                    className={`h-8 gap-1.5 text-xs whitespace-nowrap ${showAllTidakDaftarUlang ? 'bg-rose-600 hover:bg-rose-700' : ''}`}
                    onClick={() => setShowAllTidakDaftarUlang(!showAllTidakDaftarUlang)}
                  >
                    <LayoutList className="w-3.5 h-3.5" />
                    {showAllTidakDaftarUlang ? 'Batasi' : 'Semua'}
                  </Button>
                  <div className="sm:ml-auto text-sm text-gray-500">
                    Menampilkan {(() => {
                      const list = stats?.tidakDaftarUlangList || []
                      return list.filter(r => tidakDaftarUlangFilterJalur === 'all' || r.subJalur === tidakDaftarUlangFilterJalur).length
                    })()} dari {stats?.tidakDaftarUlang || 0} peserta
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Table */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <UserMinus className="w-5 h-5 text-rose-600" />
                  Daftar Peserta Tidak Daftar Ulang
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-white">
                      <TableRow className="bg-rose-50/80">
                        <TableHead className="w-12 text-center">No</TableHead>
                        <TableHead>No. Registrasi</TableHead>
                        <TableHead className="cursor-pointer select-none hover:bg-rose-100/80 transition-colors" onClick={toggleNamaSort}>
                          <span className="inline-flex items-center gap-1">
                            Nama
                            {namaSortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> :
                             namaSortDir === 'desc' ? <ArrowDown className="w-3 h-3" /> :
                             <ArrowUpDown className="w-3 h-3 opacity-30" />}
                          </span>
                        </TableHead>
                        <TableHead className="hidden md:table-cell">NISN</TableHead>
                        <TableHead>Sub Jalur</TableHead>
                        <TableHead className="hidden lg:table-cell">Sekolah Pilihan</TableHead>
                        <TableHead className="hidden lg:table-cell">Jurusan</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(() => {
                        const list = stats?.tidakDaftarUlangList || []
                        const filtered = list.filter(r => tidakDaftarUlangFilterJalur === 'all' || r.subJalur === tidakDaftarUlangFilterJalur)
                        const sorted = sortByName(filtered, namaSortDir)
                        const displayed = showAllTidakDaftarUlang ? sorted : sorted.slice(0, 20)
                        return displayed.length > 0 ? displayed.map((reg, idx) => (
                          <TableRow key={reg.id} className="hover:bg-rose-50/30">
                            <TableCell className="text-center text-sm text-gray-500">{idx + 1}</TableCell>
                            <TableCell className="font-mono text-sm">{reg.noRegistrasi}</TableCell>
                            <TableCell className="font-medium">{reg.nama}</TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-gray-500">{reg.nisn}</TableCell>
                            <TableCell><Badge variant="outline" className={SUB_JALUR_COLORS[reg.subJalur] || 'bg-gray-100 text-gray-800'}>{reg.subJalur}</Badge></TableCell>
                            <TableCell className="hidden lg:table-cell text-sm">{reg.namaSekolahPilihan}</TableCell>
                            <TableCell className="hidden lg:table-cell"><Badge variant="secondary">{reg.jurusan}</Badge></TableCell>
                            <TableCell className="text-center">
                              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs bg-teal-50 text-teal-700 hover:bg-teal-100" onClick={() => handleUpdateDaftarUlang(reg.id, 'DAFTAR_ULANG')} title="Ubah ke Daftar Ulang">
                                <ClipboardList className="w-3.5 h-3.5 mr-0.5" /> Daftar Ulang
                              </Button>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="sm" onClick={() => { setDetailTarget(reg); setDetailDialogOpen(true) }} title="Lihat Detail"><Eye className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-white hover:bg-blue-600" title="Edit Data" onClick={() => openEditDialog(reg)}><Pencil className="w-4 h-4" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-12">
                              <UserMinus className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                              <p className="text-gray-500 font-medium">Belum ada peserta yang tidak daftar ulang</p>
                              <p className="text-sm text-gray-400">Tentukan status daftar ulang pada menu Lulus</p>
                            </TableCell>
                          </TableRow>
                        )
                      })()}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== PENGATURAN TAB ==================== */}
          <TabsContent value="pengaturan" className="space-y-6">
            {/* Header */}
            <Card className="overflow-hidden border-0 shadow-lg">
              <div className="bg-gradient-to-r from-sky-700 via-sky-600 to-cyan-600 p-4 sm:p-6 text-white">
                <div className="flex items-center gap-2 sm:gap-3">
                  <Settings className="w-6 h-6 sm:w-8 sm:h-8" />
                  <div>
                    <h2 className="text-lg sm:text-2xl font-bold tracking-wide">PENGATURAN KUOTA</h2>
                    <p className="text-sky-100 mt-0.5 sm:mt-1 text-xs sm:text-sm">SPMB 2026 — Atur kuota siswa dan persentase jalur pendaftaran</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Kuota Siswa */}
            <Card className="shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="w-5 h-5 text-sky-600" />
                  Kuota Siswa
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <label className="text-sm text-gray-500 font-medium">Jumlah Total Kuota Siswa Baru</label>
                    <div className="flex items-center gap-2 mt-2">
                      <Input
                        type="number"
                        min={0}
                        value={kuota}
                        onChange={(e) => setKuota(parseInt(e.target.value) || 0)}
                        className="max-w-[200px] text-lg font-bold"
                        placeholder="Masukkan kuota..."
                      />
                      <Button
                        onClick={saveKuota}
                        disabled={settingsSaving}
                        className="bg-sky-600 hover:bg-sky-700"
                      >
                        {settingsSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                        Simpan
                      </Button>
                    </div>
                  </div>
                  <div className="bg-sky-50 rounded-xl p-5 text-center border border-sky-100 min-w-[160px]">
                    <p className="text-4xl font-bold text-sky-700">{kuota}</p>
                    <p className="text-xs text-sky-600 font-medium mt-1">Total Kuota</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Distribusi Jalur */}
            <Card className="shadow-sm">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <ClipboardCheck className="w-5 h-5 text-amber-600" />
                    Distribusi Jalur Pendaftaran
                  </CardTitle>
                  <Button
                    onClick={() => setAddJalurOpen(true)}
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Plus className="w-4 h-4" />
                    Tambah Jalur
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {settingsLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
                    <p className="text-sm text-gray-400 ml-2">Memuat pengaturan...</p>
                  </div>
                ) : jalurConfigs.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-500">Belum ada jalur yang dikonfigurasi</p>
                    <Button className="mt-3 bg-emerald-600 hover:bg-emerald-700" onClick={() => setAddJalurOpen(true)}>
                      <Plus className="w-4 h-4" /> Tambah Jalur Pertama
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Total percentage bar */}
                    {(() => {
                      const totalPersen = jalurConfigs.filter(j => j.aktif).reduce((sum, j) => sum + j.persentase, 0)
                      const totalSiswa = jalurConfigs.filter(j => j.aktif).reduce((sum, j) => sum + Math.round(kuota * j.persentase / 100), 0)
                      return (
                        <div className={`rounded-xl p-4 border-2 ${totalPersen === 100 ? 'bg-emerald-50 border-emerald-300' : totalPersen > 100 ? 'bg-red-50 border-red-300' : 'bg-amber-50 border-amber-300'}`}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {totalPersen === 100 ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> :
                               totalPersen > 100 ? <AlertTriangle className="w-5 h-5 text-red-600" /> :
                               <AlertCircle className="w-5 h-5 text-amber-600" />}
                              <span className="font-semibold text-sm">
                                Total Persentase: {totalPersen.toFixed(1)}%
                              </span>
                            </div>
                            <span className="text-sm font-medium">
                              Total Siswa: <strong>{totalSiswa}</strong> dari {kuota} kuota
                            </span>
                          </div>
                          {/* Progress bar */}
                          <div className="mt-2 h-3 bg-gray-200 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${totalPersen === 100 ? 'bg-emerald-500' : totalPersen > 100 ? 'bg-red-500' : 'bg-amber-500'}`}
                              style={{ width: `${Math.min(totalPersen, 100)}%` }}
                            />
                          </div>
                          {totalPersen !== 100 && (
                            <p className={`text-xs mt-2 ${totalPersen > 100 ? 'text-red-600' : 'text-amber-600'}`}>
                              {totalPersen > 100
                                ? `⚠ Persentase melebihi 100%! Kurangi ${(totalPersen - 100).toFixed(1)}%`
                                : `ℹ Persentase belum 100%. Tambahkan ${(100 - totalPersen).toFixed(1)}% lagi`
                              }
                            </p>
                          )}
                        </div>
                      )
                    })()}

                    {/* Jalur list */}
                    <div className="border rounded-xl overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-sky-50/80">
                            <TableHead className="w-10 text-center">No</TableHead>
                            <TableHead>Jalur</TableHead>
                            <TableHead className="w-32 text-center">Persentase</TableHead>
                            <TableHead className="w-40 text-center">Jumlah Siswa</TableHead>
                            <TableHead className="w-24 text-center">Status</TableHead>
                            <TableHead className="w-28 text-right">Aksi</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {jalurConfigs.map((jalur, idx) => {
                            const jumlahSiswa = Math.round(kuota * jalur.persentase / 100)
                            const barWidth = Math.min(jalur.persentase, 100)
                            return (
                              <TableRow key={jalur.id} className={!jalur.aktif ? 'opacity-50' : ''}>
                                <TableCell className="text-center text-sm text-gray-500">{idx + 1}</TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <div
                                      className="w-3 h-3 rounded-full"
                                      style={{
                                        backgroundColor:
                                          jalur.nama === 'Domisili' ? '#3b82f6' :
                                          jalur.nama.includes('Afirmasi') || jalur.nama.includes('KTM') ? '#f59e0b' :
                                          jalur.nama.includes('Disabilitas') ? '#8b5cf6' :
                                          jalur.nama === 'Anak Guru' ? '#ec4899' :
                                          jalur.nama === 'Mutasi' ? '#06b6d4' :
                                          jalur.nama.includes('Prestasi') ? '#10b981' :
                                          jalur.nama.includes('Non Akademik') ? '#f97316' :
                                          '#6b7280'
                                      }}
                                    />
                                    <span className="font-medium text-sm">{jalur.nama}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="text-center">
                                  <div className="flex items-center justify-center gap-1">
                                    <Input
                                      type="number"
                                      min={0}
                                      max={100}
                                      step={0.5}
                                      value={jalur.persentase}
                                      onChange={(e) => {
                                        const val = parseFloat(e.target.value) || 0
                                        setJalurConfigs(prev => prev.map(j => j.id === jalur.id ? { ...j, persentase: val } : j))
                                      }}
                                      onBlur={() => updateJalurPersentase(jalur.id, jalur.persentase)}
                                      className="w-20 text-center text-sm font-bold"
                                    />
                                    <span className="text-xs text-gray-400">%</span>
                                  </div>
                                  {/* Mini progress bar */}
                                  <div className="mt-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-sky-400 rounded-full transition-all"
                                      style={{ width: `${barWidth}%` }}
                                    />
                                  </div>
                                </TableCell>
                                <TableCell className="text-center">
                                  <div className="inline-flex flex-col items-center">
                                    <span className="text-lg font-bold text-sky-700">{jumlahSiswa}</span>
                                    <span className="text-xs text-gray-400">siswa</span>
                                  </div>
                                </TableCell>
                                <TableCell className="text-center">
                                  <button
                                    onClick={() => toggleJalurAktif(jalur.id, !jalur.aktif)}
                                    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium transition-colors ${
                                      jalur.aktif
                                        ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                                        : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                                    }`}
                                  >
                                    {jalur.aktif ? <><CheckCircle2 className="w-3 h-3" /> Aktif</> : <><XCircle className="w-3 h-3" /> Nonaktif</>}
                                  </button>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                    onClick={() => deleteJalur(jalur.id, jalur.nama)}
                                    title="Hapus jalur"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            )
                          })}
                        </TableBody>
                      </Table>
                    </div>

                    {/* Summary Cards */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
                      {jalurConfigs.filter(j => j.aktif).map(jalur => {
                        const jumlahSiswa = Math.round(kuota * jalur.persentase / 100)
                        const colors: Record<string, string> = {
                          'Domisili': 'from-blue-500 to-blue-600',
                          'Afirmasi (KTM)': 'from-amber-500 to-amber-600',
                          'Disabilitas': 'from-purple-500 to-purple-600',
                          'Anak Guru': 'from-pink-500 to-pink-600',
                          'Mutasi': 'from-cyan-500 to-cyan-600',
                          'Prestasi Nilai Rapor': 'from-emerald-500 to-emerald-600',
                          'Prestasi Non Akademik': 'from-orange-500 to-orange-600',
                        }
                        const gradient = colors[jalur.nama] || 'from-gray-500 to-gray-600'
                        return (
                          <div key={jalur.id} className={`rounded-xl p-4 text-white bg-gradient-to-br ${gradient} shadow-sm`}>
                            <p className="text-xs font-medium opacity-80">{jalur.nama}</p>
                            <p className="text-3xl font-bold mt-1">{jumlahSiswa}</p>
                            <p className="text-xs opacity-70 mt-0.5">{jalur.persentase}% dari {kuota}</p>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Sinkronisasi Portal SPMB */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Globe className="w-5 h-5 text-indigo-600" />
                  Sinkronisasi Portal SPMB
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
                    <div className="flex items-start gap-3">
                      <Globe className="w-5 h-5 text-indigo-600 mt-0.5 shrink-0" />
                      <div className="text-sm text-indigo-700">
                        <p className="font-medium">Ambil data otomatis dari portal SPMB Sumatera Utara</p>
                        <p className="mt-1 text-indigo-600">Masukkan kredensial login portal untuk mengambil data pendaftar secara otomatis. Data akan disinkronkan dengan database lokal menggunakan deduplikasi NISN.</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5" /> Email Portal
                      </label>
                      <Input
                        type="email"
                        value={portalSyncEmail}
                        onChange={(e) => setPortalSyncEmail(e.target.value)}
                        placeholder="email@disdik.sumutprov.go.id"
                        className="mt-1.5"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 flex items-center gap-1.5">
                        <Lock className="w-3.5 h-3.5" /> Password Portal
                      </label>
                      <Input
                        type="password"
                        value={portalSyncPassword}
                        onChange={(e) => setPortalSyncPassword(e.target.value)}
                        placeholder="Masukkan password..."
                        className="mt-1.5"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Status Pendaftar</label>
                      <select
                        value={portalSyncStatus}
                        onChange={(e) => setPortalSyncStatus(e.target.value)}
                        className="mt-1.5 w-full h-10 px-3 border border-gray-200 rounded-md text-sm bg-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                      >
                        <option value="accepted">Accepted (Diterima)</option>
                        <option value="">Semua Status</option>
                        <option value="pending">Pending</option>
                        <option value="rejected">Rejected</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Jumlah Halaman</label>
                      <Input
                        type="number"
                        min={1}
                        max={100}
                        value={portalSyncPages}
                        onChange={(e) => setPortalSyncPages(parseInt(e.target.value) || 10)}
                        className="mt-1.5"
                      />
                      <p className="text-xs text-gray-400 mt-1">Setiap halaman berisi 10 data</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Button
                      onClick={handlePortalSync}
                      disabled={portalSyncing}
                      className="bg-indigo-600 hover:bg-indigo-700"
                    >
                      {portalSyncing ? (
                        <><Loader2 className="w-4 h-4 animate-spin" /> Menyinkronkan...</>
                      ) : (
                        <><RefreshCw className="w-4 h-4" /> Mulai Sinkronisasi</>
                      )}
                    </Button>
                    <a
                      href="https://adminspmb.disdik.sumutprov.go.id/admin/registration"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-indigo-600 hover:text-indigo-800 underline"
                    >
                      Buka Portal SPMB ↗
                    </a>
                  </div>

                  {/* Sync Result */}
                  {portalSyncResult && (
                    <div className={`rounded-xl p-4 border-2 ${portalSyncResult.success ? 'bg-emerald-50 border-emerald-300' : 'bg-red-50 border-red-300'}`}>
                      <div className="flex items-start gap-3">
                        {portalSyncResult.success ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
                        ) : (
                          <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 shrink-0" />
                        )}
                        <div>
                          <p className={`font-semibold text-sm ${portalSyncResult.success ? 'text-emerald-700' : 'text-red-700'}`}>
                            {portalSyncResult.success ? 'Sinkronisasi Berhasil' : 'Sinkronisasi Gagal'}
                          </p>
                          <p className={`text-sm mt-1 ${portalSyncResult.success ? 'text-emerald-600' : 'text-red-600'}`}>
                            {portalSyncResult.message}
                          </p>
                          {portalSyncResult.success && portalSyncResult.total !== undefined && (
                            <div className="flex items-center gap-4 mt-3">
                              <div className="text-center">
                                <p className="text-2xl font-bold text-emerald-700">{portalSyncResult.created}</p>
                                <p className="text-xs text-emerald-600">Data Baru</p>
                              </div>
                              <div className="text-center">
                                <p className="text-2xl font-bold text-amber-600">{portalSyncResult.updated}</p>
                                <p className="text-xs text-amber-600">Diperbarui</p>
                              </div>
                              <div className="text-center">
                                <p className="text-2xl font-bold text-gray-500">{portalSyncResult.unchanged}</p>
                                <p className="text-xs text-gray-500">Tidak Berubah</p>
                              </div>
                              <div className="text-center">
                                <p className="text-2xl font-bold text-sky-700">{portalSyncResult.total}</p>
                                <p className="text-xs text-sky-700">Total Diambil</p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Admin Password Management */}
            {authUser?.role === 'admin' && (
            <Card className="shadow-sm hover:shadow-md transition-shadow border-amber-200">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Lock className="w-5 h-5 text-amber-600" />
                    Password Admin
                  </CardTitle>
                  <Button
                    onClick={() => setAdminPasswordOpen(true)}
                    size="sm"
                    className="bg-amber-600 hover:bg-amber-700"
                  >
                    <Pencil className="w-4 h-4" />
                    Ubah Password
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3 p-3 rounded-lg border bg-amber-50/50">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0 bg-amber-100 text-amber-700">
                    <Lock className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-gray-900 truncate">Password Akun Admin</p>
                      <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200">
                        Admin
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-400">Klik "Ubah Password" untuk mengganti password akun admin Anda</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            )}

            {/* Manajemen Pengguna */}
            {authUser?.role === 'admin' && (
            <Card className="shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <UserCog className="w-5 h-5 text-emerald-600" />
                    Manajemen Pengguna
                  </CardTitle>
                  <Button
                    onClick={() => { setAddUserOpen(true); fetchUsers() }}
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Plus className="w-4 h-4" />
                    Tambah Verifikator
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
                    <p className="text-sm text-gray-400 ml-2">Memuat data pengguna...</p>
                  </div>
                ) : users.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                    <p className="text-gray-500 text-sm">Belum ada data pengguna</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {users.map(user => (
                      <div key={user.id} className={`flex items-center gap-3 p-3 rounded-lg border ${user.aktif ? 'bg-white border-gray-100' : 'bg-gray-50 border-gray-200 opacity-60'}`}>
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${user.role === 'admin' ? 'bg-amber-100 text-amber-700' : 'bg-sky-100 text-sky-700'}`}>
                          {user.namaLengkap.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium text-gray-900 truncate">{user.namaLengkap}</p>
                            <Badge variant="outline" className={`text-[10px] ${user.role === 'admin' ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-sky-50 text-sky-700 border-sky-200'}`}>
                              {user.role === 'admin' ? 'Admin' : 'Verifikator'}
                            </Badge>
                            {!user.aktif && <Badge variant="outline" className="text-[10px] bg-red-50 text-red-600 border-red-200">Nonaktif</Badge>}
                          </div>
                          <p className="text-xs text-gray-400">@{user.username} · Bergabung {new Date(user.createdAt).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })}</p>
                          {user.lastLogin && (
                            <p className="text-[10px] text-gray-400">Terakhir login: {new Date(user.lastLogin).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0"
                            onClick={() => handleToggleUserAktif(user.id, user.aktif, user.namaLengkap)}
                            title={user.aktif ? 'Nonaktifkan' : 'Aktifkan'}
                          >
                            {user.aktif ? <Eye className="w-3.5 h-3.5 text-emerald-500" /> : <Eye className="w-3.5 h-3.5 text-gray-300" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0"
                            onClick={() => { setEditUserTarget({ id: user.id, username: user.username, namaLengkap: user.namaLengkap, role: user.role, aktif: user.aktif }); setEditUserPassword(''); setEditUserOpen(true) }}
                            title="Edit"
                          >
                            <Pencil className="w-3.5 h-3.5 text-sky-500" />
                          </Button>
                          {user.role !== 'admin' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0"
                              onClick={() => handleDeleteUser(user.id, user.namaLengkap)}
                              title="Hapus"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-400" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            )}

            {/* Add Jalur Dialog */}
            <Dialog open={addJalurOpen} onOpenChange={setAddJalurOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Plus className="w-5 h-5 text-emerald-600" />
                    Tambah Jalur Baru
                  </DialogTitle>
                  <DialogDescription>Tambahkan jalur pendaftaran baru untuk SPMB 2026</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Nama Jalur</label>
                    <Input
                      value={newJalurNama}
                      onChange={(e) => setNewJalurNama(e.target.value)}
                      placeholder="Contoh: Zonasi, Perpindahan Orang Tua"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Persentase Kuota (%)</label>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      step={0.5}
                      value={newJalurPersentase}
                      onChange={(e) => setNewJalurPersentase(parseFloat(e.target.value) || 0)}
                      className="mt-1"
                    />
                  </div>
                  {newJalurPersentase > 0 && kuota > 0 && (
                    <div className="bg-sky-50 rounded-lg p-3 border border-sky-200">
                      <p className="text-sm text-sky-700">
                        Estimasi jumlah siswa: <strong>{Math.round(kuota * newJalurPersentase / 100)}</strong> siswa
                      </p>
                    </div>
                  )}
                </div>
                <DialogFooter className="gap-2">
                  <Button variant="outline" onClick={() => setAddJalurOpen(false)}>Batal</Button>
                  <Button onClick={addJalur} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="w-4 h-4" /> Tambah
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Dialog: Tambah Pengguna */}
            <Dialog open={addUserOpen} onOpenChange={setAddUserOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <UserCog className="w-5 h-5 text-emerald-600" />
                    Tambah Pengguna Verifikator
                  </DialogTitle>
                  <DialogDescription>Buat akun baru untuk verifikator yang akan membantu proses verifikasi pendaftaran</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Nama Lengkap</label>
                    <Input value={newUserNama} onChange={e => setNewUserNama(e.target.value)} placeholder="Masukkan nama lengkap..." className="mt-1" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Username</label>
                    <Input value={newUserUsername} onChange={e => setNewUserUsername(e.target.value)} placeholder="Minimal 3 karakter..." className="mt-1" autoComplete="off" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Password</label>
                    <Input type="password" value={newUserPassword} onChange={e => setNewUserPassword(e.target.value)} placeholder="Minimal 6 karakter..." className="mt-1" autoComplete="new-password" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Role</label>
                    <Select value={newUserRole} onValueChange={setNewUserRole}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="verifikator">Verifikator</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter className="gap-2">
                  <Button variant="outline" onClick={() => setAddUserOpen(false)}>Batal</Button>
                  <Button onClick={handleAddUser} disabled={savingUser} className="bg-emerald-600 hover:bg-emerald-700">
                    {savingUser ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    Tambah
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Dialog: Edit Pengguna */}
            <Dialog open={editUserOpen} onOpenChange={setEditUserOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Pencil className="w-5 h-5 text-sky-600" />
                    Edit Pengguna
                  </DialogTitle>
                  <DialogDescription>Perbarui data pengguna. Kosongkan password jika tidak ingin mengubahnya.</DialogDescription>
                </DialogHeader>
                {editUserTarget && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Nama Lengkap</label>
                      <Input value={editUserTarget.namaLengkap} onChange={e => setEditUserTarget({ ...editUserTarget, namaLengkap: e.target.value })} className="mt-1" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Username</label>
                      <Input value={editUserTarget.username} onChange={e => setEditUserTarget({ ...editUserTarget, username: e.target.value })} className="mt-1" autoComplete="off" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Password Baru</label>
                      <Input type="password" value={editUserPassword} onChange={e => setEditUserPassword(e.target.value)} placeholder="Kosongkan jika tidak diubah..." className="mt-1" autoComplete="new-password" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700">Role</label>
                      <Select value={editUserTarget.role} onValueChange={v => setEditUserTarget({ ...editUserTarget, role: v })}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="verifikator">Verifikator</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
                <DialogFooter className="gap-2">
                  <Button variant="outline" onClick={() => { setEditUserOpen(false); setEditUserTarget(null) }}>Batal</Button>
                  <Button onClick={handleEditUser} disabled={savingUser} className="bg-sky-600 hover:bg-sky-700">
                    {savingUser ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    Simpan
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Dialog: Admin Change Password */}
            <Dialog open={adminPasswordOpen} onOpenChange={setAdminPasswordOpen}>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Lock className="w-5 h-5 text-amber-600" />
                    Ubah Password Admin
                  </DialogTitle>
                  <DialogDescription>Masukkan password baru untuk akun admin Anda.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Password Baru</label>
                    <div className="relative mt-1">
                      <Input
                        type={showAdminPassword ? 'text' : 'password'}
                        value={adminPasswordNew}
                        onChange={e => setAdminPasswordNew(e.target.value)}
                        placeholder="Minimal 6 karakter..."
                        autoComplete="new-password"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                        onClick={() => setShowAdminPassword(!showAdminPassword)}
                        tabIndex={-1}
                      >
                        {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Konfirmasi Password Baru</label>
                    <Input
                      type="password"
                      value={adminPasswordConfirm}
                      onChange={e => setAdminPasswordConfirm(e.target.value)}
                      placeholder="Ulangi password baru..."
                      className="mt-1"
                      autoComplete="new-password"
                    />
                  </div>
                  {adminPasswordNew && adminPasswordConfirm && adminPasswordNew !== adminPasswordConfirm && (
                    <p className="text-xs text-red-500">Password tidak cocok</p>
                  )}
                </div>
                <DialogFooter className="gap-2">
                  <Button variant="outline" onClick={() => { setAdminPasswordOpen(false); setAdminPasswordNew(''); setAdminPasswordConfirm(''); setShowAdminPassword(false) }}>Batal</Button>
                  <Button onClick={handleAdminChangePassword} disabled={adminPasswordSaving || !adminPasswordNew || adminPasswordNew !== adminPasswordConfirm} className="bg-amber-600 hover:bg-amber-700">
                    {adminPasswordSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    Simpan
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-gradient-to-r from-slate-900 via-emerald-900 to-slate-900 mt-auto">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-1 sm:gap-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />
              <p className="text-xs sm:text-sm text-emerald-100 font-medium">&copy; 2026 SPMB Verifikasi System</p>
            </div>
            <p className="text-[10px] sm:text-xs text-emerald-200/60">Sistem Verifikasi Penerimaan Peserta Didik Baru</p>
          </div>
        </div>
      </footer>

      {/* ==================== IMPORT DIALOG ==================== */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-emerald-600" />
              Import Data CSV
            </DialogTitle>
            <DialogDescription>
              Import data pendaftar dari file CSV. Format harus sesuai template SPMB 2026.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div
              className="border-2 border-dashed rounded-lg p-8 text-center hover:border-emerald-400 transition-colors cursor-pointer"
              onClick={() => document.getElementById('csv-upload')?.click()}
              onDragOver={(e) => { e.preventDefault(); e.stopPropagation() }}
              onDrop={(e) => {
                e.preventDefault(); e.stopPropagation()
                const file = e.dataTransfer.files[0]
                if (file && file.name.endsWith('.csv')) setCsvFile(file)
              }}
            >
              <FileSpreadsheet className="w-10 h-10 mx-auto text-gray-400 mb-3" />
              {csvFile ? (
                <div>
                  <p className="font-medium text-emerald-700">{csvFile.name}</p>
                  <p className="text-sm text-gray-500">{(csvFile.size / 1024).toFixed(1)} KB</p>
                </div>
              ) : (
                <div>
                  <p className="font-medium text-gray-700">Klik atau seret file CSV ke sini</p>
                  <p className="text-sm text-gray-400 mt-1">Format: No.Registrasi, Nama, NISN, Sub Jalur, dll.</p>
                </div>
              )}
              <input
                id="csv-upload"
                type="file"
                accept=".csv"
                className="hidden"
                onChange={(e) => { const file = e.target.files?.[0]; if (file) setCsvFile(file) }}
              />
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <div className="flex gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                <div className="text-sm text-amber-700">
                  <p className="font-medium">Format CSV yang diharapkan:</p>
                  <p className="mt-1">No.Registrasi, Nama, NISN, Sub Jalur, NPSN Sekolah Pilihan, Nama Sekolah Pilihan, Jurusan, NPSN Sekolah Asal, Nama Sekolah Asal, Status, Waktu Daftar</p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)}>Batal</Button>
            <Button onClick={handleImport} disabled={!csvFile || importing} className="bg-emerald-600 hover:bg-emerald-700">
              {importing ? (<><Loader2 className="w-4 h-4 animate-spin" /> Mengimport...</>) : (<><Upload className="w-4 h-4" /> Import</>)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ==================== PORTAL PASTE DIALOG ==================== */}
      <Dialog open={portalPasteOpen} onOpenChange={(open) => {
        setPortalPasteOpen(open)
        if (!open) { setPortalRawText(''); setPortalParsedData(null); setPortalSelectedJalur('') }
      }}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ClipboardPaste className="w-5 h-5 text-emerald-600" />
              Paste dari Portal SPMB
            </DialogTitle>
            <DialogDescription>
              Copy data dari halaman detail peserta di portal SPMB Sumut, lalu paste di sini. Sistem akan otomatis mengenali dan memparse data.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {!portalParsedData ? (
              <>
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
                  <div className="flex gap-2">
                    <ClipboardCheck className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                    <div className="text-sm text-emerald-700">
                      <p className="font-medium">Cara penggunaan:</p>
                      <ol className="mt-1 list-decimal list-inside space-y-0.5">
                        <li>Buka portal SPMB Sumut</li>
                        <li>Buka halaman detail peserta</li>
                        <li>Select all (Ctrl+A) lalu Copy (Ctrl+C)</li>
                        <li>Paste (Ctrl+V) di kotak di bawah ini</li>
                        <li>Klik &quot;Parse Data&quot; untuk memproses</li>
                      </ol>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1.5 block">
                    Data dari Portal SPMB
                  </label>
                  <Textarea
                    placeholder="Paste data dari portal SPMB di sini...&#10;&#10;Contoh format yang dikenali:&#10;SANDYON ARTHUR NAVORA WAU&#10;No. Registrasi: 6&#10;&#10;Domisili&#10;Data Peserta&#10;Nama Peserta&#10;SANDYON ARTHUR NAVORA WAU&#10;..."
                    value={portalRawText}
                    onChange={(e) => setPortalRawText(e.target.value)}
                    rows={12}
                    className="font-mono text-xs"
                  />
                </div>
              </>
            ) : (
              <>
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div className="text-sm text-emerald-700">
                      <p className="font-medium">Data berhasil diparse!</p>
                      <p>Periksa data di bawah sebelum menyimpan.</p>
                    </div>
                  </div>
                </div>

                {/* Parsed Data Preview */}
                <div className="space-y-3">
                  {/* Header with name and sub jalur */}
                  <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-emerald-100 rounded-lg">
                          <Users className="w-6 h-6 text-emerald-600" />
                        </div>
                        <div className="flex-1">
                          <p className="text-lg font-bold text-gray-900">{portalParsedData.nama || '-'}</p>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <Badge variant="outline" className="font-mono">No. Reg: {portalParsedData.noRegistrasi || '-'}</Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Jalur Pendaftaran Selector */}
                  <Card className="border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-white">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-amber-100 rounded-lg">
                          <ClipboardCheck className="w-5 h-5 text-amber-600" />
                        </div>
                        <div className="flex-1">
                          <label className="text-sm font-semibold text-amber-800 block mb-1">
                            Jalur Pendaftaran
                          </label>
                          <Select value={portalSelectedJalur} onValueChange={setPortalSelectedJalur}>
                            <SelectTrigger className="w-full bg-white">
                              <SelectValue placeholder="Pilih jalur pendaftaran..." />
                            </SelectTrigger>
                            <SelectContent>
                              {jalurConfigs.filter(j => j.aktif).map(jalur => (
                                <SelectItem key={jalur.id} value={jalur.nama}>
                                  <div className="flex items-center gap-2">
                                    {(() => {
                                      const Icon = getJalurIcon(jalur.nama)
                                      return <Icon className="w-4 h-4" />
                                    })()}
                                    <span>{jalur.nama}</span>
                                    <span className="text-xs text-gray-400">→ {getJalurSubFilter(jalur.nama)}</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {portalSelectedJalur && (
                            <div className="flex items-center gap-1.5 mt-1.5">
                              <span className="text-xs text-gray-500">Data akan masuk ke Lembar Verifikasi:</span>
                              <Badge variant="outline" className={SUB_JALUR_COLORS[getJalurSubFilter(portalSelectedJalur)] || 'bg-gray-100 text-gray-800'}>
                                {getJalurSubFilter(portalSelectedJalur)}
                              </Badge>
                            </div>
                          )}
                          {!portalSelectedJalur && (
                            <p className="text-xs text-red-500 mt-1">⚠️ Pilih jalur pendaftaran sebelum menyimpan</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Data Details Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    {portalParsedData.nisn && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><IdCard className="w-3 h-3" /> NISN</label>
                        <p className="text-sm font-mono font-medium mt-0.5">{portalParsedData.nisn}</p>
                      </div>
                    )}
                    {portalParsedData.nik && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><IdCard className="w-3 h-3" /> NIK</label>
                        <p className="text-sm font-mono font-medium mt-0.5">{portalParsedData.nik}</p>
                      </div>
                    )}
                    {portalParsedData.tanggalLahir && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><CalendarDays className="w-3 h-3" /> Tanggal Lahir</label>
                        <p className="text-sm mt-0.5">{portalParsedData.tanggalLahir}</p>
                      </div>
                    )}
                    {portalParsedData.noTelpSiswa && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Phone className="w-3 h-3" /> Telp Siswa</label>
                        <p className="text-sm font-mono mt-0.5">{portalParsedData.noTelpSiswa}</p>
                      </div>
                    )}
                    {portalParsedData.noTelpOrangtua && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Phone className="w-3 h-3" /> Telp Orangtua</label>
                        <p className="text-sm font-mono mt-0.5">{portalParsedData.noTelpOrangtua}</p>
                      </div>
                    )}
                    {portalParsedData.lokasiJarak && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><MapPinned className="w-3 h-3" /> Jarak</label>
                        <p className="text-sm mt-0.5">{portalParsedData.lokasiJarak}</p>
                      </div>
                    )}
                    {portalParsedData.nilaiRataRata && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Award className="w-3 h-3" /> Nilai Rata-rata</label>
                        <p className="text-sm font-bold text-emerald-600 mt-0.5">{portalParsedData.nilaiRataRata}</p>
                      </div>
                    )}
                    {portalParsedData.skor && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Award className="w-3 h-3" /> Skor</label>
                        <p className="text-sm font-bold text-amber-600 mt-0.5">{portalParsedData.skor}</p>
                      </div>
                    )}
                    {portalParsedData.skorJarak && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><MapPinned className="w-3 h-3" /> Skor Jarak</label>
                        <p className="text-sm mt-0.5">{portalParsedData.skorJarak}</p>
                      </div>
                    )}
                    {portalParsedData.skorNilaiRaport && (
                      <div className="bg-sky-50 rounded-lg p-2.5">
                        <label className="text-xs text-sky-600 font-medium flex items-center gap-1"><Award className="w-3 h-3" /> Skor Nilai Raport</label>
                        <p className="text-sm font-bold text-sky-700 mt-0.5">{portalParsedData.skorNilaiRaport}</p>
                      </div>
                    )}
                  </div>

                  {/* Schools */}
                  <div className="grid grid-cols-2 gap-3">
                    {portalParsedData.namaSekolahAsal && (
                      <div className="bg-gray-50 rounded-lg p-2.5">
                        <label className="text-xs text-gray-500 font-medium">Asal Sekolah</label>
                        <p className="text-sm font-medium mt-0.5">{portalParsedData.namaSekolahAsal}</p>
                      </div>
                    )}
                    {portalParsedData.namaSekolahPilihan && (
                      <div className="bg-sky-50 rounded-lg p-2.5">
                        <label className="text-xs text-sky-600 font-medium">Sekolah Pilihan</label>
                        <p className="text-sm font-medium text-sky-800 mt-0.5">{portalParsedData.namaSekolahPilihan}</p>
                      </div>
                    )}
                  </div>

                  {/* Address */}
                  {(portalParsedData.alamat || portalParsedData.alamatLengkap) && (
                    <div className="bg-gray-50 rounded-lg p-2.5">
                      <label className="text-xs text-gray-500 font-medium">Alamat</label>
                      <p className="text-sm mt-0.5">{portalParsedData.alamat}</p>
                      {portalParsedData.alamatLengkap && portalParsedData.alamatLengkap !== portalParsedData.alamat && (
                        <p className="text-xs text-gray-500 mt-0.5">{portalParsedData.alamatLengkap}</p>
                      )}
                    </div>
                  )}

                  {/* Nilai Rapor */}
                  {portalParsedData.nilaiRapor && (() => {
                    try {
                      const grades = JSON.parse(portalParsedData.nilaiRapor)
                      return (
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                          <h4 className="text-sm font-medium text-amber-800 mb-2 flex items-center gap-1">
                            <GraduationCap className="w-4 h-4" /> Nilai Rapor
                          </h4>
                          <div className="grid grid-cols-2 gap-2">
                            {Object.entries(grades).map(([subject, value]) => (
                              <div key={subject} className="flex justify-between text-sm bg-white rounded px-2 py-1">
                                <span className="text-gray-600 text-xs">{subject}</span>
                                <span className="font-bold text-amber-700">{String(value)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )
                    } catch { return null }
                  })()}

                  {/* Coordinates */}
                  {(portalParsedData.latitude || portalParsedData.longitude) && (
                    <div className="bg-gray-50 rounded-lg p-2.5">
                      <label className="text-xs text-gray-500 font-medium">Koordinat</label>
                      <p className="text-xs font-mono mt-0.5">{portalParsedData.latitude}, {portalParsedData.longitude}</p>
                    </div>
                  )}

                  {/* Verification Data */}
                  {portalParsedData.dokumen && (
                    <div className="bg-sky-50 border border-sky-200 rounded-lg p-3">
                      <h4 className="text-sm font-medium text-sky-800 mb-2 flex items-center gap-1">
                        <ClipboardCheck className="w-4 h-4" /> Data Verifikasi
                      </h4>
                      <div className="grid grid-cols-2 gap-2">
                        {portalParsedData.dokumen && (
                          <div className="col-span-2 bg-white rounded px-2 py-1.5">
                            <label className="text-xs text-gray-500 font-medium">Dokumen</label>
                            <p className="text-sm">{portalParsedData.dokumen}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => setPortalParsedData(null)}>
                    <RotateCcw className="w-4 h-4" />
                    Parse Ulang
                  </Button>
                </div>
              </>
            )}
          </div>

          <DialogFooter>
            {!portalParsedData ? (
              <Button onClick={handlePortalPaste} disabled={!portalRawText.trim() || portalParsing} className="bg-emerald-600 hover:bg-emerald-700">
                {portalParsing ? (<><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</>) : (<><ClipboardCheck className="w-4 h-4" /> Parse Data</>)}
              </Button>
            ) : (
              <>
                <Button variant="outline" onClick={() => { setPortalParsedData(null); setPortalRawText('') }}>
                  Batal
                </Button>
                <Button onClick={handlePortalSave} disabled={importing || !portalSelectedJalur} className="bg-emerald-600 hover:bg-emerald-700">
                  {importing ? (<><Loader2 className="w-4 h-4 animate-spin" /> Menyimpan...</>) : (<><Check className="w-4 h-4" /> Simpan Data</>)}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ==================== SINGLE VERIFY DIALOG ==================== */}
      <Dialog open={verifyDialogOpen} onOpenChange={setVerifyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-5 h-5 text-emerald-600" /> Terima Pendaftar</>
              ) : (
                <><ThumbsDown className="w-5 h-5 text-red-600" /> Tolak Pendaftar</>
              )}
            </DialogTitle>
            <DialogDescription>
              {verifyAction === 'VERIFIED'
                ? 'Apakah Anda yakin ingin MENERIMA pendaftar ini? Data akan diverifikasi dan diterima di SPMB 2026.'
                : 'Apakah Anda yakin ingin MENOLAK pendaftar ini? Berikan alasan penolakan jika diperlukan.'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {verifyAction === 'REJECTED' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-red-800">Perhatian!</p>
                    <p className="text-sm text-red-700">Pendaftar yang ditolak tetap dapat diterima kembali nanti melalui menu Ditolak.</p>
                  </div>
                </div>
              </div>
            )}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 block">
                {verifyAction === 'VERIFIED' ? 'Catatan Verifikasi' : 'Alasan Penolakan'} {verifyAction === 'REJECTED' && <span className="text-red-500">*</span>}
              </label>
              <Textarea
                placeholder={verifyAction === 'VERIFIED' ? 'Catatan tambahan (opsional)...' : 'Tuliskan alasan penolakan...'}
                value={verifyNote}
                onChange={(e) => setVerifyNote(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setVerifyDialogOpen(false)}>Batal</Button>
            <Button
              onClick={handleVerify}
              disabled={verifying}
              className={verifyAction === 'VERIFIED' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              variant={verifyAction === 'REJECTED' ? 'destructive' : 'default'}
            >
              {verifying ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</>
              ) : verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-4 h-4" /> Terima</>
              ) : (
                <><ThumbsDown className="w-4 h-4" /> Tolak</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ==================== BULK VERIFY DIALOG ==================== */}
      <Dialog open={bulkVerifyDialogOpen} onOpenChange={setBulkVerifyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-5 h-5 text-emerald-600" /> Terima {selectedIds.size} Pendaftar</>
              ) : (
                <><ThumbsDown className="w-5 h-5 text-red-600" /> Tolak {selectedIds.size} Pendaftar</>
              )}
            </DialogTitle>
            <DialogDescription>
              {verifyAction === 'VERIFIED'
                ? `Apakah Anda yakin ingin MENERIMA ${selectedIds.size} pendaftar yang dipilih?`
                : `Apakah Anda yakin ingin MENOLAK ${selectedIds.size} pendaftar yang dipilih?`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {verifyAction === 'REJECTED' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-red-800">Perhatian!</p>
                    <p className="text-sm text-red-700">Pendaftar yang ditolak tetap dapat diterima kembali nanti melalui menu Ditolak.</p>
                  </div>
                </div>
              </div>
            )}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1.5 block">
                {verifyAction === 'VERIFIED' ? 'Catatan Verifikasi' : 'Alasan Penolakan'} {verifyAction === 'REJECTED' && <span className="text-red-500">*</span>}
              </label>
              <Textarea
                placeholder={verifyAction === 'VERIFIED' ? 'Catatan untuk semua pendaftar (opsional)...' : 'Tuliskan alasan penolakan untuk semua pendaftar...'}
                value={verifyNote}
                onChange={(e) => setVerifyNote(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkVerifyDialogOpen(false)}>Batal</Button>
            <Button
              onClick={handleBulkVerify}
              disabled={verifying}
              className={verifyAction === 'VERIFIED' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              variant={verifyAction === 'REJECTED' ? 'destructive' : 'default'}
            >
              {verifying ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Memproses...</>
              ) : verifyAction === 'VERIFIED' ? (
                <><ThumbsUp className="w-4 h-4" /> Terima Semua</>
              ) : (
                <><ThumbsDown className="w-4 h-4" /> Tolak Semua</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ==================== DETAIL DIALOG ==================== */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-600" />
              Detail Pendaftar
            </DialogTitle>
            <DialogDescription>Informasi lengkap pendaftar SPMB 2026</DialogDescription>
          </DialogHeader>

          {detailTarget && (
            <div className="space-y-4 overflow-y-auto flex-1 min-h-0 pr-1" style={{ scrollbarGutter: 'stable' }}>
              {/* Status badge at top */}
              <div className="flex items-center gap-2">
                <Badge variant="outline" className={`${STATUS_COLORS[detailTarget.verificationStatus]} text-sm px-3 py-1`}>
                  {detailTarget.verificationStatus === 'PENDING' && <Clock className="w-4 h-4" />}
                  {detailTarget.verificationStatus === 'VERIFIED' && <CheckCircle2 className="w-4 h-4" />}
                  {detailTarget.verificationStatus === 'REJECTED' && <XCircle className="w-4 h-4" />}
                  {detailTarget.verificationStatus === 'PENDING' ? 'Menunggu Verifikasi' :
                   detailTarget.verificationStatus === 'VERIFIED' ? 'Diterima (Terverifikasi)' : 'Ditolak'}
                </Badge>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 font-medium">No. Registrasi</label>
                  <p className="text-sm font-mono font-medium">{detailTarget.noRegistrasi}</p>
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium">NISN</label>
                  <p className="text-sm font-mono">{detailTarget.nisn}</p>
                </div>
                <div className="col-span-2">
                  <label className="text-xs text-gray-500 font-medium">Nama Lengkap</label>
                  <p className="text-sm font-semibold">{detailTarget.nama}</p>
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium">Sub Jalur</label>
                  <div className="mt-1">
                    <Badge variant="outline" className={SUB_JALUR_COLORS[detailTarget.subJalur] || 'bg-gray-100 text-gray-800'}>
                      {detailTarget.subJalur}
                    </Badge>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium">Jurusan</label>
                  <div className="mt-1">
                    <Badge variant="secondary">{detailTarget.jurusan}</Badge>
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Sekolah Pilihan</h4>
                <div className="bg-sky-50 rounded-lg p-3">
                  <p className="text-sm font-medium text-sky-800">{detailTarget.namaSekolahPilihan}</p>
                  <p className="text-xs text-sky-600">NPSN: {detailTarget.npsnSekolahPilihan}</p>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Sekolah Asal</h4>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-sm font-medium">{detailTarget.namaSekolahAsal}</p>
                  <p className="text-xs text-gray-500">NPSN: {detailTarget.npsnSekolahAsal}</p>
                </div>
              </div>

              {/* Portal SPMB Data */}
              {(detailTarget.nik || detailTarget.tanggalLahir || detailTarget.alamat || detailTarget.noTelpSiswa || detailTarget.noTelpOrangtua || detailTarget.lokasiJarak || detailTarget.nilaiRataRata || detailTarget.skor || detailTarget.nilaiRapor || detailTarget.skorJarak || detailTarget.skorNilaiRaport) && (
                <div className="border-t pt-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-1.5">
                    <ClipboardCheck className="w-4 h-4 text-emerald-600" />
                    Data Portal SPMB
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    {detailTarget.nik && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium">NIK</label>
                        <p className="text-sm font-mono">{detailTarget.nik}</p>
                      </div>
                    )}
                    {detailTarget.tanggalLahir && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium">Tanggal Lahir</label>
                        <p className="text-sm">{detailTarget.tanggalLahir}</p>
                      </div>
                    )}
                    {detailTarget.noTelpSiswa && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium">Telp Siswa</label>
                        <p className="text-sm font-mono">{detailTarget.noTelpSiswa}</p>
                      </div>
                    )}
                    {detailTarget.noTelpOrangtua && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium">Telp Orangtua</label>
                        <p className="text-sm font-mono">{detailTarget.noTelpOrangtua}</p>
                      </div>
                    )}
                    {detailTarget.lokasiJarak && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium">Jarak</label>
                        <p className="text-sm">{detailTarget.lokasiJarak}</p>
                      </div>
                    )}
                    {detailTarget.nilaiRataRata && (
                      <div className="bg-emerald-50 rounded-lg p-2">
                        <label className="text-xs text-emerald-600 font-medium">Nilai Rata-rata</label>
                        <p className="text-sm font-bold text-emerald-700">{detailTarget.nilaiRataRata}</p>
                      </div>
                    )}
                    {detailTarget.skor && (
                      <div className="bg-amber-50 rounded-lg p-2">
                        <label className="text-xs text-amber-600 font-medium">Skor</label>
                        <p className="text-sm font-bold text-amber-700">{detailTarget.skor}</p>
                      </div>
                    )}
                    {detailTarget.skorJarak && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Globe className="w-3 h-3 text-sky-400" /> Skor Jarak</label>
                        <p className="text-sm">{detailTarget.skorJarak}</p>
                      </div>
                    )}
                    {detailTarget.skorNilaiRaport && (
                      <div className="bg-sky-50 rounded-lg p-2">
                        <label className="text-xs text-sky-600 font-medium">Skor Nilai Raport</label>
                        <p className="text-sm font-bold text-sky-700">{detailTarget.skorNilaiRaport}</p>
                      </div>
                    )}
                  </div>

                  {detailTarget.alamat && (
                    <div className="mt-3 bg-gray-50 rounded-lg p-2">
                      <label className="text-xs text-gray-500 font-medium">Alamat</label>
                      <p className="text-sm">{detailTarget.alamat}</p>
                      {detailTarget.alamatLengkap && <p className="text-xs text-gray-400">{detailTarget.alamatLengkap}</p>}
                    </div>
                  )}

                  {detailTarget.nilaiRapor && (() => {
                    try {
                      const grades = JSON.parse(detailTarget.nilaiRapor)
                      return (
                        <div className="mt-3 bg-amber-50 border border-amber-200 rounded-lg p-3">
                          <h5 className="text-xs font-medium text-amber-800 mb-2 flex items-center gap-1">
                            <GraduationCap className="w-3.5 h-3.5" /> Nilai Rapor
                          </h5>
                          <div className="grid grid-cols-2 gap-1.5">
                            {Object.entries(grades).map(([subject, value]) => (
                              <div key={subject} className="flex justify-between text-xs bg-white rounded px-2 py-1">
                                <span className="text-gray-600">{subject}</span>
                                <span className="font-bold text-amber-700">{String(value)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )
                    } catch { return null }
                  })()}

                  {(detailTarget.latitude || detailTarget.longitude) && (
                    <div className="mt-3 bg-gray-50 rounded-lg p-2">
                      <label className="text-xs text-gray-500 font-medium">Koordinat</label>
                      <p className="text-xs font-mono">{detailTarget.latitude}, {detailTarget.longitude}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Data Verifikasi */}
              {(detailTarget.skorNilaiRaport || detailTarget.kekuranganVerifikasi || detailTarget.tanggalVerif || detailTarget.jamVerif || detailTarget.terbitKK || detailTarget.lamaKK || detailTarget.dokumen) && (
                <div className="border-t pt-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-1.5">
                    <ClipboardCheck className="w-4 h-4 text-sky-600" />
                    Data Verifikasi
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    {detailTarget.skorNilaiRaport && (
                      <div className="bg-sky-50 rounded-lg p-2">
                        <label className="text-xs text-sky-600 font-medium">Skor Nilai Raport</label>
                        <p className="text-sm font-bold text-sky-700">{detailTarget.skorNilaiRaport}</p>
                      </div>
                    )}
                    {detailTarget.kekuranganVerifikasi && (
                      <div className="bg-red-50 rounded-lg p-2 col-span-2">
                        <div className="flex items-center justify-between">
                          <label className="text-xs text-red-600 font-medium">Kekurangan Verifikasi</label>
                          <button
                            className="flex items-center gap-1 text-[10px] text-red-400 hover:text-emerald-600 transition-colors"
                            onClick={async () => {
                              const text = detailTarget.kekuranganVerifikasi!.replace(/^\d+\.\s*/gm, '')
                              try { await navigator.clipboard.writeText(text) } catch { document.execCommand('copy') }
                            }}
                            title="Salin alasan untuk paste ke portal SPMB"
                          >
                            <Copy className="w-3 h-3" /> Salin
                          </button>
                        </div>
                        <div className="mt-1 space-y-0.5">
                          {detailTarget.kekuranganVerifikasi.split('; ').map((item: string, idx: number) => {
                            const cleanItem = item.replace(/^\d+\.\s*/, '')
                            return cleanItem ? (
                              <div key={idx} className="flex items-start gap-1.5 text-sm text-red-700">
                                <span className="text-red-400 shrink-0 mt-px">•</span>
                                <span>{cleanItem}</span>
                              </div>
                            ) : null
                          })}
                        </div>
                      </div>
                    )}
                    {detailTarget.tanggalVerif && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><CalendarDays className="w-3 h-3" /> Tanggal Verifikasi</label>
                        <p className="text-sm">{detailTarget.tanggalVerif}</p>
                      </div>
                    )}
                    {detailTarget.jamVerif && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium">Jam Verifikasi</label>
                        <p className="text-sm">{detailTarget.jamVerif}</p>
                      </div>
                    )}
                    {detailTarget.terbitKK && (
                      <div className="bg-gray-50 rounded-lg p-2">
                        <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><IdCard className="w-3 h-3" /> Terbit KK</label>
                        <p className="text-sm">{detailTarget.terbitKK}</p>
                      </div>
                    )}
                    {(detailTarget.terbitKK || detailTarget.lamaKK) && (
                      <div className={`rounded-lg p-2 ${
                        detailTarget.terbitKK && isKKKurangSetahun(detailTarget.terbitKK)
                          ? 'bg-red-50 border border-red-200'
                          : 'bg-emerald-50 border border-emerald-200'
                      }`}>
                        <label className={`text-xs font-medium flex items-center gap-1 ${
                          detailTarget.terbitKK && isKKKurangSetahun(detailTarget.terbitKK)
                            ? 'text-red-600'
                            : 'text-emerald-600'
                        }`}>
                          <CalendarClock className="w-3 h-3" /> Lama KK
                        </label>
                        <p className={`text-sm font-bold ${
                          detailTarget.terbitKK && isKKKurangSetahun(detailTarget.terbitKK)
                            ? 'text-red-700'
                            : 'text-emerald-700'
                        }`}>
                          {detailTarget.lamaKK || (detailTarget.terbitKK ? hitungLamaKK(detailTarget.terbitKK) : '-')}
                        </p>
                        {detailTarget.terbitKK && isKKKurangSetahun(detailTarget.terbitKK) && (
                          <p className="text-xs text-red-500 mt-0.5">⚠ KK kurang dari 1 tahun</p>
                        )}
                      </div>
                    )}
                    {detailTarget.dokumen && (
                      <div className="bg-gray-50 rounded-lg p-2 col-span-2">
                        <label className="text-xs text-gray-500 font-medium">Dokumen</label>
                        <p className="text-sm">{detailTarget.dokumen}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="border-t pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Status Pendaftaran</label>
                    <div className="mt-1"><Badge variant="outline">{detailTarget.status}</Badge></div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Waktu Daftar</label>
                    <p className="text-sm">{detailTarget.waktuDaftar}</p>
                  </div>
                  {detailTarget.verificationNote && (
                    <div className="col-span-2">
                      <label className="text-xs text-gray-500 font-medium">
                        {detailTarget.verificationStatus === 'REJECTED' ? 'Alasan Penolakan' : 'Catatan Verifikasi'}
                      </label>
                      <p className="text-sm mt-1 bg-yellow-50 p-2 rounded border border-yellow-200">
                        {detailTarget.verificationNote}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2 border-t">
                {detailTarget.verificationStatus !== 'VERIFIED' && (
                  <Button
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                    onClick={() => {
                      setVerifyTargetId(detailTarget.id)
                      setVerifyAction('VERIFIED')
                      setVerifyNote('')
                      setDetailDialogOpen(false)
                      setVerifyDialogOpen(true)
                    }}
                  >
                    <ThumbsUp className="w-4 h-4" />
                    Terima
                  </Button>
                )}
                {detailTarget.verificationStatus !== 'REJECTED' && (
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => {
                      setVerifyTargetId(detailTarget.id)
                      setVerifyAction('REJECTED')
                      setVerifyNote('')
                      setDetailDialogOpen(false)
                      setVerifyDialogOpen(true)
                    }}
                  >
                    <ThumbsDown className="w-4 h-4" />
                    Tolak
                  </Button>
                )}
                {detailTarget.verificationStatus === 'VERIFIED' && (
                  <Button
                    variant="outline"
                    className="flex-1 border-yellow-400 text-yellow-700 hover:bg-yellow-50"
                    onClick={() => {
                      setVerifyTargetId(detailTarget.id)
                      setVerifyAction('REJECTED')
                      setVerifyNote('')
                      setDetailDialogOpen(false)
                      setVerifyDialogOpen(true)
                    }}
                  >
                    <RotateCcw className="w-4 h-4" />
                    Batalkan & Tolak
                  </Button>
                )}
                {detailTarget.verificationStatus === 'REJECTED' && (
                  <Button
                    variant="outline"
                    className="flex-1 border-emerald-400 text-emerald-700 hover:bg-emerald-50"
                    onClick={() => {
                      setVerifyTargetId(detailTarget.id)
                      setVerifyAction('VERIFIED')
                      setVerifyNote('')
                      setDetailDialogOpen(false)
                      setVerifyDialogOpen(true)
                    }}
                  >
                    <RotateCcw className="w-4 h-4" />
                    Terima Ulang
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ==================== EDIT DIALOG (Home Component) ==================== */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pencil className="w-5 h-5 text-blue-600" /> Edit Data Pendaftar
            </DialogTitle>
            <DialogDescription>
              Edit data pendaftar <span className="font-semibold">{editTarget?.nama}</span> ({editTarget?.noRegistrasi})
            </DialogDescription>
          </DialogHeader>
          {editTarget && (
            <div className="space-y-6">
              {/* Data Pendaftar */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-gray-500" /> Data Pendaftar
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium">No. Registrasi</label>
                    <Input value={editForm.noRegistrasi || ''} onChange={e => setEditForm({...editForm, noRegistrasi: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Nama</label>
                    <Input value={editForm.nama || ''} onChange={e => setEditForm({...editForm, nama: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NISN</label>
                    <Input value={editForm.nisn || ''} onChange={e => setEditForm({...editForm, nisn: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Sub Jalur</label>
                    <Select value={editForm.subJalur || ''} onValueChange={v => setEditForm({...editForm, subJalur: v})}>
                      <SelectTrigger className="mt-1"><SelectValue placeholder="Pilih Sub Jalur" /></SelectTrigger>
                      <SelectContent>
                        {subJalurOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NIK</label>
                    <Input value={editForm.nik || ''} onChange={e => setEditForm({...editForm, nik: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Tanggal Lahir</label>
                    <Input type="date" value={editForm.tanggalLahir || ''} onChange={e => setEditForm({...editForm, tanggalLahir: e.target.value})} className="mt-1" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs text-gray-500 font-medium">Alamat</label>
                    <Input value={editForm.alamat || ''} onChange={e => setEditForm({...editForm, alamat: e.target.value})} className="mt-1" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs text-gray-500 font-medium">Alamat Lengkap</label>
                    <Textarea value={editForm.alamatLengkap || ''} onChange={e => setEditForm({...editForm, alamatLengkap: e.target.value})} className="mt-1" rows={2} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">No. Telp Siswa</label>
                    <Input value={editForm.noTelpSiswa || ''} onChange={e => setEditForm({...editForm, noTelpSiswa: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">No. Telp Orangtua</label>
                    <Input value={editForm.noTelpOrangtua || ''} onChange={e => setEditForm({...editForm, noTelpOrangtua: e.target.value})} className="mt-1" />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Data Sekolah */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <School className="w-4 h-4 text-gray-500" /> Data Sekolah
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NPSN Sekolah Pilihan</label>
                    <Input value={editForm.npsnSekolahPilihan || ''} onChange={e => setEditForm({...editForm, npsnSekolahPilihan: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Nama Sekolah Pilihan</label>
                    <Input value={editForm.namaSekolahPilihan || ''} onChange={e => setEditForm({...editForm, namaSekolahPilihan: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Jurusan</label>
                    <Input value={editForm.jurusan || ''} onChange={e => setEditForm({...editForm, jurusan: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">NPSN Sekolah Asal</label>
                    <Input value={editForm.npsnSekolahAsal || ''} onChange={e => setEditForm({...editForm, npsnSekolahAsal: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Nama Sekolah Asal</label>
                    <Input value={editForm.namaSekolahAsal || ''} onChange={e => setEditForm({...editForm, namaSekolahAsal: e.target.value})} className="mt-1" />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Data Verifikasi */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <ClipboardCheck className="w-4 h-4 text-gray-500" /> Data Verifikasi
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Globe className="w-3 h-3 text-sky-400" /> Skor Jarak</label>
                    <Input value={editForm.skorJarak || ''} readOnly className="mt-1 bg-gray-50 text-gray-500 cursor-not-allowed border-dashed" title="Otomatis dari portal paste" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Globe className="w-3 h-3 text-sky-400" /> Skor Nilai Raport</label>
                    <Input value={editForm.skorNilaiRaport || ''} readOnly className="mt-1 bg-gray-50 text-gray-500 cursor-not-allowed border-dashed" title="Otomatis dari portal paste" />
                    <p className="text-[10px] text-sky-500 mt-0.5">↻ Otomatis dari portal paste</p>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs text-gray-500 font-medium">Kekurangan Verifikasi</label>
                    <div className="mt-1">
                      <Select value={editForm.kekuranganVerifikasi || ''} onValueChange={v => setEditForm({...editForm, kekuranganVerifikasi: v === '__none__' ? '' : v})}>
                        <SelectTrigger><SelectValue placeholder="Pilih kekurangan verifikasi" /></SelectTrigger>
                        <SelectContent className="max-h-64">
                          <SelectItem value="__none__">- Tidak Ada -</SelectItem>
                          {KEKURANGAN_VERIFIKASI_DEFAULTS.map(opt => (
                            <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Tanggal Verifikasi</label>
                    <Input type="date" value={editForm.tanggalVerif || ''} onChange={e => setEditForm({...editForm, tanggalVerif: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Jam Verifikasi</label>
                    <Input type="time" value={editForm.jamVerif || ''} onChange={e => setEditForm({...editForm, jamVerif: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Terbit KK</label>
                    <div className="flex items-center gap-1 mt-1">
                      <Input type="date" value={editForm.terbitKK || ''} onChange={e => setEditForm({...editForm, terbitKK: e.target.value})} className="flex-1" />
                      {editForm.terbitKK && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-700 hover:bg-red-50 h-9 px-2"
                          onClick={() => setEditForm({...editForm, terbitKK: ''})}
                          title="Kosongkan"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Lama KK</label>
                    <Input value={editForm.terbitKK ? hitungLamaKK(editForm.terbitKK) : ''} readOnly className="mt-1 bg-gray-50" />
                    <p className="text-xs text-gray-400 mt-1">Dihitung otomatis dari Terbit KK</p>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Data Lokasi & Nilai */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-gray-500" /> Lokasi & Nilai
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Latitude</label>
                    <Input value={editForm.latitude || ''} onChange={e => setEditForm({...editForm, latitude: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Longitude</label>
                    <Input value={editForm.longitude || ''} onChange={e => setEditForm({...editForm, longitude: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium">Lokasi Jarak</label>
                    <Input value={editForm.lokasiJarak || ''} onChange={e => setEditForm({...editForm, lokasiJarak: e.target.value})} className="mt-1" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium flex items-center gap-1"><Globe className="w-3 h-3 text-sky-400" /> Nilai Rata-Rata</label>
                    <Input value={editForm.nilaiRataRata || ''} readOnly className="mt-1 bg-gray-50 text-gray-500 cursor-not-allowed border-dashed" title="Otomatis dari portal paste" />
                    <p className="text-[10px] text-sky-500 mt-0.5">↻ Otomatis dari portal paste</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Batal</Button>
            <Button onClick={handleSaveEdit} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
              {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Menyimpan...</> : <><Pencil className="w-4 h-4" /> Simpan</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ==================== DELETE DIALOG (Home Component) ==================== */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-600" /> Hapus Data Pendaftar
            </DialogTitle>
            <DialogDescription>
              Apakah Anda yakin ingin menghapus data pendaftar <span className="font-semibold">{deleteTarget?.nama}</span>? Tindakan ini tidak dapat dibatalkan.
            </DialogDescription>
          </DialogHeader>
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <div className="flex gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
              <p className="text-sm text-red-700">Data yang sudah dihapus tidak dapat dikembalikan. Pastikan Anda yakin sebelum melanjutkan.</p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Batal</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? <><Loader2 className="w-4 h-4 animate-spin" /> Menghapus...</> : <><Trash2 className="w-4 h-4" /> Hapus</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ==================== PREVIEW DIALOG ==================== */}
      <Dialog open={previewOpen} onOpenChange={(open) => { setPreviewOpen(open); if (!open) setPreviewData(null) }}>
        <DialogContent className="max-w-[95vw] max-h-[90vh] flex flex-col p-0">
          <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-emerald-600" /> Pratinjau Cetak
            </DialogTitle>
            <DialogDescription>
              Periksa data sebelum mencetak atau mengunduh
            </DialogDescription>
          </DialogHeader>

          {previewData && (
            <>
              {/* Preview Document Area */}
              <div className="flex-1 overflow-auto px-6">
                <div className="bg-white border border-gray-200 rounded-lg shadow-sm">
                  {/* Document Header */}
                  <div className="bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 text-white p-4 rounded-t-lg">
                    <h2 className="text-lg font-bold text-center tracking-wide">{previewData.title}</h2>
                    <p className="text-emerald-100 text-center text-sm mt-0.5">{previewData.subtitle}</p>
                    <p className="text-emerald-200 text-center text-xs mt-1">
                      Dicetak: {new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>

                  {/* Summary Badge */}
                  <div className="px-4 pt-3 pb-2 flex items-center justify-between border-b border-gray-100">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-gray-500" />
                      <span className="text-sm font-medium text-gray-700">{previewData.rows.length} data</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {previewData.exportType === 'print' && (
                        <Badge variant="outline" className="text-xs border-blue-300 text-blue-700 bg-blue-50">
                          <Printer className="w-3 h-3 mr-1" /> Cetak
                        </Badge>
                      )}
                      {previewData.exportType === 'pdf' && (
                        <Badge variant="outline" className="text-xs border-red-300 text-red-700 bg-red-50">
                          <FileDown className="w-3 h-3 mr-1" /> PDF
                        </Badge>
                      )}
                      {previewData.exportType === 'excel' && (
                        <Badge variant="outline" className="text-xs border-green-300 text-green-700 bg-green-50">
                          <FileExcel className="w-3 h-3 mr-1" /> Excel
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Table Preview */}
                  <div className="overflow-auto max-h-[45vh]">
                    <table className="w-full text-sm">
                      <thead className="sticky top-0 z-10">
                        <tr className="bg-emerald-700 text-white">
                          {previewData.headers.map((h, i) => (
                            <th key={i} className="px-3 py-2.5 text-left text-xs font-semibold whitespace-nowrap">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {previewData.rows.length === 0 ? (
                          <tr>
                            <td colSpan={previewData.headers.length} className="text-center py-8 text-gray-400">
                              Tidak ada data untuk ditampilkan
                            </td>
                          </tr>
                        ) : (
                          previewData.rows.map((row, ri) => (
                            <tr key={ri} className={`${ri % 2 === 0 ? 'bg-white' : 'bg-emerald-50/50'} hover:bg-emerald-50 transition-colors`}>
                              {row.map((cell, ci) => (
                                <td key={ci} className={`px-3 py-2 text-xs border-b border-gray-100 ${ci === 0 ? 'text-center font-medium text-gray-500' : 'text-gray-700'} ${ci === 0 ? 'w-10' : ''}`}>
                                  {cell}
                                </td>
                              ))}
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Document Footer */}
                  <div className="px-4 py-2 bg-gray-50 rounded-b-lg border-t border-gray-100 text-center">
                    <p className="text-xs text-gray-400">Dokumen akan disimpan sebagai: <span className="font-medium text-gray-600">{previewData.filename}</span></p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <DialogFooter className="px-6 pb-6 pt-3 gap-2 shrink-0 border-t border-gray-100">
                <Button variant="outline" onClick={() => { setPreviewOpen(false); setPreviewData(null) }} className="gap-1.5">
                  <X className="w-4 h-4" /> Batal
                </Button>
                <Button onClick={confirmPreview} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700">
                  {previewData.exportType === 'print' && <><Printer className="w-4 h-4" /> Cetak Sekarang</>}
                  {previewData.exportType === 'pdf' && <><FileDown className="w-4 h-4" /> Unduh PDF</>}
                  {previewData.exportType === 'excel' && <><FileExcel className="w-4 h-4" /> Unduh Excel</>}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
